import csv
import numpy as np
from itertools import combinations


def load_solomon_data(filepath):
    customers = {}
    max_cust_id = 0
    print(f"尝试打开文件：{filepath}")
    with open(filepath, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f, delimiter="\t")
        fieldnames = [name.strip() if name else "" for name in reader.fieldnames]
        # 你的文件最后一列表头目前为空，但实际是 release_time
        if fieldnames and fieldnames[-1] == "":
            fieldnames[-1] = "release_time"
        reader.fieldnames = fieldnames
        required_cols = {
            "CUST NO.",
            "Coordinate X",
            "Coordinate Y",
            "H",
            "q",
            "p",
            "ready_time",
            "due_time",
            "demand_status",
            "demand_type",
            "release_time",
        }
        missing_cols = required_cols - set(reader.fieldnames)
        if missing_cols:
            raise ValueError(f"数据文件缺少必要列：{sorted(missing_cols)}")
        for line_no, row in enumerate(reader, start=2):
            row = {k: (v.strip() if v is not None else "") for k, v in row.items()}
            if not any(row.values()):
                continue
            if not row["CUST NO."]:
                raise ValueError(f"第 {line_no} 行客户编号为空，请检查 CUST NO. 列")
            cust_id = int(row["CUST NO."])
            ready_time = float(row["ready_time"])
            due_time = float(row["due_time"])
            release_time = float(row["release_time"])
            if ready_time > due_time:
                raise ValueError(f"客户 {cust_id} 的 ready_time 大于 due_time")
            customers[cust_id] = {
                "x": float(row["Coordinate X"]),
                "y": float(row["Coordinate Y"]),
                "z": float(row["H"]),
                "q": float(row["q"]),                  # 基本物资需求
                "p": float(row["p"]),                  # 紧急物资需求
                "ready_time": ready_time,              # 时间窗开始时间
                "due_time": due_time,                  # 时间窗结束时间
                "due": due_time,                       # 兼容旧代码
                "demand_status": row["demand_status"], # static / dynamic / depot
                "demand_type": row["demand_type"],     # basic / urgent / none
                "release_time": release_time,          # 动态需求释放时间
            }
            max_cust_id = max(max_cust_id, cust_id)
    if 0 not in customers:
        raise ValueError("数据文件中缺少起始仓库节点 0")
    depot_end = max_cust_id + 1
    customers[depot_end] = {
        "x": customers[0]["x"],
        "y": customers[0]["y"],
        "z": customers[0]["z"],
        "q": 0,
        "p": 0,
        "ready_time": 0,
        "due_time": float("inf"),
        "due": float("inf"),
        "demand_status": "depot",
        "demand_type": "none",
        "release_time": 0,
    }
    print(f"成功加载数据：{len(customers) - 2} 个客户 + 2 个仓库节点")
    return customers, depot_end


def compute_distances(customers):
    D_ij = {}
    node_ids = list(customers.keys())
    for i, j in combinations(node_ids, 2):
        x1, y1 = customers[i]["x"], customers[i]["y"]
        x2, y2 = customers[j]["x"], customers[j]["y"]
        dh = np.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2) * 1000
        D_ij[i, j] = D_ij[j, i] = dh
    return D_ij

