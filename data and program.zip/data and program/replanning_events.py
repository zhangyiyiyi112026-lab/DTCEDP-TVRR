from __future__ import annotations

import copy
from collections import defaultdict
from typing import TYPE_CHECKING, Any, Dict, List, Set

from replanning_types import (
    DroneReplanState,
    LockedCostState,
    ReplanContext,
    TruckReplanState,
)
from replanning_costs import (
    calculate_dynamic_objective,
    calculate_executed_cost_increment,
    commit_locked_cost_increment,
)
from solution import refresh_depot_phase_start_state

if TYPE_CHECKING:
    from ALNS import Solution


def _reject_deprecated_replenishment_in_replanning_solution(
    solution_data: Dict[str, Any],
    scope: str,
    replenishment_node: int = 999,
) -> None:
    if "truck_routes" not in solution_data:
        raise ValueError(f"{scope}: solution missing required key: truck_routes")
    if "drone_routes" not in solution_data:
        raise ValueError(f"{scope}: solution missing required key: drone_routes")
    truck_routes = solution_data["truck_routes"]
    drone_routes = solution_data["drone_routes"]
    if not isinstance(truck_routes, dict):
        raise TypeError(f'{scope}: solution["truck_routes"] must be a dict')
    if not isinstance(drone_routes, list):
        raise TypeError(f'{scope}: solution["drone_routes"] must be a list')

    for truck_id, route in truck_routes.items():
        if not isinstance(route, list):
            raise TypeError(f"{scope}: truck route of truck {truck_id} must be a list")
        for position, node in enumerate(route):
            if node == replenishment_node:
                raise ValueError(
                    f"{scope}: deprecated replenishment node {replenishment_node} "
                    f"appears in truck {truck_id} route at position {position}"
                )

    for task_index, task in enumerate(drone_routes):
        if not isinstance(task, dict):
            raise TypeError(f"{scope}: drone task {task_index} must be a dict")
        for key in ("launch_node", "recovery_node", "customer"):
            if key in task and task[key] == replenishment_node:
                raise ValueError(
                    f"{scope}: deprecated replenishment node {replenishment_node} "
                    f"appears in drone task {task_index} field {key}"
                )


def _build_locked_drone_intervals(
    previous_drone_routes: List[Dict[str, Any]],
    locked_drone_task_ids: Set[int],
) -> List[Dict[str, Any]]:
    intervals = []
    found_task_ids = set()
    for task_index, task in enumerate(previous_drone_routes):
        if not isinstance(task, dict):
            raise TypeError(f"previous drone task {task_index} must be a dict")
        required_keys = {
            "task_id",
            "truck_id",
            "drone_id",
            "customer",
            "launch_time",
            "recovery_time",
        }
        missing_keys = required_keys - set(task)
        if missing_keys:
            raise ValueError(
                f"previous drone task {task_index} missing required keys: "
                f"{sorted(missing_keys)}"
            )
        task_id = task["task_id"]
        if task_id not in locked_drone_task_ids:
            continue
        for key_name in ("task_id", "truck_id", "drone_id", "customer"):
            if isinstance(task[key_name], bool) or not isinstance(task[key_name], int):
                raise TypeError(
                    f"locked drone task {task_index} {key_name} must be int, "
                    f"got {type(task[key_name]).__name__}"
                )
        for key_name in ("launch_time", "recovery_time"):
            if isinstance(task[key_name], bool) or not isinstance(
                task[key_name],
                (int, float),
            ):
                raise TypeError(
                    f"locked drone task {task_id} {key_name} must be numeric, "
                    f"got {type(task[key_name]).__name__}"
                )
        launch_time = float(task["launch_time"])
        recovery_time = float(task["recovery_time"])
        if recovery_time < launch_time:
            raise ValueError(
                f"locked drone task {task_id} recovery_time {recovery_time} "
                f"is before launch_time {launch_time}"
            )
        intervals.append(
            {
                "task_id": task_id,
                "truck_id": task["truck_id"],
                "drone_id": task["drone_id"],
                "customer": task["customer"],
                "launch_time": launch_time,
                "recovery_time": recovery_time,
            }
        )
        found_task_ids.add(task_id)

    missing_task_ids = locked_drone_task_ids - found_task_ids
    if missing_task_ids:
        raise ValueError(
            f"previous_solution missing locked drone task_ids: "
            f"{sorted(missing_task_ids)}"
        )
    return intervals


def build_replanning_events(
    customers: Dict[int, Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """根据动态客户 reveal_time 构造按时间排序的重规划事件序列。"""
    grouped: Dict[float, List[int]] = defaultdict(list)

    for customer_id, customer in customers.items():
        if customer["is_static"]:
            continue

        release_time = customer["release_time"]
        reveal_time = customer["reveal_time"]
        earliest = customer["earliest"]
        latest = customer["latest"]

        if reveal_time < 0:
            raise ValueError(
                f"customer {customer_id} reveal_time must be non-negative"
            )

        if release_time > reveal_time:
            raise ValueError(
                f"customer {customer_id} release_time exceeds reveal_time"
            )

        if earliest > latest:
            raise ValueError(
                f"customer {customer_id} earliest exceeds latest"
            )

        grouped[reveal_time].append(customer_id)
    events = []
    for trigger_time in sorted(grouped):
        events.append(
            {
                "trigger_time": trigger_time,
                "customer_ids": sorted(grouped[trigger_time]),
            }
        )

    return events

def reveal_events_until(
    events: List[Dict[str, Any]],
    adjusted_trigger_time: float,
    already_revealed_customer_ids: Set[int],
) -> Set[int]:
    """返回截止时间前应揭示且尚未揭示的动态客户集合。"""
    if adjusted_trigger_time < 0:
        raise ValueError("adjusted_trigger_time must be non-negative")
    newly_revealed = set()
    for event in events:
        if event["trigger_time"] > adjusted_trigger_time:
            break
        for customer_id in event["customer_ids"]:
            if customer_id not in already_revealed_customer_ids:
                newly_revealed.add(customer_id)
    return newly_revealed


def _validate_replanning_events(
    events: List[Dict[str, Any]],
    customers: Dict[int, Dict[str, Any]],
) -> None:
    #这个函数的作用是在执行单个trigger主流程前，先检查事件列表events的结构是否合法
    if not isinstance(events, list):
        raise TypeError("events must be a list")

    previous_trigger_time = None#记录上一个事件的时间，用来检查事件是否按照时间升序排列
    seen_customer_ids = set()#已经在前面事件里见过的客户集合，用来防止同一个客户出现在多个事件里
    for event_index, event in enumerate(events):
        if not isinstance(event, dict):
            raise TypeError(f"event {event_index} must be a dict")
        for required_key in ("trigger_time", "customer_ids"):
            if required_key not in event:
                raise ValueError(
                    f"event {event_index} missing required key: {required_key}"
                )

        trigger_time = event["trigger_time"]
        #bool:布尔类型，只有两个值：true、false
        if not isinstance(trigger_time, (int, float)) or isinstance(trigger_time, bool):
            raise TypeError(f"event {event_index} trigger_time must be numeric")
        if trigger_time < 0:
            raise ValueError(f"event {event_index} trigger_time must be non-negative")
        #检查事件是否按升序排列
        if previous_trigger_time is not None and trigger_time < previous_trigger_time:
            raise ValueError("events must be sorted by trigger_time")
        previous_trigger_time = trigger_time

        customer_ids = event["customer_ids"]
        if not isinstance(customer_ids, list):
            raise TypeError(f"event {event_index} customer_ids must be a list")
        if not customer_ids:
            raise ValueError(f"event {event_index} customer_ids must not be empty")
        #同一个 trigger 触发时间，customer_ids 里有没有重复客户。
        duplicated_inside_event = {
            customer_id
            for customer_id in customer_ids
            if customer_ids.count(customer_id) > 1
        }#遍历 customer_ids，如果某个 customer_id 在列表中出现次数大于 1，就把它加入集合 duplicated_inside_event。
        if duplicated_inside_event:
            raise ValueError(
                f"event {event_index} contains duplicated customer_ids: "
                f"{sorted(duplicated_inside_event)}"
            )

        for customer_id in customer_ids:
            if customer_id not in customers:
                raise ValueError(
                    f"event {event_index} references unknown customer {customer_id}"
                )
            if customer_id in seen_customer_ids:
                raise ValueError(
                    f"customer {customer_id} appears in more than one event"
                )
            seen_customer_ids.add(customer_id)


def _has_unrevealed_replanning_event(
    events: List[Dict[str, Any]],
    already_revealed_customer_ids: Set[int],
) -> bool:#判断 events 里是否还有没被揭示过的动态客户。
    if not isinstance(already_revealed_customer_ids, set):
        raise TypeError("already_revealed_customer_ids must be a set")
    for event in events:
        for customer_id in event["customer_ids"]:
            if customer_id not in already_revealed_customer_ids:
                return True
    return False


def _customers_visible_in_replanning_phase(
    customers: Dict[int, Dict[str, Any]],
    revealed_customer_ids: Set[int],
) -> Dict[int, Dict[str, Any]]:
    if not isinstance(revealed_customer_ids, set):
        raise TypeError("revealed_customer_ids must be a set")
    unknown_revealed_customer_ids = revealed_customer_ids - set(customers)
    if unknown_revealed_customer_ids:
        raise ValueError(
            "revealed_customer_ids contains unknown customers: "
            f"{sorted(unknown_revealed_customer_ids)}"
        )

    visible_customers = {}
    for customer_id, customer in customers.items():
        if "is_static" not in customer:
            raise ValueError(f"customer {customer_id} missing required key: is_static")
        is_static = customer["is_static"]
        if not isinstance(is_static, bool):
            raise TypeError(
                f"customer {customer_id} is_static must be bool, "
                f"got {type(is_static).__name__}"
            )
        if is_static or customer_id in revealed_customer_ids:
            visible_customers[customer_id] = customer

    return visible_customers


def _set_alns_visible_customers_if_supported(
    alns: Any,
    customers: Dict[int, Dict[str, Any]],
    revealed_customer_ids: Set[int],
) -> None:
    if not hasattr(alns, "customers"):
        return None
    alns.customers = _customers_visible_in_replanning_phase(
        customers=customers,
        revealed_customer_ids=revealed_customer_ids,
    )
    return None


def adjust_trigger_time_away_from_drone_flights(
    drone_routes: List[Dict[str, Any]],
    trigger_time: float,
) -> Dict[str, Any]:
    """
    若动态事件触发时刻位于无人机飞行区间内部，
    则将其推迟到最近的安全回收时刻。
    """

    if isinstance(trigger_time, bool) or not isinstance(trigger_time, (int, float)):
        raise TypeError(
            f"trigger_time must be numeric, got {type(trigger_time).__name__}"
        )
    if trigger_time < 0:
        raise ValueError("trigger_time must be non-negative")
    if not isinstance(drone_routes, list):
        raise TypeError("drone_routes must be a list")
    for task_index, task in enumerate(drone_routes):
        if not isinstance(task, dict):
            raise TypeError(f"drone task {task_index} must be a dict")
        for required_key in ("task_id", "launch_time", "recovery_time"):
            if required_key not in task:
                raise ValueError(
                    f"drone task {task_index} missing required key: {required_key}"
                )
        for time_key in ("launch_time", "recovery_time"):
            value = task[time_key]
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise TypeError(
                    f"drone task {task_index} {time_key} must be numeric, "
                    f"got {type(value).__name__}"
                )
        if task["launch_time"] >= task["recovery_time"]:
            raise ValueError(
                f"drone task {task_index} launch_time must be before recovery_time"
            )

    adjusted_time = trigger_time
    blocking_task_ids = []

    while True:
        active_tasks = [
            task
            for task in drone_routes
            if task["launch_time"] <= adjusted_time < task["recovery_time"]
        ]

        if not active_tasks:
            break

        blocking_task_ids.extend(
            task["task_id"]
            for task in active_tasks
        )

        adjusted_time = min(
            task["recovery_time"]
            for task in active_tasks
        )

    return {
        "original_trigger_time": trigger_time,
        "adjusted_trigger_time": adjusted_time,
        "was_delayed": adjusted_time != trigger_time,
        "blocking_task_ids": sorted(set(blocking_task_ids)),
    }


def _find_anchor_time_drone_blockers(
    solution_data: Dict[str, Any],
    trigger_time: float,
    drone_ids_by_truck: Dict[int, List[int]],
    replenishment_node: int = 999,
) -> List[Dict[str, Any]]:
    if "truck_routes" not in solution_data:
        raise ValueError("solution_data missing required key: truck_routes")
    if "drone_routes" not in solution_data:
        raise ValueError("solution_data missing required key: drone_routes")
    if "validation_report" not in solution_data:
        raise ValueError("solution_data missing required key: validation_report")
    validation_report = solution_data["validation_report"]
    if not isinstance(validation_report, dict):
        raise TypeError('solution_data["validation_report"] must be a dict')
    if "truck_evaluations" not in validation_report:
        raise ValueError('solution_data["validation_report"] missing truck_evaluations')

    truck_routes = solution_data["truck_routes"]
    drone_routes = solution_data["drone_routes"]
    truck_evaluations = validation_report["truck_evaluations"]
    if not isinstance(truck_routes, dict):
        raise TypeError('solution_data["truck_routes"] must be a dict')
    if not isinstance(drone_routes, list):
        raise TypeError('solution_data["drone_routes"] must be a list')
    if not isinstance(truck_evaluations, dict):
        raise TypeError('validation_report["truck_evaluations"] must be a dict')

    _reject_deprecated_replenishment_in_replanning_solution(
        solution_data=solution_data,
        scope="_find_anchor_time_drone_blockers",
        replenishment_node=replenishment_node,
    )

    anchors_by_truck = {}
    timeline_by_truck = {}
    for truck_id, route in truck_routes.items():
        if truck_id not in truck_evaluations:
            raise ValueError(f"truck_evaluations missing truck_id {truck_id}")
        if truck_id not in drone_ids_by_truck:
            raise ValueError(f"drone_ids_by_truck missing truck_id {truck_id}")
        truck_evaluation = truck_evaluations[truck_id]
        if not isinstance(truck_evaluation, dict):
            raise TypeError(f"truck evaluation of truck {truck_id} must be a dict")
        if "timeline_by_position" not in truck_evaluation:
            raise ValueError(
                f"truck evaluation of truck {truck_id} missing timeline_by_position"
            )
        timeline_by_position = truck_evaluation["timeline_by_position"]
        anchor = determine_truck_anchor(
            route=route,
            timeline_by_position=timeline_by_position,
            trigger_time=trigger_time,
        )
        if anchor["anchor_node"] == replenishment_node:
            raise ValueError(
                f"_find_anchor_time_drone_blockers: deprecated replenishment node "
                f"{replenishment_node} cannot be a phase anchor for truck {truck_id}"
            )
        anchors_by_truck[truck_id] = anchor
        timeline_by_truck[truck_id] = timeline_by_position

    validated_tasks = []
    for task_index, task in enumerate(drone_routes):
        if not isinstance(task, dict):
            raise TypeError(f"drone task {task_index} must be a dict")
        required_keys = {
            "task_id",
            "truck_id",
            "launch_node",
            "launch_idx",
            "launch_time",
            "recovery_node",
            "recovery_idx",
            "recovery_time",
        }
        missing_keys = required_keys - set(task)
        if missing_keys:
            raise ValueError(
                f"drone task {task_index} missing required keys for anchor blocker "
                f"check: {sorted(missing_keys)}"
            )
        for key_name in ("task_id", "truck_id", "launch_idx", "recovery_idx"):
            if isinstance(task[key_name], bool) or not isinstance(task[key_name], int):
                raise TypeError(
                    f"drone task {task_index} {key_name} must be int, "
                    f"got {type(task[key_name]).__name__}"
                )
        for key_name in ("launch_time", "recovery_time"):
            if isinstance(task[key_name], bool) or not isinstance(
                task[key_name],
                (int, float),
            ):
                raise TypeError(
                    f"drone task {task_index} {key_name} must be numeric, "
                    f"got {type(task[key_name]).__name__}"
                )
        if task["launch_time"] >= task["recovery_time"]:
            raise ValueError(
                f"drone task {task_index} launch_time must be before recovery_time"
            )
        validated_tasks.append(task)

    blockers = []
    for task in sorted(validated_tasks, key=lambda item: item["recovery_time"]):
        truck_id = task["truck_id"]
        if truck_id not in anchors_by_truck:
            raise ValueError(
                f"drone task {task['task_id']} references unknown truck_id {truck_id}"
            )
        route = truck_routes[truck_id]
        launch_idx = task["launch_idx"]
        recovery_idx = task["recovery_idx"]
        if launch_idx < 0 or launch_idx >= len(route):
            raise ValueError(
                f"drone task {task['task_id']} launch_idx {launch_idx} "
                f"outside truck route length {len(route)}"
            )
        if recovery_idx < 0 or recovery_idx >= len(route):
            raise ValueError(
                f"drone task {task['task_id']} recovery_idx {recovery_idx} "
                f"outside truck route length {len(route)}"
            )
        if launch_idx >= recovery_idx:
            raise ValueError(
                f"drone task {task['task_id']} launch_idx must be before recovery_idx"
            )
        if route[launch_idx] != task["launch_node"]:
            raise ValueError(
                f"drone task {task['task_id']} launch_idx points to "
                f"{route[launch_idx]}, expected {task['launch_node']}"
            )
        if route[recovery_idx] != task["recovery_node"]:
            raise ValueError(
                f"drone task {task['task_id']} recovery_idx points to "
                f"{route[recovery_idx]}, expected {task['recovery_node']}"
            )

        anchor = anchors_by_truck[truck_id]
        anchor_position = len(anchor["locked_prefix"]) - 1
        anchor_time = anchor["anchor_time"]
        if task["launch_time"] <= anchor_time < task["recovery_time"]:
            if task["recovery_time"] <= trigger_time + 1e-9:
                anchors_by_truck[truck_id] = _build_anchor_from_route_position(
                    truck_id=truck_id,
                    route=route,
                    timeline_by_position=timeline_by_truck[truck_id],
                    position=recovery_idx,
                )
                continue
            blockers.append(
                {
                    "task_id": task["task_id"],
                    "truck_id": truck_id,
                    "anchor_time": anchor_time,
                    "launch_time": task["launch_time"],
                    "recovery_time": task["recovery_time"],
                }
            )
            continue
        if task["recovery_time"] <= anchor_time and recovery_idx > anchor_position:
            anchors_by_truck[truck_id] = _build_anchor_from_route_position(
                truck_id=truck_id,
                route=route,
                timeline_by_position=timeline_by_truck[truck_id],
                position=recovery_idx,
            )

    return blockers


def resolve_safe_replanning_trigger_time(
    solution_data: Dict[str, Any],
    raw_trigger_time: float,
    drone_ids_by_truck: Dict[int, List[int]],
    replenishment_node: int = 999,
) -> Dict[str, Any]:
    if isinstance(raw_trigger_time, bool) or not isinstance(
        raw_trigger_time,
        (int, float),
    ):
        raise TypeError(
            f"raw_trigger_time must be numeric, got {type(raw_trigger_time).__name__}"
        )
    if raw_trigger_time < 0:
        raise ValueError("raw_trigger_time must be non-negative")

    current_trigger_time = raw_trigger_time
    airborne_blocking_task_ids = set()
    anchor_blocking_task_ids = set()
    anchor_delay_adjustments = []
    max_iterations = len(solution_data["drone_routes"]) + 1

    for iteration in range(max_iterations):
        trigger_adjustment = adjust_trigger_time_away_from_drone_flights(
            drone_routes=solution_data["drone_routes"],
            trigger_time=current_trigger_time,
        )
        adjusted_trigger_time = trigger_adjustment["adjusted_trigger_time"]
        airborne_blocking_task_ids.update(trigger_adjustment["blocking_task_ids"])
        blockers = _find_anchor_time_drone_blockers(
            solution_data=solution_data,
            trigger_time=adjusted_trigger_time,
            drone_ids_by_truck=drone_ids_by_truck,
            replenishment_node=replenishment_node,
        )
        if not blockers:
            return {
                "original_trigger_time": raw_trigger_time,
                "adjusted_trigger_time": adjusted_trigger_time,
                "was_delayed": adjusted_trigger_time != raw_trigger_time,
                "blocking_task_ids": sorted(airborne_blocking_task_ids),
                "anchor_blocking_task_ids": sorted(anchor_blocking_task_ids),
                "anchor_delay_adjustments": anchor_delay_adjustments,
                "safe_split_iterations": iteration + 1,
            }

        next_trigger_time = min(blocker["recovery_time"] for blocker in blockers)
        if next_trigger_time <= adjusted_trigger_time:
            raise ValueError(
                "anchor-time blocker did not advance trigger_time: "
                f"adjusted_trigger_time={adjusted_trigger_time}, "
                f"blockers={blockers}"
            )
        anchor_blocking_task_ids.update(blocker["task_id"] for blocker in blockers)
        anchor_delay_adjustments.append(
            {
                "from_trigger_time": adjusted_trigger_time,
                "to_trigger_time": next_trigger_time,
                "blocking_task_ids": sorted(
                    {blocker["task_id"] for blocker in blockers}
                ),
                "blockers": blockers,
            }
        )
        current_trigger_time = next_trigger_time

    raise ValueError(
        "failed to resolve safe replanning trigger_time after "
        f"{max_iterations} iterations"
    )


def determine_truck_anchor(
    route: List[int],
    timeline_by_position: Dict[int, Dict[str, Any]],
    trigger_time: float,
) -> Dict[str, Any]:
    """根据安全触发时刻确定卡车后续重规划锚点。"""

    if trigger_time < 0:
        raise ValueError("trigger_time must be non-negative")
    if not route:
        raise ValueError("route must not be empty")

    for position, node in enumerate(route):
        if position not in timeline_by_position:
            raise ValueError(f"timeline_by_position missing position {position}")
        record = timeline_by_position[position]
        if record["node"] != node:
            raise ValueError(
                f"timeline position {position} node {record['node']} "
                f"does not match route node {node}"
            )
        if record["remaining_basic_load"] < 0:
            raise ValueError(
                f"timeline position {position} remaining_basic_load is negative"
            )
        if record["remaining_emergency_load"] < 0:
            raise ValueError(
                f"timeline position {position} remaining_emergency_load is negative"
            )

    start_departure_time = timeline_by_position[0]["departure_time"]
    if trigger_time <= start_departure_time:
        anchor_position = 0
    else:
        anchor_position = None
        for position in range(len(route)):
            record = timeline_by_position[position]
            if record["arrival_time"] <= trigger_time <= record["departure_time"]:
                anchor_position = position
                break

        if anchor_position is None:
            for position in range(len(route) - 1):
                current_record = timeline_by_position[position]
                next_record = timeline_by_position[position + 1]
                if (
                    current_record["departure_time"]
                    < trigger_time
                    < next_record["arrival_time"]
                ):
                    anchor_position = position + 1
                    break

        if anchor_position is None:
            anchor_position = len(route) - 1

    anchor_record = timeline_by_position[anchor_position]
    return {
        "anchor_position": anchor_position,
        "anchor_node": route[anchor_position],
        "anchor_time": anchor_record["departure_time"],
        "locked_prefix": route[: anchor_position + 1],
        "remaining_basic_load": anchor_record["remaining_basic_load"],
        "remaining_emergency_load": anchor_record["remaining_emergency_load"],
    }


def _build_anchor_from_route_position(
    truck_id: int,
    route: List[int],
    timeline_by_position: Dict[int, Dict[str, Any]],
    position: int,
) -> Dict[str, Any]:
    if isinstance(position, bool) or not isinstance(position, int):
        raise TypeError(
            f"truck {truck_id} anchor position must be int, "
            f"got {type(position).__name__}"
        )
    if position < 0 or position >= len(route):
        raise ValueError(
            f"truck {truck_id} anchor position {position} outside route length "
            f"{len(route)}"
        )
    if position not in timeline_by_position:
        raise ValueError(f"truck {truck_id} timeline missing position {position}")
    record = timeline_by_position[position]
    node = route[position]
    if record["node"] != node:
        raise ValueError(
            f"truck {truck_id} timeline node mismatch at position "
            f"{position}: {record['node']} != {node}"
        )
    return {
        "anchor_position": position,
        "anchor_node": node,
        "anchor_time": record["departure_time"],
        "locked_prefix": route[: position + 1],
        "remaining_basic_load": record["remaining_basic_load"],
        "remaining_emergency_load": record["remaining_emergency_load"],
    }


def split_solution_at_trigger(
    solution_data: Dict[str, Any],
    customers: Dict[int, Dict[str, Any]],
    trigger_time: float,
    drone_ids_by_truck: Dict[int, List[int]],
    replenishment_node: int = 999,
) -> Dict[str, Any]:
    """在安全触发时刻切分当前方案并提取后续重规划所需状态。"""

    if trigger_time < 0:
        raise ValueError("trigger_time must be non-negative")

    truck_routes = solution_data["truck_routes"]
    drone_routes = solution_data["drone_routes"]
    truck_evaluations = solution_data["validation_report"]["truck_evaluations"]
    _reject_deprecated_replenishment_in_replanning_solution(
        solution_data=solution_data,
        scope="split_solution_at_trigger",
        replenishment_node=replenishment_node,
    )

    completed_customer_ids = set()
    locked_drone_task_ids = set()
    truck_states = {}
    truck_timeline_by_truck = {}

    for truck_id, route in truck_routes.items():
        if truck_id not in truck_evaluations:
            raise ValueError(f"truck_evaluations missing truck_id {truck_id}")
        if truck_id not in drone_ids_by_truck:
            raise ValueError(f"drone_ids_by_truck missing truck_id {truck_id}")

        truck_evaluation = truck_evaluations[truck_id]
        timeline_by_position = truck_evaluation["timeline_by_position"]
        truck_timeline_by_truck[truck_id] = timeline_by_position
        anchor = determine_truck_anchor(
            route=route,
            timeline_by_position=timeline_by_position,
            trigger_time=trigger_time,
        )
        if anchor["anchor_node"] == replenishment_node:
            raise ValueError(
                f"split_solution_at_trigger: deprecated replenishment node "
                f"{replenishment_node} cannot be a phase anchor for truck {truck_id}"
            )

        truck_completed_customer_ids = {
            node
            for node in anchor["locked_prefix"]
            if node in customers
        }
        completed_customer_ids.update(truck_completed_customer_ids)

        truck_states[truck_id] = TruckReplanState(
            truck_id=truck_id,
            anchor_node=anchor["anchor_node"],
            anchor_position=anchor["anchor_position"],
            anchor_time=anchor["anchor_time"],
            remaining_basic_load=anchor["remaining_basic_load"],
            remaining_emergency_load=anchor["remaining_emergency_load"],
            locked_prefix=anchor["locked_prefix"],
            onboard_drone_ids=list(drone_ids_by_truck[truck_id]),
            completed_customer_ids=truck_completed_customer_ids,
        )

    validated_drone_routes = []
    for task_index, task in enumerate(drone_routes):
        if not isinstance(task, dict):
            raise TypeError(f"drone task {task_index} must be a dict")
        if "recovery_time" not in task:
            raise ValueError(
                f"drone task {task_index} missing required key before trigger split: "
                "recovery_time"
            )
        recovery_time = task["recovery_time"]
        if isinstance(recovery_time, bool) or not isinstance(recovery_time, (int, float)):
            raise TypeError(
                f"drone task {task_index} recovery_time must be numeric, "
                f"got {type(recovery_time).__name__}"
            )
        validated_drone_routes.append(task)

    for task in sorted(validated_drone_routes, key=lambda task: task["recovery_time"]):
        for required_key in (
            "task_id",
            "truck_id",
            "launch_node",
            "launch_idx",
            "launch_time",
            "customer",
            "recovery_node",
            "recovery_idx",
            "recovery_time",
        ):
            if required_key not in task:
                raise ValueError(
                    f"drone task missing required key before trigger split: "
                    f"{required_key}"
                )
        launch_time = task["launch_time"]
        recovery_time = task["recovery_time"]
        if isinstance(launch_time, bool) or not isinstance(launch_time, (int, float)):
            raise TypeError(
                f"drone task {task['task_id']} launch_time must be numeric, "
                f"got {type(launch_time).__name__}"
            )
        if isinstance(recovery_time, bool) or not isinstance(recovery_time, (int, float)):
            raise TypeError(
                f"drone task {task['task_id']} recovery_time must be numeric, "
                f"got {type(recovery_time).__name__}"
            )
        if launch_time >= recovery_time:
            raise ValueError(
                f"drone task {task['task_id']} launch_time must be before recovery_time"
            )
        truck_id = task["truck_id"]
        if truck_id not in truck_states:
            raise ValueError(
                f"drone task {task['task_id']} references unknown truck_id "
                f"{truck_id}"
            )
        launch_idx = task["launch_idx"]
        recovery_idx = task["recovery_idx"]
        if isinstance(launch_idx, bool) or not isinstance(launch_idx, int):
            raise TypeError(
                f"drone task {task['task_id']} launch_idx must be int, "
                f"got {type(launch_idx).__name__}"
            )
        if isinstance(recovery_idx, bool) or not isinstance(recovery_idx, int):
            raise TypeError(
                f"drone task {task['task_id']} recovery_idx must be int, "
                f"got {type(recovery_idx).__name__}"
            )
        route = truck_routes[truck_id]
        if launch_idx < 0 or launch_idx >= len(route):
            raise ValueError(
                f"drone task {task['task_id']} launch_idx {launch_idx} "
                f"outside truck route length {len(route)}"
            )
        if recovery_idx < 0 or recovery_idx >= len(route):
            raise ValueError(
                f"drone task {task['task_id']} recovery_idx {recovery_idx} "
                f"outside truck route length {len(route)}"
            )
        if launch_idx >= recovery_idx:
            raise ValueError(
                f"drone task {task['task_id']} launch_idx must be before recovery_idx"
            )
        if route[launch_idx] != task["launch_node"]:
            raise ValueError(
                f"drone task {task['task_id']} launch_idx points to "
                f"{route[launch_idx]}, expected {task['launch_node']}"
            )
        if route[recovery_idx] != task["recovery_node"]:
            raise ValueError(
                f"drone task {task['task_id']} recovery_idx points to "
                f"{route[recovery_idx]}, expected {task['recovery_node']}"
            )
        current_anchor_position = len(truck_states[truck_id].locked_prefix) - 1
        task_cut_time = truck_states[truck_id].anchor_time
        if launch_time <= task_cut_time < recovery_time:
            raise ValueError(
                f"truck {truck_id} anchor_time {task_cut_time} falls inside "
                f"airborne drone task {task['task_id']}"
            )
        if launch_idx <= current_anchor_position and launch_time > task_cut_time:
            raise ValueError(
                f"drone task {task['task_id']} launch_idx {launch_idx} is inside "
                f"the locked prefix ending at {current_anchor_position}, but "
                f"launch_time {launch_time} is after truck anchor_time {task_cut_time}"
            )
        if recovery_idx <= current_anchor_position and recovery_time > task_cut_time:
            raise ValueError(
                f"drone task {task['task_id']} recovery_idx {recovery_idx} is inside "
                f"the locked prefix ending at {current_anchor_position}, but "
                f"recovery_time {recovery_time} is after truck anchor_time {task_cut_time}"
            )

        if recovery_time <= task_cut_time:
            locked_drone_task_ids.add(task["task_id"])
            completed_customer_ids.add(task["customer"])
            for required_key in ("truck_id", "recovery_idx", "recovery_node"):
                if required_key not in task:
                    raise ValueError(
                        f"locked drone task {task['task_id']} missing required key: "
                        f"{required_key}"
                    )
            timeline_by_position = truck_timeline_by_truck[truck_id]
            if recovery_idx < 0 or recovery_idx >= len(route):
                raise ValueError(
                    f"locked drone task {task['task_id']} recovery_idx {recovery_idx} "
                    f"outside truck route length {len(route)}"
                )
            if route[recovery_idx] != task["recovery_node"]:
                raise ValueError(
                    f"locked drone task {task['task_id']} recovery_idx points to "
                    f"{route[recovery_idx]}, expected {task['recovery_node']}"
                )
            current_anchor_position = len(truck_states[truck_id].locked_prefix) - 1
            if recovery_idx > current_anchor_position:
                recovery_record = timeline_by_position[recovery_idx]
                if recovery_record["node"] != task["recovery_node"]:
                    raise ValueError(
                        f"timeline recovery position {recovery_idx} node "
                        f"{recovery_record['node']} does not match task recovery_node "
                        f"{task['recovery_node']}"
                    )
                locked_prefix = route[: recovery_idx + 1]
                truck_completed_customer_ids = {
                    node
                    for node in locked_prefix
                    if node in customers
                }
                completed_customer_ids.update(truck_completed_customer_ids)
                previous_state = truck_states[truck_id]
                truck_states[truck_id] = TruckReplanState(
                    truck_id=truck_id,
                    anchor_node=task["recovery_node"],
                    anchor_position=recovery_idx,
                    anchor_time=recovery_record["departure_time"],
                    remaining_basic_load=recovery_record["remaining_basic_load"],
                    remaining_emergency_load=recovery_record["remaining_emergency_load"],
                    locked_prefix=locked_prefix,
                    onboard_drone_ids=list(previous_state.onboard_drone_ids),
                    completed_customer_ids=truck_completed_customer_ids,
                )
        elif launch_time > task_cut_time:
            pass
        else:
            raise ValueError(
                f"drone task {task['task_id']} has inconsistent timing"
            )

    drone_states = {}
    for truck_id, drone_ids in drone_ids_by_truck.items():
        if truck_id not in truck_routes:
            raise ValueError(f"drone_ids_by_truck references unknown truck_id {truck_id}")
        for drone_id in drone_ids:
            if drone_id in drone_states:
                raise ValueError(f"duplicate drone_id in drone_ids_by_truck: {drone_id}")
            drone_states[drone_id] = DroneReplanState(
                truck_id=truck_id,
                drone_id=drone_id,
                status="onboard",
            )

    all_served_or_planned_customer_ids = {
        node
        for route in truck_routes.values()
        for node in route
        if node in customers
    }
    all_served_or_planned_customer_ids.update(
        task["customer"]
        for task in drone_routes
    )

    unfinished_customer_ids = (
        all_served_or_planned_customer_ids
        - completed_customer_ids
    )

    return {
        "trigger_time": trigger_time,
        "truck_states": truck_states,
        "drone_states": drone_states,
        "completed_customer_ids": completed_customer_ids,
        "locked_customer_ids": set(completed_customer_ids),
        "locked_drone_task_ids": locked_drone_task_ids,
        "unfinished_customer_ids": unfinished_customer_ids,
    }


def build_replan_context_from_solution(
    solution_data: Dict[str, Any],
    customers: Dict[int, Dict[str, Any]],
    adjusted_trigger_time: float,
    phase_index: int,
    trigger_reason: str,
    revealed_customer_ids: Set[int],
    newly_revealed_customer_ids: Set[int],
    future_dynamic_customer_ids: Set[int],
    drone_ids_by_truck: Dict[int, List[int]],
    replenishment_node: int = 999,
) -> ReplanContext:
    """从当前方案和安全触发时刻构造重规划上下文。"""

    split_result = split_solution_at_trigger(
        solution_data=solution_data,
        customers=customers,
        trigger_time=adjusted_trigger_time,
        drone_ids_by_truck=drone_ids_by_truck,
        replenishment_node=replenishment_node,
    )
    return ReplanContext(
        phase_index=phase_index,
        phase_start_time=adjusted_trigger_time,
        trigger_reason=trigger_reason,
        revealed_customer_ids=revealed_customer_ids,
        newly_revealed_customer_ids=newly_revealed_customer_ids,
        future_dynamic_customer_ids=future_dynamic_customer_ids,
        completed_customer_ids=split_result["completed_customer_ids"],
        locked_customer_ids=split_result["locked_customer_ids"],
        locked_drone_task_ids=split_result["locked_drone_task_ids"],
        truck_states=split_result["truck_states"],
        drone_states=split_result["drone_states"],
    )


def build_phase_initial_solution(
    previous_solution: "Solution",
    context: ReplanContext,
    customers: Dict[int, Dict[str, Any]],
    depot_end: int,
) -> "Solution":
    """根据上一阶段的解 previous_solution 和第 3 步生成的重规划上下文 context，构造当前 Phase 的“最小活动后缀解”。"""

    if not hasattr(previous_solution, "data"):
        raise TypeError("previous_solution must expose data")
    previous_data = previous_solution.data
    required_previous_keys = {
        "truck_routes",
        "drone_routes",
        "next_drone_task_id",
        "unserved",
    }
    missing_previous_keys = required_previous_keys - set(previous_data)
    if missing_previous_keys:
        raise ValueError(
            f"previous_solution missing required keys: {sorted(missing_previous_keys)}"
        )
    if not isinstance(previous_data["truck_routes"], dict):
        raise TypeError('previous_solution.data["truck_routes"] must be a dict')
    if not isinstance(previous_data["drone_routes"], list):
        raise TypeError('previous_solution.data["drone_routes"] must be a list')
    if not isinstance(previous_data["next_drone_task_id"], int):
        raise TypeError('previous_solution.data["next_drone_task_id"] must be an int')
    if not isinstance(previous_data["unserved"], list):
        raise TypeError('previous_solution.data["unserved"] must be a list')

    planned_customer_ids: Set[int] = set()
    for truck_id, route in previous_data["truck_routes"].items():
        if not isinstance(route, list):
            raise TypeError(f"truck route of truck {truck_id} must be a list")
        for node in route:
            if node in customers:
                planned_customer_ids.add(node)

    for task_index, task in enumerate(previous_data["drone_routes"]):
        if not isinstance(task, dict):
            raise TypeError(f"drone task {task_index} must be a dict")
        if "customer" not in task:
            raise ValueError(f"drone task {task_index} missing required key: customer")
        if task["customer"] not in customers:
            raise ValueError(
                f"drone task {task_index} references unknown customer "
                f"{task['customer']}"
            )
        planned_customer_ids.add(task["customer"])

    previous_unserved_customer_ids = set(previous_data["unserved"])
    for customer_id in previous_unserved_customer_ids:
        if isinstance(customer_id, bool) or not isinstance(customer_id, int):
            raise TypeError(
                f"previous unserved customer id must be int, "
                f"got {type(customer_id).__name__}"
            )
        if customer_id not in customers:
            raise ValueError(f"previous unserved customer {customer_id} is unknown")
    unfinished_old_customer_ids = planned_customer_ids - context.completed_customer_ids
    repair_pool = unfinished_old_customer_ids | context.newly_revealed_customer_ids
    repair_pool |= previous_unserved_customer_ids#把上一阶段还没服务的客户加入当前阶段的修复池 repair_pool。

    if repair_pool & context.completed_customer_ids:
        raise ValueError("repair_pool contains completed customers")
    if repair_pool & context.future_dynamic_customer_ids:
        raise ValueError("repair_pool contains future dynamic customers")
    #每辆卡车建立最小活动路径
    truck_routes = {}
    truck_routes = {}
    phase_start_state_by_truck = {}
    phase_route_customer_ids: Set[int] = set()
    phase_route_customer_owner: Dict[int, int] = {}
    for truck_id, truck_state in context.truck_states.items():
        if truck_id not in previous_data["truck_routes"]:
            raise ValueError(f"previous truck_routes missing truck_id {truck_id}")
        previous_route = previous_data["truck_routes"][truck_id]
        if not isinstance(previous_route, list):
            raise TypeError(f"previous route of truck {truck_id} must be a list")

        anchor_position = truck_state.anchor_position
        if anchor_position >= len(previous_route):
            raise ValueError(
                f"truck {truck_id} anchor_position {anchor_position} outside "
                f"previous route length {len(previous_route)}"
            )
        if previous_route[anchor_position] != truck_state.anchor_node:
            raise ValueError(
                f"truck {truck_id} anchor_position {anchor_position} points to "
                f"{previous_route[anchor_position]}, expected {truck_state.anchor_node}"
            )
        if previous_route[: anchor_position + 1] != truck_state.locked_prefix:
            raise ValueError(
                f"truck {truck_id} locked_prefix does not match previous route "
                f"prefix ending at anchor_position {anchor_position}"
            )
        if truck_state.anchor_node == depot_end:
            if previous_route[anchor_position:] != [depot_end]:
                raise ValueError(
                    f"completed truck {truck_id} anchor at depot_end must have no "
                    f"remaining suffix, got {previous_route[anchor_position:]}"
                )
            phase_route = [depot_end]
        else:
            phase_route = list(previous_route[anchor_position:])
            if not phase_route:
                raise ValueError(f"truck {truck_id} phase suffix must not be empty")
            if phase_route[0] != truck_state.anchor_node:
                raise ValueError(
                    f"truck {truck_id} phase suffix must start from anchor_node "
                    f"{truck_state.anchor_node}, got {phase_route[0]}"
                )
            if phase_route[-1] != depot_end:
                raise ValueError(
                    f"truck {truck_id} phase suffix must end at depot_end "
                    f"{depot_end}, got {phase_route[-1]}"
                )
        truck_routes[truck_id] = phase_route
        for position, node in enumerate(phase_route):
            if position == 0 and node == truck_state.anchor_node:
                continue
            if node in context.locked_customer_ids:
                raise ValueError(
                    f"truck {truck_id} phase suffix contains locked customer "
                    f"{node} outside anchor"
                )
            if node in context.future_dynamic_customer_ids:
                raise ValueError(
                    f"truck {truck_id} phase suffix contains future dynamic "
                    f"customer {node}"
                )
            if node in customers:
                if node in phase_route_customer_owner:
                    raise ValueError(
                        f"customer {node} appears in multiple phase truck routes: "
                        f"truck {phase_route_customer_owner[node]} and truck {truck_id}"
                    )
                phase_route_customer_owner[node] = truck_id
                phase_route_customer_ids.add(node)
        phase_start_state_by_truck[truck_id] = {
            "anchor_node": truck_state.anchor_node,
            "anchor_time": truck_state.anchor_time,
            "initial_basic_load": truck_state.remaining_basic_load,
            "initial_emergency_load": truck_state.remaining_emergency_load,
        }

    phase_drone_routes = []
    phase_drone_customer_ids: Set[int] = set()
    seen_previous_task_ids: Set[int] = set()
    for task_index, task in enumerate(previous_data["drone_routes"]):
        if not isinstance(task, dict):
            raise TypeError(f"drone task {task_index} must be a dict")
        required_task_keys = {
            "task_id",
            "truck_id",
            "launch_node",
            "launch_idx",
            "customer",
            "recovery_node",
            "recovery_idx",
        }
        missing_task_keys = required_task_keys - set(task)
        if missing_task_keys:
            raise ValueError(
                f"drone task {task_index} missing required keys before phase "
                f"suffix preservation: {sorted(missing_task_keys)}"
            )
        task_id = task["task_id"]
        if isinstance(task_id, bool) or not isinstance(task_id, int):
            raise TypeError(
                f"drone task {task_index} task_id must be int, "
                f"got {type(task_id).__name__}"
            )
        if task_id in seen_previous_task_ids:
            raise ValueError(f"duplicate previous drone task_id {task_id}")
        seen_previous_task_ids.add(task_id)
        if task_id in context.locked_drone_task_ids:
            continue

        truck_id = task["truck_id"]
        if truck_id not in context.truck_states:
            raise ValueError(
                f"unlocked drone task {task_id} references unknown truck_id {truck_id}"
            )
        launch_idx = task["launch_idx"]
        recovery_idx = task["recovery_idx"]
        for key, value in (("launch_idx", launch_idx), ("recovery_idx", recovery_idx)):
            if isinstance(value, bool) or not isinstance(value, int):
                raise TypeError(
                    f"drone task {task_id} {key} must be int, "
                    f"got {type(value).__name__}"
                )
        anchor_position = context.truck_states[truck_id].anchor_position
        if launch_idx < anchor_position < recovery_idx:
            raise ValueError(
                f"drone task {task_id} crosses phase split point: "
                f"launch_idx={launch_idx}, anchor_position={anchor_position}, "
                f"recovery_idx={recovery_idx}"
            )
        if launch_idx < anchor_position or recovery_idx < anchor_position:
            raise ValueError(
                f"unlocked drone task {task_id} lies before phase anchor "
                f"{anchor_position}"
            )

        phase_task = copy.deepcopy(task)
        phase_task["launch_idx"] = launch_idx - anchor_position
        phase_task["recovery_idx"] = recovery_idx - anchor_position
        phase_route = truck_routes[truck_id]
        if phase_task["launch_idx"] < 0 or phase_task["launch_idx"] >= len(phase_route):
            raise ValueError(
                f"phase drone task {task_id} launch_idx {phase_task['launch_idx']} "
                f"outside truck {truck_id} phase route length {len(phase_route)}"
            )
        if (
            phase_task["recovery_idx"] < 0
            or phase_task["recovery_idx"] >= len(phase_route)
        ):
            raise ValueError(
                f"phase drone task {task_id} recovery_idx "
                f"{phase_task['recovery_idx']} outside truck {truck_id} phase "
                f"route length {len(phase_route)}"
            )
        if phase_route[phase_task["launch_idx"]] != phase_task["launch_node"]:
            raise ValueError(
                f"phase drone task {task_id} launch_idx points to "
                f"{phase_route[phase_task['launch_idx']]}, expected "
                f"{phase_task['launch_node']}"
            )
        if phase_route[phase_task["recovery_idx"]] != phase_task["recovery_node"]:
            raise ValueError(
                f"phase drone task {task_id} recovery_idx points to "
                f"{phase_route[phase_task['recovery_idx']]}, expected "
                f"{phase_task['recovery_node']}"
            )

        customer_id = phase_task["customer"]
        if customer_id in context.locked_customer_ids:
            raise ValueError(
                f"phase drone task {task_id} serves locked customer {customer_id}"
            )
        if customer_id in context.future_dynamic_customer_ids:
            raise ValueError(
                f"phase drone task {task_id} serves future dynamic customer "
                f"{customer_id}"
            )
        if customer_id in phase_route_customer_ids:
            raise ValueError(
                f"phase drone task {task_id} duplicates truck-served customer "
                f"{customer_id}"
            )
        if customer_id in phase_drone_customer_ids:
            raise ValueError(
                f"customer {customer_id} appears in multiple phase drone tasks"
            )
        phase_drone_customer_ids.add(customer_id)
        phase_drone_routes.append(phase_task)

    phase_served_customer_ids = phase_route_customer_ids | phase_drone_customer_ids
    retained_old_customer_ids = phase_served_customer_ids & unfinished_old_customer_ids
    unexpected_phase_served = phase_served_customer_ids - unfinished_old_customer_ids
    if unexpected_phase_served:
        raise ValueError(
            "phase suffix contains customers that are not unfinished old "
            f"customers: {sorted(unexpected_phase_served)}"
        )

    repair_pool = (
        (unfinished_old_customer_ids - retained_old_customer_ids)
        | context.newly_revealed_customer_ids
        | previous_unserved_customer_ids
    )
    if repair_pool & context.completed_customer_ids:
        raise ValueError("repair_pool contains completed customers")
    if repair_pool & context.future_dynamic_customer_ids:
        raise ValueError("repair_pool contains future dynamic customers")
    if repair_pool & phase_served_customer_ids:
        raise ValueError(
            f"repair_pool contains phase-served customers: "
            f"{sorted(repair_pool & phase_served_customer_ids)}"
        )

    phase_solution_data = {
        "truck_routes": truck_routes,
        "drone_routes": phase_drone_routes,
        "next_drone_task_id": previous_data["next_drone_task_id"],
        "phase_start_state_by_truck": phase_start_state_by_truck,
        "phase_completed_customer_ids": set(context.completed_customer_ids),
        "phase_locked_customer_ids": set(context.locked_customer_ids),
        "phase_locked_drone_task_ids": set(context.locked_drone_task_ids),
        "phase_future_dynamic_customer_ids": set(context.future_dynamic_customer_ids),
        "phase_repair_pool": set(repair_pool),
        "served": set(phase_served_customer_ids),
        "unserved": sorted(repair_pool),
        "cost": None,
        "feasible": None,
        "validation_report": {},
        "full_validation_report": {},
        "drone_period_usage": {},
        "segment_usage": {},
    }
    _reject_deprecated_replenishment_in_replanning_solution(
        solution_data=phase_solution_data,
        scope="build_phase_initial_solution",
    )

    return previous_solution.__class__(phase_solution_data)


def validate_phase_solution_semantics(
    phase_solution: "Solution",
    context: ReplanContext,
) -> Dict[str, Any]:
    """检查“这是不是合法的重规划后缀解”"""

    if not hasattr(phase_solution, "data"):
        raise TypeError("phase_solution must expose data")
    data = phase_solution.data
    required_keys = {
        "truck_routes",
        "drone_routes",
        "served",
        "unserved",
        "phase_start_state_by_truck",
        "phase_completed_customer_ids",
        "phase_locked_customer_ids",
        "phase_future_dynamic_customer_ids",
    }
    missing_keys = required_keys - set(data)
    if missing_keys:
        raise ValueError(f"phase_solution missing required keys: {sorted(missing_keys)}")

    violations = []
    try:
        _reject_deprecated_replenishment_in_replanning_solution(
            solution_data=data,
            scope="validate_phase_solution_semantics",
        )
    except ValueError as exc:
        violations.append(str(exc))
    completed_customer_ids = data["phase_completed_customer_ids"]
    locked_customer_ids = data["phase_locked_customer_ids"]
    future_dynamic_customer_ids = data["phase_future_dynamic_customer_ids"]
    served = data["served"]
    unserved = set(data["unserved"])

    if completed_customer_ids != context.completed_customer_ids:
        violations.append("phase_completed_customer_ids differ from context")
    if locked_customer_ids != context.locked_customer_ids:
        violations.append("phase_locked_customer_ids differ from context")
    if future_dynamic_customer_ids != context.future_dynamic_customer_ids:
        violations.append("phase_future_dynamic_customer_ids differ from context")
    if served & completed_customer_ids:
        violations.append(
            f"phase served contains completed customers: {sorted(served & completed_customer_ids)}"
        )
    if unserved & completed_customer_ids:
        violations.append(
            f"phase unserved contains completed customers: {sorted(unserved & completed_customer_ids)}"
        )
    if served & future_dynamic_customer_ids:
        violations.append(
            f"phase served contains future dynamic customers: {sorted(served & future_dynamic_customer_ids)}"
        )
    if unserved & future_dynamic_customer_ids:
        violations.append(
            f"phase unserved contains future dynamic customers: {sorted(unserved & future_dynamic_customer_ids)}"
        )

    for truck_id, truck_state in context.truck_states.items():
        if truck_id not in data["truck_routes"]:
            violations.append(f"truck_routes missing truck_id {truck_id}")
            continue
        route = data["truck_routes"][truck_id]
        if not route:
            violations.append(f"truck route of truck {truck_id} is empty")
            continue
        if route[0] != truck_state.anchor_node:
            violations.append(
                f"truck {truck_id} route must start from anchor_node "
                f"{truck_state.anchor_node}, got {route[0]}"
            )
        if truck_state.anchor_node == route[-1] and len(route) != 1:
            violations.append(
                f"completed truck {truck_id} phase route must remain "
                f"[{truck_state.anchor_node}], got {route}"
            )
        for position, node in enumerate(route):
            if position == 0 and node == truck_state.anchor_node:
                continue
            if node in locked_customer_ids:
                violations.append(
                    f"truck {truck_id} route contains locked customer {node} "
                    f"outside anchor"
                )

    for task_index, task in enumerate(data["drone_routes"]):
        if "task_id" not in task:
            raise ValueError(f"drone task {task_index} missing required key: task_id")
        if "customer" not in task:
            raise ValueError(f"drone task {task_index} missing required key: customer")
        if task["task_id"] in context.locked_drone_task_ids:
            violations.append(f"phase drone route contains locked task_id {task['task_id']}")
        if task["customer"] in locked_customer_ids:
            violations.append(
                f"phase drone route contains locked customer {task['customer']}"
            )
        if task["customer"] in future_dynamic_customer_ids:
            violations.append(
                f"phase drone route contains future dynamic customer {task['customer']}"
            )

    return {
        "valid": len(violations) == 0,
        "violations": violations,
    }


def _count_rejected_insert_moves_by_customer(
    rejected_insert_moves: List[Dict[str, Any]],
) -> Dict[int, Dict[str, Any]]:
    def flatten_failure_details(move: Dict[str, Any]) -> List[str]:
        details = move.get("post_rebuild_failure_details")
        if details is None:
            return []
        if not isinstance(details, dict):
            raise TypeError("post_rebuild_failure_details must be a dict or None")
        flattened = []
        for detail_key in (
            "full_validation_violations",
            "truck_evaluation_violations",
            "lightweight_violations",
        ):
            if detail_key not in details:
                continue
            detail_values = details[detail_key]
            if not isinstance(detail_values, list):
                raise TypeError(
                    f'post_rebuild_failure_details["{detail_key}"] must be a list'
                )
            for value in detail_values:
                flattened.append(f"{detail_key}: {value}")
        return flattened

    result: Dict[int, Dict[str, Any]] = {}
    for move_index, move in enumerate(rejected_insert_moves):
        if not isinstance(move, dict):
            raise TypeError(f"rejected insert move {move_index} must be a dict")
        if "customer" not in move:
            raise ValueError(
                f"rejected insert move {move_index} missing required key: customer"
            )
        if "mode" not in move:
            raise ValueError(
                f"rejected insert move {move_index} missing required key: mode"
            )
        if "reason" not in move:
            raise ValueError(
                f"rejected insert move {move_index} missing required key: reason"
            )
        customer_id = move["customer"]
        if isinstance(customer_id, bool) or not isinstance(customer_id, int):
            raise TypeError(
                f"rejected insert move customer must be int, "
                f"got {type(customer_id).__name__}"
            )
        if customer_id not in result:
            result[customer_id] = {
                "rejected_count": 0,
                "rejected_reason_counts": {},
                "rejected_mode_counts": {},
                "rejected_detail_counts": {},
                "rejected_detail_examples": [],
            }
        item = result[customer_id]
        item["rejected_count"] += 1
        reason = move["reason"]
        mode = move["mode"]
        item["rejected_reason_counts"][reason] = (
            item["rejected_reason_counts"].get(reason, 0) + 1
        )
        item["rejected_mode_counts"][mode] = (
            item["rejected_mode_counts"].get(mode, 0) + 1
        )
        detail_messages = flatten_failure_details(move)
        if reason == "post_rebuild_infeasible" and not detail_messages:
            detail_messages = [
                "post_rebuild_infeasible: no validation detail recorded"
            ]
        for detail_message in detail_messages:
            item["rejected_detail_counts"][detail_message] = (
                item["rejected_detail_counts"].get(detail_message, 0) + 1
            )
            if (
                detail_message not in item["rejected_detail_examples"]
                and len(item["rejected_detail_examples"]) < 5
            ):
                item["rejected_detail_examples"].append(detail_message)
    return result


def _build_remaining_unserved_diagnostics(
    phase_solution: "Solution",
    context: ReplanContext,
    customers: Dict[int, Dict[str, Any]],
    alns: Any,
    initial_repair_pool: Set[int],
    repair_context: Dict[str, Any],
) -> List[Dict[str, Any]]:
    if not hasattr(phase_solution, "data"):
        raise TypeError("phase_solution must expose data")
    if "unserved" not in phase_solution.data:
        raise ValueError('phase_solution.data missing required key: unserved')
    if "phase_repair_pool" not in phase_solution.data:
        raise ValueError('phase_solution.data missing required key: phase_repair_pool')
    if not isinstance(phase_solution.data["unserved"], list):
        raise TypeError('phase_solution.data["unserved"] must be a list')
    if not isinstance(phase_solution.data["phase_repair_pool"], set):
        raise TypeError('phase_solution.data["phase_repair_pool"] must be a set')
    if not isinstance(initial_repair_pool, set):
        raise TypeError("initial_repair_pool must be a set")
    if "rejected_insert_moves" not in repair_context:
        raise ValueError("repair_context missing required key: rejected_insert_moves")
    if not isinstance(repair_context["rejected_insert_moves"], list):
        raise TypeError('repair_context["rejected_insert_moves"] must be a list')
    if not hasattr(alns, "_all_truck_insert_deltas"):
        raise TypeError("alns must expose _all_truck_insert_deltas")

    rejected_by_customer = _count_rejected_insert_moves_by_customer(
        repair_context["rejected_insert_moves"]
    )
    drone_insertions_enabled = bool(getattr(alns, "allow_drone_insertions", False))
    if drone_insertions_enabled and not hasattr(alns, "_all_drone_insert_deltas"):
        raise TypeError(
            "alns must expose _all_drone_insert_deltas when drone insertions are enabled"
        )

    diagnostics = []
    for customer_id in phase_solution.data["unserved"]:
        if isinstance(customer_id, bool) or not isinstance(customer_id, int):
            raise TypeError(
                f"unserved customer id must be int, got {type(customer_id).__name__}"
            )
        if customer_id not in customers:
            raise ValueError(f"unserved customer {customer_id} is not in customers")
        customer = customers[customer_id]
        if "is_static" not in customer:
            raise ValueError(f"customer {customer_id} missing required key: is_static")
        if not isinstance(customer["is_static"], bool):
            raise TypeError(
                f'customers[{customer_id}]["is_static"] must be bool, '
                f"got {type(customer['is_static']).__name__}"
            )

        truck_moves = alns._all_truck_insert_deltas(phase_solution, customer_id)
        if not isinstance(truck_moves, list):
            raise TypeError(
                f"_all_truck_insert_deltas must return a list for customer "
                f"{customer_id}"
            )
        drone_moves = []
        if drone_insertions_enabled:
            drone_moves = alns._all_drone_insert_deltas(phase_solution, customer_id)
            if not isinstance(drone_moves, list):
                raise TypeError(
                    f"_all_drone_insert_deltas must return a list for customer "
                    f"{customer_id}"
                )

        rejected_summary = rejected_by_customer.get(
            customer_id,
            {
                "rejected_count": 0,
                "rejected_reason_counts": {},
                "rejected_mode_counts": {},
                "rejected_detail_counts": {},
                "rejected_detail_examples": [],
            },
        )
        diagnostics.append(
            {
                "customer": customer_id,
                "is_static": customer["is_static"],
                "in_initial_repair_pool": customer_id in initial_repair_pool,
                "in_phase_repair_pool": (
                    customer_id in phase_solution.data["phase_repair_pool"]
                ),
                "newly_revealed": customer_id in context.newly_revealed_customer_ids,
                "future_dynamic": customer_id in context.future_dynamic_customer_ids,
                "locked_or_completed": customer_id in context.locked_customer_ids,
                "truck_candidate_count": len(truck_moves),
                "drone_candidate_count": len(drone_moves),
                "drone_insertions_enabled": drone_insertions_enabled,
                "initial_repair_rejected_count": rejected_summary["rejected_count"],
                "initial_repair_rejected_reason_counts": dict(
                    rejected_summary["rejected_reason_counts"]
                ),
                "initial_repair_rejected_mode_counts": dict(
                    rejected_summary["rejected_mode_counts"]
                ),
                "initial_repair_rejected_detail_counts": dict(
                    rejected_summary["rejected_detail_counts"]
                ),
                "initial_repair_rejected_detail_examples": list(
                    rejected_summary["rejected_detail_examples"]
                ),
            }
        )

    return diagnostics


def solve_replanning_phase(
    previous_solution: "Solution",
    context: ReplanContext,
    customers: Dict[int, Dict[str, Any]],
    depot_end: int,
    alns: Any,
    iters: int,
    x_remove: float | None = 0.15,
    temp_init: float = 100.0,
    temp_final: float = 1.0,
    normalize_every: int = 50,
    stage_breaks: tuple[float, float] = (0.3, 0.7),
    verbose: bool = False,
) -> tuple["Solution", Dict[str, Any]]:
    """以 build_phase_initial_solution(...) 生成的最小活动后缀解为起点，
调用现有 ALNS，求当前重规划 Phase 的较优后缀解。"""

    if iters < 0:
        raise ValueError(f"iters must be non-negative, got {iters}")

    phase_solution = build_phase_initial_solution(
        previous_solution=previous_solution,
        context=context,
        customers=customers,
        depot_end=depot_end,
    )
    alns._rebuild_solution(phase_solution)

    previous_validator = getattr(alns, "phase_candidate_validator", None)

    def merged_phase_candidate_validator(candidate_solution: "Solution") -> Dict[str, Any]:
        return validate_merged_phase_candidate(
            previous_solution=previous_solution,
            phase_solution=candidate_solution,
            context=context,
            depot_end=depot_end,
            alns=alns,
            customers=customers,
        )

    alns.phase_candidate_validator = merged_phase_candidate_validator
    try:
        repair_context = {
            "rejected_insert_moves": [],
            "phase_index": context.phase_index,
            "phase_start_time": context.phase_start_time,
        }
        initial_repair_pool = set(phase_solution.data["unserved"])
        phase_solution = alns._repair_greedy(
            phase_solution,
            initial_repair_pool,
            repair_context,
        )
        alns._rebuild_solution(phase_solution)
        if phase_solution.data["feasible"] is not True:
            raise ValueError(
                "phase solution infeasible after initial repair: "
                f"{phase_solution.data['full_validation_report']}"
            )

        initial_semantics = validate_phase_solution_semantics(
            phase_solution=phase_solution,
            context=context,
        )
        if not initial_semantics["valid"]:
            raise ValueError(f"phase solution invalid before ALNS: {initial_semantics}")
        initial_merge_validation = validate_merged_phase_candidate(
            previous_solution=previous_solution,
            phase_solution=phase_solution,
            context=context,
            depot_end=depot_end,
            alns=alns,
            customers=customers,
        )
        if not initial_merge_validation["valid"]:
            raise ValueError(
                "phase solution invalid in merged semantics before ALNS: "
                f"{initial_merge_validation}"
            )

        phase_best_solution = alns.solve(
            init=phase_solution,
            iters=iters,
            x_remove=x_remove,
            temp_init=temp_init,
            temp_final=temp_final,
            normalize_every=normalize_every,
            stage_breaks=stage_breaks,
            verbose=verbose,
        )
    finally:
        alns.phase_candidate_validator = previous_validator
    alns._rebuild_solution(phase_best_solution)
    if phase_best_solution.data["feasible"] is not True:
        raise ValueError(
            "phase solution infeasible after ALNS: "
            f"{phase_best_solution.data['full_validation_report']}"
        )

    final_semantics = validate_phase_solution_semantics(
        phase_solution=phase_best_solution,
        context=context,
    )
    if not final_semantics["valid"]:
        raise ValueError(f"phase solution invalid after ALNS: {final_semantics}")
    final_merge_validation = validate_merged_phase_candidate(
        previous_solution=previous_solution,
        phase_solution=phase_best_solution,
        context=context,
        depot_end=depot_end,
        alns=alns,
        customers=customers,
    )
    if not final_merge_validation["valid"]:
        raise ValueError(
            "phase solution cannot be merged after ALNS: "
            f"{final_merge_validation['full_validation_report']}; "
            f"truck_routes={final_merge_validation['truck_routes']}"
        )
    remaining_unserved_diagnostics = _build_remaining_unserved_diagnostics(
        phase_solution=phase_best_solution,
        context=context,
        customers=customers,
        alns=alns,
        initial_repair_pool=initial_repair_pool,
        repair_context=repair_context,
    )

    report = {
        "phase_index": context.phase_index,
        "phase_start_time": context.phase_start_time,
        "trigger_reason": context.trigger_reason,
        "anchor_by_truck": {
            truck_id: truck_state.anchor_node
            for truck_id, truck_state in context.truck_states.items()
        },
        "initial_repair_pool": sorted(initial_repair_pool),
        "served_in_phase": sorted(phase_best_solution.data["served"]),
        "remaining_unserved": list(phase_best_solution.data["unserved"]),
        "remaining_unserved_diagnostics": remaining_unserved_diagnostics,
        "phase_cost": phase_best_solution.data["cost"],
        "feasible": phase_best_solution.data["feasible"],
        "semantic_valid": final_semantics["valid"],
        "semantic_violations": final_semantics["violations"],
        "initial_merge_valid": initial_merge_validation["valid"],
        "initial_merge_violations": initial_merge_validation["violations"],
        "merge_valid": final_merge_validation["valid"],
        "merge_violations": final_merge_validation["violations"],
        "rejected_insert_moves_count": len(repair_context["rejected_insert_moves"]),
        "rejected_phase_candidate_count": getattr(
            alns,
            "rejected_phase_candidate_count",
            0,
        ),
    }

    return phase_best_solution, report


def merge_replanning_phase_solution(
    previous_solution: "Solution",
    phase_solution: "Solution",
    context: ReplanContext,
    depot_end: int,
) -> "Solution":
    """Merge one solved replanning suffix back into a complete route solution."""

    if not hasattr(previous_solution, "data"):
        raise TypeError("previous_solution must expose data")
    if not hasattr(phase_solution, "data"):
        raise TypeError("phase_solution must expose data")

    previous_data = previous_solution.data
    phase_data = phase_solution.data
    required_previous_keys = {
        "truck_routes",
        "drone_routes",
        "next_drone_task_id",
        "phase_start_state_by_truck",
    }
    required_phase_keys = {
        "truck_routes",
        "drone_routes",
        "next_drone_task_id",
        "unserved",
    }
    missing_previous_keys = required_previous_keys - set(previous_data)
    if missing_previous_keys:
        raise ValueError(
            f"previous_solution missing required keys: {sorted(missing_previous_keys)}"
        )
    missing_phase_keys = required_phase_keys - set(phase_data)
    if missing_phase_keys:
        raise ValueError(
            f"phase_solution missing required keys: {sorted(missing_phase_keys)}"
        )
    if not isinstance(previous_data["truck_routes"], dict):
        raise TypeError('previous_solution.data["truck_routes"] must be a dict')
    if not isinstance(previous_data["drone_routes"], list):
        raise TypeError('previous_solution.data["drone_routes"] must be a list')
    if not isinstance(previous_data["phase_start_state_by_truck"], dict):
        raise TypeError(
            'previous_solution.data["phase_start_state_by_truck"] must be a dict'
        )
    if not isinstance(phase_data["truck_routes"], dict):
        raise TypeError('phase_solution.data["truck_routes"] must be a dict')
    if not isinstance(phase_data["drone_routes"], list):
        raise TypeError('phase_solution.data["drone_routes"] must be a list')
    if not isinstance(phase_data["unserved"], list):
        raise TypeError('phase_solution.data["unserved"] must be a list')
    if isinstance(previous_data["next_drone_task_id"], bool) or not isinstance(
        previous_data["next_drone_task_id"],
        int,
    ):
        raise TypeError('previous_solution.data["next_drone_task_id"] must be an int')
    if isinstance(phase_data["next_drone_task_id"], bool) or not isinstance(
        phase_data["next_drone_task_id"],
        int,
    ):
        raise TypeError('phase_solution.data["next_drone_task_id"] must be an int')
    _reject_deprecated_replenishment_in_replanning_solution(
        solution_data=previous_data,
        scope="merge_replanning_phase_solution.previous_solution",
    )
    _reject_deprecated_replenishment_in_replanning_solution(
        solution_data=phase_data,
        scope="merge_replanning_phase_solution.phase_solution",
    )

    previous_truck_ids = set(previous_data["truck_routes"])
    phase_truck_ids = set(phase_data["truck_routes"])
    context_truck_ids = set(context.truck_states)
    if previous_truck_ids != phase_truck_ids:
        raise ValueError(
            "previous_solution and phase_solution truck_id sets differ: "
            f"{sorted(previous_truck_ids)} vs {sorted(phase_truck_ids)}"
        )
    if previous_truck_ids != context_truck_ids:
        raise ValueError(
            "solution truck_id set differs from context.truck_states: "
            f"{sorted(previous_truck_ids)} vs {sorted(context_truck_ids)}"
        )

    merged_truck_routes = {}
    index_shift_by_truck = {}
    for truck_id, truck_state in context.truck_states.items():
        locked_prefix = truck_state.locked_prefix
        phase_route = phase_data["truck_routes"][truck_id]
        if not isinstance(locked_prefix, list):
            raise TypeError(f"context truck {truck_id} locked_prefix must be a list")
        if not locked_prefix:
            raise ValueError(f"context truck {truck_id} locked_prefix must not be empty")
        if not isinstance(phase_route, list):
            raise TypeError(f"phase truck route of truck {truck_id} must be a list")
        if not phase_route:
            raise ValueError(f"phase truck route of truck {truck_id} must not be empty")
        if locked_prefix[-1] != truck_state.anchor_node:
            raise ValueError(
                f"truck {truck_id} locked_prefix must end at anchor_node "
                f"{truck_state.anchor_node}, got {locked_prefix[-1]}"
            )
        if phase_route[0] != truck_state.anchor_node:
            raise ValueError(
                f"phase truck {truck_id} route must start from anchor_node "
                f"{truck_state.anchor_node}, got {phase_route[0]}"
            )
        if truck_state.anchor_node == depot_end and phase_route != [depot_end]:
            raise ValueError(
                f"completed truck {truck_id} phase route must remain "
                f"[{depot_end}], got {phase_route}"
            )
        if phase_route[-1] != depot_end:
            raise ValueError(
                f"phase truck {truck_id} route must end at depot_end "
                f"{depot_end}, got {phase_route[-1]}"
            )
        repeated_locked_customers = set(phase_route[1:]) & context.locked_customer_ids
        if repeated_locked_customers:
            raise ValueError(
                f"phase truck {truck_id} route repeats locked customers: "
                f"{sorted(repeated_locked_customers)}"
            )

        index_shift = len(locked_prefix) - 1
        if index_shift < 0:
            raise ValueError(f"truck {truck_id} index_shift must be non-negative")
        index_shift_by_truck[truck_id] = index_shift
        merged_truck_routes[truck_id] = list(locked_prefix) + list(phase_route[1:])

    full_start_state_by_truck = previous_data["phase_start_state_by_truck"]
    for truck_id, merged_route in merged_truck_routes.items():
        if truck_id not in full_start_state_by_truck:
            raise ValueError(
                f'previous_solution.data["phase_start_state_by_truck"] '
                f"missing truck_id {truck_id}"
            )
        start_state = full_start_state_by_truck[truck_id]
        if not isinstance(start_state, dict):
            raise TypeError(
                f'previous_solution.data["phase_start_state_by_truck"][{truck_id}] '
                f"must be a dict"
            )
        required_start_state_keys = {
            "anchor_node",
            "anchor_time",
            "initial_basic_load",
            "initial_emergency_load",
        }
        missing_start_state_keys = required_start_state_keys - set(start_state)
        if missing_start_state_keys:
            raise ValueError(
                f'previous_solution.data["phase_start_state_by_truck"][{truck_id}] '
                f"missing required keys: {sorted(missing_start_state_keys)}"
            )
        if start_state["anchor_node"] != merged_route[0]:
            raise ValueError(
                f"full start state of truck {truck_id} must start at merged route "
                f"first node {merged_route[0]}, got {start_state['anchor_node']}"
            )

    locked_drone_tasks = []
    found_locked_task_ids = set()#在 previous_solution.data["drone_routes"] 里实际找到了哪些 locked 无人机任务 ID。
    for task_index, task in enumerate(previous_data["drone_routes"]):
        if not isinstance(task, dict):
            raise TypeError(f"previous drone task {task_index} must be a dict")
        if "task_id" not in task:
            raise ValueError(
                f"previous drone task {task_index} missing required key: task_id"
            )
        if task["task_id"] in context.locked_drone_task_ids:
            locked_drone_tasks.append(copy.deepcopy(task))
            found_locked_task_ids.add(task["task_id"])

    missing_locked_task_ids = context.locked_drone_task_ids - found_locked_task_ids
    if missing_locked_task_ids:
        raise ValueError(
            f"previous_solution missing locked drone task_ids: "
            f"{sorted(missing_locked_task_ids)}"
        )

    merged_drone_routes = locked_drone_tasks
    for task_index, task in enumerate(phase_data["drone_routes"]):
        if not isinstance(task, dict):
            raise TypeError(f"phase drone task {task_index} must be a dict")
        required_task_keys = {
            "task_id",
            "truck_id",
            "launch_node",
            "launch_idx",
            "customer",
            "recovery_node",
            "recovery_idx",
        }
        missing_task_keys = required_task_keys - set(task)
        if missing_task_keys:
            raise ValueError(
                f"phase drone task {task_index} missing required keys: "
                f"{sorted(missing_task_keys)}"
            )
        if task["task_id"] in context.locked_drone_task_ids:
            raise ValueError(
                f"phase drone task {task_index} reuses locked task_id {task['task_id']}"
            )
        if task["customer"] in context.locked_customer_ids:
            raise ValueError(
                f"phase drone task {task_index} serves locked customer {task['customer']}"
            )
        truck_id = task["truck_id"]
        if truck_id not in index_shift_by_truck:
            raise ValueError(
                f"phase drone task {task_index} references unknown truck_id {truck_id}"
            )
        launch_idx = task["launch_idx"]
        recovery_idx = task["recovery_idx"]
        if isinstance(launch_idx, bool) or not isinstance(launch_idx, int):
            raise TypeError(
                f"phase drone task {task_index} launch_idx must be int, "
                f"got {type(launch_idx).__name__}"
            )
        if isinstance(recovery_idx, bool) or not isinstance(recovery_idx, int):
            raise TypeError(
                f"phase drone task {task_index} recovery_idx must be int, "
                f"got {type(recovery_idx).__name__}"
            )
        phase_route = phase_data["truck_routes"][truck_id]
        if launch_idx < 0 or launch_idx >= len(phase_route):
            raise ValueError(
                f"phase drone task {task_index} launch_idx {launch_idx} "
                f"outside phase route length {len(phase_route)}"
            )
        if recovery_idx < 0 or recovery_idx >= len(phase_route):
            raise ValueError(
                f"phase drone task {task_index} recovery_idx {recovery_idx} "
                f"outside phase route length {len(phase_route)}"
            )
        if phase_route[launch_idx] != task["launch_node"]:
            raise ValueError(
                f"phase drone task {task_index} launch_idx points to "
                f"{phase_route[launch_idx]}, expected {task['launch_node']}"
            )
        if phase_route[recovery_idx] != task["recovery_node"]:
            raise ValueError(
                f"phase drone task {task_index} recovery_idx points to "
                f"{phase_route[recovery_idx]}, expected {task['recovery_node']}"
            )

        merged_task = copy.deepcopy(task)
        merged_task["launch_idx"] = launch_idx + index_shift_by_truck[truck_id]
        merged_task["recovery_idx"] = recovery_idx + index_shift_by_truck[truck_id]
        merged_route = merged_truck_routes[truck_id]
        if merged_task["launch_idx"] < 0 or merged_task["launch_idx"] >= len(merged_route):
            raise ValueError(
                f"merged drone task {task_index} launch_idx "
                f"{merged_task['launch_idx']} outside merged route length "
                f"{len(merged_route)}"
            )
        if (
            merged_task["recovery_idx"] < 0
            or merged_task["recovery_idx"] >= len(merged_route)
        ):
            raise ValueError(
                f"merged drone task {task_index} recovery_idx "
                f"{merged_task['recovery_idx']} outside merged route length "
                f"{len(merged_route)}"
            )
        if merged_route[merged_task["launch_idx"]] != merged_task["launch_node"]:
            raise ValueError(
                f"merged drone task {task_index} launch_idx points to "
                f"{merged_route[merged_task['launch_idx']]}, "
                f"expected {merged_task['launch_node']}"
            )
        if merged_route[merged_task["recovery_idx"]] != merged_task["recovery_node"]:
            raise ValueError(
                f"merged drone task {task_index} recovery_idx points to "
                f"{merged_route[merged_task['recovery_idx']]}, "
                f"expected {merged_task['recovery_node']}"
            )
        merged_drone_routes.append(merged_task)

    task_ids = []
    for task_index, task in enumerate(merged_drone_routes):
        if "task_id" not in task:
            raise ValueError(f"merged drone task {task_index} missing required key: task_id")
        task_ids.append(task["task_id"])
    duplicate_task_ids = {
        task_id
        for task_id in task_ids
        if task_ids.count(task_id) > 1
    }
    if duplicate_task_ids:
        raise ValueError(f"merged drone_routes duplicate task_ids: {sorted(duplicate_task_ids)}")

    merged_unserved = sorted(set(phase_data["unserved"]))
    repeated_locked_unserved = set(merged_unserved) & context.locked_customer_ids
    if repeated_locked_unserved:
        raise ValueError(
            f"phase unserved contains locked customers: {sorted(repeated_locked_unserved)}"
        )

    merged_data = {
        "truck_routes": merged_truck_routes,
        "drone_routes": merged_drone_routes,
        "next_drone_task_id": phase_data["next_drone_task_id"],
        "phase_start_state_by_truck": copy.deepcopy(
            previous_data["phase_start_state_by_truck"]
        ),
        "served": set(),
        "unserved": merged_unserved,
        "cost": None,
        "feasible": None,
        "validation_report": {},
        "full_validation_report": {},
        "drone_period_usage": {},
        "segment_usage": {},
    }
    _reject_deprecated_replenishment_in_replanning_solution(
        solution_data=merged_data,
        scope="merge_replanning_phase_solution.merged_solution",
    )

    return previous_solution.__class__(merged_data)


def validate_merged_phase_candidate(
    previous_solution: "Solution",
    phase_solution: "Solution",
    context: ReplanContext,
    depot_end: int,
    alns: Any,
    customers: Dict[int, Dict[str, Any]],
) -> Dict[str, Any]:
    """Validate a phase suffix after temporary merge into the full solution."""

    if not hasattr(alns, "_rebuild_solution"):
        raise TypeError("alns must expose _rebuild_solution")
    if not hasattr(alns, "depot_start"):
        raise ValueError("alns missing required attribute: depot_start")

    try:
        merged_solution = merge_replanning_phase_solution(
            previous_solution=previous_solution,
            phase_solution=phase_solution,
            context=context,
            depot_end=depot_end,
        )
    except ValueError as exc:
        if "deprecated replenishment node" not in str(exc):
            raise
        violations = [str(exc)]
        return {
            "valid": False,
            "merged_solution": None,
            "full_validation_report": {
                "valid": False,
                "feasible": False,
                "violations": violations,
                "warnings": [],
            },
            "violations": violations,
            "truck_routes": copy.deepcopy(phase_solution.data["truck_routes"]),
        }
    refresh_depot_phase_start_state(
        solution=merged_solution.data,
        customers=customers,
        depot_start=alns.depot_start,
    )
    alns._rebuild_solution(merged_solution, full_validate=True)

    for required_key in ("feasible", "cost", "unserved", "validation_report"):
        if required_key not in merged_solution.data:
            raise ValueError(
                f"merged candidate missing required key after rebuild: {required_key}"
            )
    full_validation_report = merged_solution.data.get("full_validation_report")
    if not isinstance(full_validation_report, dict):
        raise TypeError(
            'merged candidate data["full_validation_report"] must be a dict'
        )
    violations = full_validation_report.get("violations")
    if not isinstance(violations, list):
        raise TypeError(
            'merged candidate full_validation_report["violations"] must be a list'
        )
    valid = (
        merged_solution.data["feasible"] is True
        and full_validation_report.get("valid") is True
        and full_validation_report.get("feasible") is True
        and not violations
    )
    return {
        "valid": valid,
        "merged_solution": merged_solution,
        "full_validation_report": full_validation_report,
        "violations": list(violations),
        "truck_routes": copy.deepcopy(merged_solution.data["truck_routes"]),
    }


def run_single_replanning_trigger(
    phase1_best: "Solution",
    customers: Dict[int, Dict[str, Any]],
    depot_end: int,
    alns: Any,
    drone_ids_by_truck: Dict[int, List[int]],
    iters: int,
    already_revealed_customer_ids: Set[int],
    events: List[Dict[str, Any]] | None = None,
    phase_index: int = 1,
    trigger_reason: str = "dynamic_customer_reveal",
    x_remove: float | None = 0.15,
    temp_init: float = 100.0,
    temp_final: float = 1.0,
    normalize_every: int = 50,
    stage_breaks: tuple[float, float] = (0.3, 0.7),
    verbose: bool = False,
) -> tuple["Solution", ReplanContext, Dict[str, Any]]:
    """Run one dynamic-customer trigger and solve the resulting active suffix."""

    if not hasattr(phase1_best, "data"):
        raise TypeError("phase1_best must expose data")
    if iters < 0:
        raise ValueError(f"iters must be non-negative, got {iters}")
    if not isinstance(already_revealed_customer_ids, set):
        raise TypeError("already_revealed_customer_ids must be a set")

    phase1_data = phase1_best.data
    for required_key in ("drone_routes", "validation_report", "truck_routes"):
        if required_key not in phase1_data:
            raise ValueError(f"phase1_best.data missing required key: {required_key}")

    if events is None:
        events = build_replanning_events(customers)
    _validate_replanning_events(events=events, customers=customers)

    selected_event = None
    for event in events:
        unrevealed_customer_ids = [
            customer_id
            for customer_id in event["customer_ids"]
            if customer_id not in already_revealed_customer_ids
        ]
        if unrevealed_customer_ids:
            selected_event = event
            break
    if selected_event is None:
        raise ValueError("no unrevealed replanning event remains")

    trigger_adjustment = resolve_safe_replanning_trigger_time(
        solution_data=phase1_data,
        raw_trigger_time=selected_event["trigger_time"],
        drone_ids_by_truck=drone_ids_by_truck,
    )
    adjusted_trigger_time = trigger_adjustment["adjusted_trigger_time"]

    newly_revealed_customer_ids = reveal_events_until(
        events=events,
        adjusted_trigger_time=adjusted_trigger_time,
        already_revealed_customer_ids=already_revealed_customer_ids,
    )
    if not newly_revealed_customer_ids:
        raise ValueError("single trigger produced no newly revealed customers")

    revealed_customer_ids = (
        set(already_revealed_customer_ids)
        | newly_revealed_customer_ids
    )
    event_customer_ids = {
        customer_id
        for event in events
        for customer_id in event["customer_ids"]
    }
    future_dynamic_customer_ids = event_customer_ids - revealed_customer_ids

    context = build_replan_context_from_solution(
        solution_data=phase1_data,
        customers=customers,
        adjusted_trigger_time=adjusted_trigger_time,
        phase_index=phase_index,
        trigger_reason=trigger_reason,
        revealed_customer_ids=revealed_customer_ids,
        newly_revealed_customer_ids=newly_revealed_customer_ids,
        future_dynamic_customer_ids=future_dynamic_customer_ids,
        drone_ids_by_truck=drone_ids_by_truck,
    )

    _set_alns_visible_customers_if_supported(
        alns=alns,
        customers=customers,
        revealed_customer_ids=revealed_customer_ids,
    )

    phase_best_solution, phase_report = solve_replanning_phase(
        previous_solution=phase1_best,
        context=context,
        customers=customers,
        depot_end=depot_end,
        alns=alns,
        iters=iters,
        x_remove=x_remove,
        temp_init=temp_init,
        temp_final=temp_final,
        normalize_every=normalize_every,
        stage_breaks=stage_breaks,
        verbose=verbose,
    )

    report = {
        "phase_index": phase_index,
        "trigger_reason": trigger_reason,
        "selected_event": {
            "trigger_time": selected_event["trigger_time"],
            "customer_ids": list(selected_event["customer_ids"]),
        },
        "trigger_adjustment": trigger_adjustment,
        "phase_start_time": context.phase_start_time,
        "already_revealed_customer_ids": sorted(already_revealed_customer_ids),
        "newly_revealed_customer_ids": sorted(newly_revealed_customer_ids),
        "revealed_customer_ids": sorted(revealed_customer_ids),
        "future_dynamic_customer_ids": sorted(future_dynamic_customer_ids),
        "locked_customer_ids": sorted(context.locked_customer_ids),
        "locked_drone_task_ids": sorted(context.locked_drone_task_ids),
        "anchor_by_truck": {
            truck_id: truck_state.anchor_node
            for truck_id, truck_state in context.truck_states.items()
        },
        "phase_report": phase_report,
    }

    return phase_best_solution, context, report


def run_replanning_triggers(
    initial_solution: "Solution",
    customers: Dict[int, Dict[str, Any]],
    depot_end: int,
    alns: Any,
    drone_ids_by_truck: Dict[int, List[int]],
    iters: int,
    events: List[Dict[str, Any]] | None = None,
    initial_revealed_customer_ids: Set[int] | None = None,
    first_phase_index: int = 2,
    trigger_reason: str = "dynamic_customer_reveal",
    x_remove: float | None = 0.15,
    temp_init: float = 100.0,
    temp_final: float = 1.0,
    normalize_every: int = 50,
    stage_breaks: tuple[float, float] = (0.3, 0.7),
    verbose: bool = False,
) -> tuple["Solution", Dict[str, Any]]:
    """Run all remaining dynamic-customer triggers as a rolling replanning loop."""

    if not hasattr(initial_solution, "data"):
        raise TypeError("initial_solution must expose data")
    if not hasattr(alns, "_rebuild_solution"):
        raise TypeError("alns must expose _rebuild_solution")
    if iters < 0:
        raise ValueError(f"iters must be non-negative, got {iters}")
    if isinstance(first_phase_index, bool) or not isinstance(first_phase_index, int):
        raise TypeError("first_phase_index must be an int")
    if first_phase_index < 1:
        raise ValueError(f"first_phase_index must be positive, got {first_phase_index}")

    if events is None:
        events = build_replanning_events(customers)
    _validate_replanning_events(events=events, customers=customers)

    if initial_revealed_customer_ids is None:
        already_revealed_customer_ids: Set[int] = set()
    else:
        if not isinstance(initial_revealed_customer_ids, set):
            raise TypeError("initial_revealed_customer_ids must be a set")
        already_revealed_customer_ids = set(initial_revealed_customer_ids)

    event_customer_ids = {
        customer_id
        for event in events
        for customer_id in event["customer_ids"]
    }
    unknown_initial_revealed = already_revealed_customer_ids - event_customer_ids
    if unknown_initial_revealed:
        raise ValueError(
            "initial_revealed_customer_ids contains customers outside events: "
            f"{sorted(unknown_initial_revealed)}"
        )

    current_solution = initial_solution
    phase_reports = []
    phase_index = first_phase_index
    locked_cost_state = LockedCostState()
    final_dynamic_cost_report = None

    while _has_unrevealed_replanning_event(events, already_revealed_customer_ids):
        phase_solution, context, trigger_report = run_single_replanning_trigger(
            phase1_best=current_solution,
            customers=customers,
            depot_end=depot_end,
            alns=alns,
            drone_ids_by_truck=drone_ids_by_truck,
            iters=iters,
            already_revealed_customer_ids=already_revealed_customer_ids,
            events=events,
            phase_index=phase_index,
            trigger_reason=trigger_reason,
            x_remove=x_remove,
            temp_init=temp_init,
            temp_final=temp_final,
            normalize_every=normalize_every,
            stage_breaks=stage_breaks,
            verbose=verbose,
        )

        increment_result = calculate_executed_cost_increment(
            full_solution=current_solution,
            context=context,
            locked_cost_state=locked_cost_state,
        )

        merge_validation = validate_merged_phase_candidate(
            previous_solution=current_solution,
            phase_solution=phase_solution,
            context=context,
            depot_end=depot_end,
            alns=alns,
            customers=customers,
        )
        if not merge_validation["valid"]:
            raise ValueError(
                "merged solution is infeasible after rebuild: "
                f"{merge_validation['full_validation_report']}; "
                f"truck_routes={merge_validation['truck_routes']}"
            )
        merged_solution = merge_validation["merged_solution"]
        validation_report = merged_solution.data["validation_report"]
        if not isinstance(validation_report, dict):
            raise TypeError('merged_solution.data["validation_report"] must be a dict')
        if "truck_evaluations" not in validation_report:
            raise ValueError(
                'merged_solution.data["validation_report"] missing truck_evaluations'
            )

        commit_locked_cost_increment(
            locked_cost_state=locked_cost_state,
            increment_result=increment_result,
        )
        dynamic_cost_report = calculate_dynamic_objective(
            locked_cost_state=locked_cost_state,
            active_suffix_solution=phase_solution,
        )
        final_dynamic_cost_report = dynamic_cost_report
        trigger_report["executed_cost_increment"] = dict(
            increment_result["increment_components"]
        )
        trigger_report["locked_cost_components"] = dict(
            locked_cost_state.locked_cost_components
        )
        trigger_report["locked_executed_cost"] = (
            locked_cost_state.locked_executed_cost
        )
        trigger_report["active_suffix_cost"] = dynamic_cost_report[
            "active_suffix_cost"
        ]
        trigger_report["dynamic_cost_components"] = dict(
            dynamic_cost_report["dynamic_cost_components"]
        )
        trigger_report["dynamic_total_cost"] = dynamic_cost_report[
            "dynamic_total_cost"
        ]

        current_solution = merged_solution
        already_revealed_customer_ids.update(context.newly_revealed_customer_ids)
        phase_reports.append(trigger_report)
        phase_index += 1

    for required_key in ("feasible", "cost", "unserved"):
        if required_key not in current_solution.data:
            raise ValueError(f"final solution missing required key: {required_key}")
    #在当前这段重规划代码里，already_revealed_customer_ids 只表示“动态事件里已经揭示的动态客户”
    remaining_unrevealed_customer_ids = event_customer_ids - already_revealed_customer_ids
    if final_dynamic_cost_report is None:
        final_dynamic_cost_report = calculate_dynamic_objective(
            locked_cost_state=locked_cost_state,
            active_suffix_solution=current_solution,
        )

    report = {
        "initial_event_count": len(events),
        "executed_phase_count": len(phase_reports),
        "first_phase_index": first_phase_index,
        "next_phase_index": phase_index,
        "revealed_customer_ids": sorted(already_revealed_customer_ids),
        "remaining_unrevealed_customer_ids": sorted(remaining_unrevealed_customer_ids),
        "phase_reports": phase_reports,
        "final_cost": current_solution.data["cost"],
        "locked_cost_components": dict(locked_cost_state.locked_cost_components),
        "locked_executed_cost": locked_cost_state.locked_executed_cost,
        "final_dynamic_cost_report": final_dynamic_cost_report,
        "final_feasible": current_solution.data["feasible"],
        "final_unserved": list(current_solution.data["unserved"]),
    }

    return current_solution, report
