from pprint import pprint

from utils import (
    ROAD_RISK_DISTANCE_SCALE,
    calculate_weighted_cost,
    require_customer_field as require_common_customer_field,
    require_customer_is_dynamic,
    require_customer_load,
    require_nested_value,
    require_period_value,
)
from priority_rules import require_customer_priority_weight
from solution import create_empty_solution, refresh_depot_phase_start_state


def make_infeasible_result(
    violation,
    total_distance=0.0,
    total_travel_time=0.0,
    current_time=0.0,
    start_time=0.0,
    arrival_times=None,
    departure_times=None,
    remaining_loads=None,
    risk_cost=0.0,
    priority_cost=0.0,
    unserved_penalty_cost=0.0,
    delay_penalty=0.0,
    replenishment_count=0,
    total_basic_replenishment=0.0,
    total_emergency_replenishment=0.0,
    replenishment_records=None,
    initial_loads=None,
    final_loads=None,
    violations=None,
    warnings=None,
):
    """统一构造不可行结果，保留已经计算出的调试信息。"""
    if arrival_times is None:
        arrival_times = {}
    if departure_times is None:
        departure_times = {}
    if remaining_loads is None:
        remaining_loads = {}
    if replenishment_records is None:
        replenishment_records = []
    if initial_loads is None:
        initial_loads = {"basic": 0.0, "emergency": 0.0}
    if final_loads is None:
        final_loads = {"basic": 0.0, "emergency": 0.0}
    if violations is None:
        violations = []
    if warnings is None:
        warnings = []

    violations = list(violations)
    violations.append(violation)

    return {
        "feasible": False,
        "total_distance": total_distance,
        "total_travel_time": total_travel_time,
        "total_time": current_time - start_time,
        "arrival_times": arrival_times,
        "departure_times": departure_times,
        "remaining_loads": remaining_loads,
        "risk_cost": risk_cost,
        "road_risk_cost": risk_cost,
        "priority_cost": priority_cost,
        "unserved_penalty_cost": unserved_penalty_cost,
        "delay_penalty": delay_penalty,
        "replenishment_count": replenishment_count,
        "total_basic_replenishment": total_basic_replenishment,
        "total_emergency_replenishment": total_emergency_replenishment,
        "replenishment_records": replenishment_records,
        "initial_loads": initial_loads,
        "final_loads": final_loads,
        "violations": violations,
        "warnings": warnings,
    }


def evaluate_truck_route(
    route,
    customers,
    distance_matrix,
    truck_time_matrix,
    risk_matrix,
    periods,
    period_length,
    truck_capacity,
    depot_start,
    depot_end,
    replenishment_node=999,
    start_time=0.0,
    initial_load=None,
    anchor_node=None,
    initial_basic_load=None,
    initial_emergency_load=None,
    replenishment_time=0.0,
    risk_cost_weight=1.0,
    delay_cost_weight=1.0,
):
    """评价一条卡车路径的可行性、成本、补货记录和两类载重变化。"""

    def get_period_by_time(current_time):
        return require_period_value(current_time, periods, period_length)

    def require_customer_field(customer_id, field_name):
        return require_common_customer_field(customers, customer_id, field_name)

    def get_customer_load(customer_id):
        return require_customer_load(customers, customer_id)

    def get_customer_priority_weight(customer_id):
        return require_customer_priority_weight(customer_id, customers)

    def is_dynamic_customer(customer_id):
        return require_customer_is_dynamic(customers, customer_id)

    def copy_load(loads):
        return {
            "basic": loads["basic"],
            "emergency": loads["emergency"],
        }

    def exceeds_capacity(loads):
        """检查两类物资载重是否超过卡车容量。"""
        if isinstance(truck_capacity, dict):
            if "basic" not in truck_capacity or "emergency" not in truck_capacity:
                raise ValueError("truck_capacity 为 dict 时必须包含 basic 和 emergency")
            return (
                loads["basic"] > truck_capacity["basic"]
                or loads["emergency"] > truck_capacity["emergency"]
            )
        return loads["basic"] + loads["emergency"] > truck_capacity

    def get_matrix_value(matrix, *keys):
        return require_nested_value(matrix, *keys)

    def build_result(feasible):
        return {
            "feasible": feasible,
            "total_distance": total_distance,
            "total_travel_time": total_travel_time,
            "total_time": current_time - start_time,
            "arrival_times": arrival_times,
            "departure_times": departure_times,
            "arrival_times_by_index": arrival_times_by_index,
            "departure_times_by_index": departure_times_by_index,
            "timeline_by_position": timeline_by_position,
            "remaining_loads": remaining_loads,
            "risk_cost": risk_cost,
            "road_risk_cost": risk_cost,
            "priority_cost": priority_cost,
            "unserved_penalty_cost": unserved_penalty_cost,
            "delay_penalty": delay_penalty,
            "replenishment_count": replenishment_count,
            "total_basic_replenishment": total_basic_replenishment,
            "total_emergency_replenishment": total_emergency_replenishment,
            "replenishment_records": replenishment_records,
            "initial_loads": initial_loads,
            "final_loads": copy_load(remaining_load),
            "violations": violations,
            "warnings": warnings,
        }

    def infeasible(violation):
        return make_infeasible_result(
            violation=violation,
            total_distance=total_distance,
            total_travel_time=total_travel_time,
            current_time=current_time,
            start_time=start_time,
            arrival_times=arrival_times,
            departure_times=departure_times,
            remaining_loads=remaining_loads,
            risk_cost=risk_cost,
            priority_cost=priority_cost,
            unserved_penalty_cost=unserved_penalty_cost,
            delay_penalty=delay_penalty,
            replenishment_count=replenishment_count,
            total_basic_replenishment=total_basic_replenishment,
            total_emergency_replenishment=total_emergency_replenishment,
            replenishment_records=replenishment_records,
            initial_loads=initial_loads,
            final_loads=copy_load(remaining_load),
            violations=violations,
            warnings=warnings,
        )

    current_time = start_time
    total_distance = 0.0
    total_travel_time = 0.0
    risk_cost = 0.0
    priority_cost = 0.0
    unserved_penalty_cost = 0.0
    delay_penalty = 0.0
    replenishment_count = 0
    total_basic_replenishment = 0.0
    total_emergency_replenishment = 0.0
    arrival_times = {}
    departure_times = {}
    arrival_times_by_index = {}
    departure_times_by_index = {}
    timeline_by_position = {}#用于存储卡车路径中每个位置（索引）的详细时间线快照。节点的到达时间和离开时间等等
    remaining_loads = {}
    replenishment_records = []
    dynamic_truck_direct_dispatch_by_replenishment = {}
    violations = []
    warnings = []
    initial_loads = {"basic": 0.0, "emergency": 0.0}
    remaining_load = {"basic": 0.0, "emergency": 0.0}

    if anchor_node is None:
        anchor_node = depot_start
    has_phase_initial_load = (
        initial_basic_load is not None
        or initial_emergency_load is not None
    )
    if has_phase_initial_load:
        if initial_basic_load is None or initial_emergency_load is None:
            raise ValueError(
                "initial_basic_load and initial_emergency_load must be provided together"
            )
        if initial_load is not None:
            raise ValueError("initial_load cannot be combined with phase initial loads")

    # 第一步：基础路径结构检查。
    if not route:
        return infeasible("route 不能为空")
    if route[0] != anchor_node:
        return infeasible(f"route must start from anchor_node={anchor_node}, got {route[0]}")
    if route[-1] != depot_end:
        return infeasible(f"路径终点必须是 depot_end={depot_end}")

    for index, node in enumerate(route):
        if node == depot_start and not (index == 0 and anchor_node == depot_start):
            return infeasible(f"depot_start={depot_start} can only be the depot phase anchor")
        if node == depot_end and index != len(route) - 1:
            return infeasible(f"depot_end={depot_end} 只能出现在路径最后一个位置")

        if node == replenishment_node:
            return infeasible(
                f"replenishment node {replenishment_node} is deprecated in truck routes"
            )

        if node not in customers and node not in {depot_start, depot_end, replenishment_node}:
            return infeasible(f"路径中存在未知节点: {node}")

    # 第二步：初始化两类物资载重。
    if has_phase_initial_load:
        initial_loads = {
            "basic": initial_basic_load,
            "emergency": initial_emergency_load,
        }
    elif initial_load is None:
        for node in route:
            if node in customers and not is_dynamic_customer(node):
                customer_load = get_customer_load(node)
                initial_loads["basic"] += customer_load["basic"]
                initial_loads["emergency"] += customer_load["emergency"]
    else:
        if not isinstance(initial_load, dict):
            raise ValueError("initial_load 必须是 None 或包含 basic/emergency 的 dict")
        if "basic" not in initial_load or "emergency" not in initial_load:
            raise ValueError("initial_load 必须包含 basic 和 emergency")
        initial_loads = {
            "basic": initial_load["basic"],
            "emergency": initial_load["emergency"],
        }

    remaining_load = copy_load(initial_loads)
    start_node = route[0]
    arrival_times[start_node] = current_time
    arrival_times_by_index[0] = current_time
    departure_times[start_node] = current_time
    departure_times_by_index[0] = current_time
    remaining_loads[start_node] = copy_load(remaining_load)
    timeline_by_position[0] = {
        "node": start_node,
        "arrival_time": arrival_times_by_index[0],
        "departure_time": departure_times_by_index[0],
        "remaining_basic_load": remaining_load["basic"],
        "remaining_emergency_load": remaining_load["emergency"],
    }

    if exceeds_capacity(initial_loads):
        return infeasible(f"初始载重超过卡车容量: {initial_loads}")

    # 第三步：沿路径逐段模拟行驶、补货、服务和载重变化。
    for edge_index in range(len(route) - 1):
        i = route[edge_index]
        j = route[edge_index + 1]
        period = get_period_by_time(current_time)

        risk_level = get_matrix_value(risk_matrix, period, i, j)
        if risk_level not in {0, 1, 2, 3, 4}:
            raise ValueError(f"道路风险等级必须在 0-4 内: period={period}, edge=({i}, {j})")
        if risk_level == 4:
            return infeasible(f"道路 ({i}, {j}) 在时段 {period} 风险等级为 4，卡车不可通行")

        travel_time = get_matrix_value(truck_time_matrix, period, i, j)
        distance = get_matrix_value(distance_matrix, i, j)

        current_time += travel_time
        total_distance += distance
        total_travel_time += travel_time
        risk_cost += (distance / ROAD_RISK_DISTANCE_SCALE) * risk_level * risk_cost_weight
        arrival_times[j] = current_time
        next_position = edge_index + 1
        arrival_times_by_index[next_position] = current_time

        if j == depot_end:
            departure_times[j] = current_time
            remaining_loads[j] = copy_load(remaining_load)

        elif j == replenishment_node:
            return infeasible(
                f"replenishment node {replenishment_node} is deprecated in truck routes"
            )
        elif j in customers:
            basic_demand = require_customer_field(j, "basic_demand")
            emergency_demand = require_customer_field(j, "emergency_demand")
            latest = require_customer_field(j, "latest")
            service_time = require_customer_field(j, "service_time")
            if isinstance(latest, bool) or not isinstance(latest, (int, float)):
                raise TypeError(
                    f"customer {j} latest must be numeric, got {type(latest).__name__}"
                )

            service_start_time = current_time
            customer_is_dynamic = is_dynamic_customer(j)
            if customer_is_dynamic:
                release_time = require_customer_field(j, "release_time")
                if isinstance(release_time, bool) or not isinstance(release_time, (int, float)):
                    raise TypeError(
                        f"dynamic customer {j} release_time must be numeric, "
                        f"got {type(release_time).__name__}"
                    )
                if service_start_time < release_time:
                    service_start_time = release_time
                    current_time = release_time
            customer_weight = get_customer_priority_weight(j)
            if customer_is_dynamic:
                priority_time = service_start_time - release_time
            else:
                priority_time = service_start_time
            priority_cost += customer_weight * max(0.0, priority_time)

            if service_start_time > latest:
                delay = service_start_time - latest
                delay_penalty += delay * customer_weight * delay_cost_weight
                warnings.append(f"Customer {j} served late by {delay}")

            if not customer_is_dynamic and remaining_load["basic"] < basic_demand:
                return infeasible(
                    f"服务客户 {j} 时 basic 载重不足: "
                    f"load={remaining_load['basic']}, demand={basic_demand}"
                )
            if not customer_is_dynamic and remaining_load["emergency"] < emergency_demand:
                return infeasible(
                    f"服务客户 {j} 时 emergency 载重不足: "
                    f"load={remaining_load['emergency']}, demand={emergency_demand}"
                )

            if not customer_is_dynamic:
                remaining_load["basic"] -= basic_demand
                remaining_load["emergency"] -= emergency_demand
            current_time += service_time
            departure_times[j] = current_time
            remaining_loads[j] = copy_load(remaining_load)

        else:
            return infeasible(f"无法识别的到达节点: {j}")

        departure_times_by_index[next_position] = departure_times[j]
        position_load = remaining_loads[j]
        timeline_by_position[next_position] = {
            "node": j,
            "arrival_time": arrival_times_by_index[next_position],
            "departure_time": departure_times_by_index[next_position],
            "remaining_basic_load": position_load["basic"],
            "remaining_emergency_load": position_load["emergency"],
        }

    return build_result(feasible=True)


def calculate_route_cost(evaluation, cost_weights=None):
    """按参考代码的目标函数方向计算路径成本。"""
    return calculate_weighted_cost(evaluation, cost_weights)


def try_insert_customer_with_inventory_options(
    route,
    customer_id,
    customers,
    distance_matrix,
    truck_time_matrix,
    risk_matrix,
    periods,
    period_length,
    truck_capacity,
    depot_start,
    depot_end,
    replenishment_node=999,
    start_time=0.0,
    initial_load=None,
    replenishment_time=0.0,
    risk_cost_weight=1.0,
    delay_cost_weight=1.0,
    cost_weights=None,
):
    """Enumerate direct [customer] truck insertion candidates."""
    if customer_id not in customers:
        raise ValueError(f"客户 {customer_id} 不在 customers 中")
    if "is_static" not in customers[customer_id]:
        raise ValueError(f"客户 {customer_id} 缺少字段: is_static")

    if not route:
        raise ValueError("route 不能为空")
    if route[0] != depot_start:
        raise ValueError(f"路径起点必须是 depot_start={depot_start}")
    if route[-1] != depot_end:
        raise ValueError(f"路径终点必须是 depot_end={depot_end}")

    old_evaluation = evaluate_truck_route(
        route=route,
        customers=customers,
        distance_matrix=distance_matrix,
        truck_time_matrix=truck_time_matrix,
        risk_matrix=risk_matrix,
        periods=periods,
        period_length=period_length,
        truck_capacity=truck_capacity,
        depot_start=depot_start,
        depot_end=depot_end,
        replenishment_node=replenishment_node,
        start_time=start_time,
        initial_load=initial_load,
        replenishment_time=replenishment_time,
        risk_cost_weight=risk_cost_weight,
        delay_cost_weight=delay_cost_weight,
    )
    old_cost = calculate_route_cost(old_evaluation, cost_weights)
    insert_node_options = [[customer_id]]
    candidates = []
    best_candidate = None

    for position in range(1, len(route)):
        for insert_nodes in insert_node_options:
            candidate_route = route[:position] + insert_nodes + route[position:]
            evaluation = evaluate_truck_route(
                route=candidate_route,
                customers=customers,
                distance_matrix=distance_matrix,
                truck_time_matrix=truck_time_matrix,
                risk_matrix=risk_matrix,
                periods=periods,
                period_length=period_length,
                truck_capacity=truck_capacity,
                depot_start=depot_start,
                depot_end=depot_end,
                replenishment_node=replenishment_node,
                start_time=start_time,
                initial_load=initial_load,
                replenishment_time=replenishment_time,
                risk_cost_weight=risk_cost_weight,
                delay_cost_weight=delay_cost_weight,
            )

            candidate = {
                "position": position,
                "insert_nodes": list(insert_nodes),
                "route": candidate_route,
                "feasible": evaluation["feasible"],
                "cost": None,
                "insert_cost": float("inf"),
                "evaluation": evaluation,
                "violations": evaluation.get("violations", []),
                "warnings": evaluation.get("warnings", []),
            }

            if evaluation["feasible"]:
                candidate["cost"] = calculate_route_cost(evaluation, cost_weights)
                candidate["insert_cost"] = candidate["cost"] - old_cost
                if (
                    best_candidate is None
                    or candidate["insert_cost"] < best_candidate["insert_cost"]
                ):
                    best_candidate = candidate

            candidates.append(candidate)

    if best_candidate is None:
        return {
            "feasible": False,
            "best_position": None,
            "best_route": None,
            "best_cost": None,
            "insert_position": None,
            "insert_nodes": None,
            "inserted_pair": None,
            "insert_cost": float("inf"),
            "new_cost": float("inf"),
            "old_cost": old_cost,
            "best_evaluation": None,
            "evaluation": None,
            "candidates": candidates,
            "all_candidates": candidates,
            "violations": [
                f"No feasible truck insertion found for customer {customer_id}"
            ],
        }

    return {
        "feasible": True,
        "best_position": best_candidate["position"],
        "best_route": best_candidate["route"],
        "best_cost": best_candidate["cost"],
        "insert_position": best_candidate["position"],
        "insert_nodes": list(best_candidate["insert_nodes"]),
        "inserted_pair": None,
        "insert_cost": best_candidate["insert_cost"],
        "new_cost": best_candidate["cost"],
        "old_cost": old_cost,
        "best_evaluation": best_candidate["evaluation"],
        "evaluation": best_candidate["evaluation"],
        "candidates": candidates,
        "all_candidates": candidates,
    }


def insert_customer_into_best_truck(
    solution,
    customer_id,
    customers,
    distance_matrix,
    truck_time_matrix,
    risk_matrix,
    periods,
    period_length,
    truck_capacity_by_truck,
    depot_start,
    depot_end,
    replenishment_node=999,
    start_time=0.0,
    replenishment_time=0.0,
    cost_weights=None,
):
    """把一个客户插入到 solution 中增量成本最低的卡车路径。"""
    '''if customer_id not in customers:
        raise ValueError(f"客户 {customer_id} 不在 customers 中")
    if "truck_routes" not in solution:
        raise ValueError("solution 缺少 truck_routes")
    if "served" not in solution:
        raise ValueError("solution 缺少 served")
    if "unserved" not in solution:
        raise ValueError("solution 缺少 unserved")
    if "is_static" not in customers[customer_id]:
        raise ValueError(f"客户 {customer_id} 缺少字段: is_static")'''
    all_truck_candidates = []
    best_truck_candidate = None

    for truck_id, route in solution["truck_routes"].items():
        if isinstance(truck_capacity_by_truck, dict):
            if truck_id not in truck_capacity_by_truck:
                raise ValueError(f"truck_capacity_by_truck 缺少卡车 {truck_id} 的容量")
            truck_capacity = truck_capacity_by_truck[truck_id]
        else:
            truck_capacity = truck_capacity_by_truck

        insert_result = try_insert_customer_with_inventory_options(
            route=route,
            customer_id=customer_id,
            customers=customers,
            distance_matrix=distance_matrix,
            truck_time_matrix=truck_time_matrix,
            risk_matrix=risk_matrix,
            periods=periods,
            period_length=period_length,
            truck_capacity=truck_capacity,
            depot_start=depot_start,
            depot_end=depot_end,
            replenishment_node=replenishment_node,
            start_time=start_time,
            replenishment_time=replenishment_time,
            cost_weights=cost_weights,
        )

        truck_candidate = {
            "truck_id": truck_id,
            "feasible": insert_result["feasible"],
            "best_route": insert_result.get("best_route"),
            "insert_position": insert_result.get("insert_position"),
            "insert_nodes": insert_result.get("insert_nodes"),
            "insert_cost": insert_result.get("insert_cost", float("inf")),
            "new_cost": insert_result.get("new_cost", float("inf")),
            "old_cost": insert_result.get("old_cost"),
            "evaluation": insert_result.get("evaluation"),
            "raw_result": insert_result,
        }
        all_truck_candidates.append(truck_candidate)

        if truck_candidate["feasible"]:
            if (
                best_truck_candidate is None
                or truck_candidate["insert_cost"] < best_truck_candidate["insert_cost"]
            ):
                best_truck_candidate = truck_candidate

    if best_truck_candidate is None:
        if customer_id not in solution["unserved"]:
            solution["unserved"].append(customer_id)
        return {
            "feasible": False,
            "customer_id": customer_id,
            "best_truck_id": None,
            "best_route": None,
            "insert_cost": float("inf"),
            "evaluation": None,
            "all_truck_candidates": all_truck_candidates,
            "violations": [
                f"No feasible truck insertion found for customer {customer_id}"
            ],
        }

    best_truck_id = best_truck_candidate["truck_id"]
    solution["truck_routes"][best_truck_id] = best_truck_candidate["best_route"]
    solution["served"].add(customer_id)
    if customer_id in solution["unserved"]:
        solution["unserved"].remove(customer_id)

    return {
        "feasible": True,
        "customer_id": customer_id,
        "best_truck_id": best_truck_id,
        "best_route": best_truck_candidate["best_route"],
        "insert_nodes": best_truck_candidate["insert_nodes"],
        "insert_cost": best_truck_candidate["insert_cost"],
        "new_cost": best_truck_candidate["new_cost"],
        "old_cost": best_truck_candidate["old_cost"],
        "evaluation": best_truck_candidate["evaluation"],
        "all_truck_candidates": all_truck_candidates,
    }


def construct_initial_truck_routes(
    truck_ids,
    customers,
    distance_matrix,
    truck_time_matrix,
    risk_matrix,
    periods,
    period_length,
    truck_capacity_by_truck,
    depot_start,
    depot_end,
    replenishment_node=999,
    start_time=0.0,
    replenishment_time=0.0,
    cost_weights=None,
    depot_node_for_sort=0,
):
    """按静态客户优先、动态客户后插入的方式构造初始卡车路径。"""

    def require_customer_field(customer_id, field_name):
        return require_common_customer_field(customers, customer_id, field_name)

    def get_distance_for_sort(customer_id):
        """读取客户到仓库的距离；缺少距离时直接报错。"""
        if depot_node_for_sort not in distance_matrix:
            raise ValueError(f"distance_matrix 缺少仓库节点 {depot_node_for_sort}")
        if customer_id not in distance_matrix[depot_node_for_sort]:
            raise ValueError(
                f"distance_matrix[{depot_node_for_sort}] 缺少客户 {customer_id} 的距离"
            )
        return distance_matrix[depot_node_for_sort][customer_id]

    def static_sort_key(customer_id):
        latest = require_customer_field(customer_id, "latest")
        priority_score = require_customer_priority_weight(customer_id, customers)
        distance_to_depot = get_distance_for_sort(customer_id)
        return (
            -priority_score,
            latest,
            distance_to_depot,
        )

    def dynamic_sort_key(customer_id):
        release_time = require_customer_field(customer_id, "release_time")
        latest = require_customer_field(customer_id, "latest")
        priority_score = require_customer_priority_weight(customer_id, customers)
        return (
            release_time,
            -priority_score,
            latest,
        )

    solution = create_empty_solution(truck_ids, depot_start, depot_end)
    construction_log = []
    non_customer_nodes = {depot_start, depot_end, replenishment_node}

    static_customers = []
    dynamic_customers = []
    for customer_id, customer in customers.items():
        if customer_id in non_customer_nodes:
            continue
        is_static = require_customer_field(customer_id, "is_static")
        if is_static:
            static_customers.append(customer_id)
        else:
            dynamic_customers.append(customer_id)

    static_order = sorted(static_customers, key=static_sort_key)
    dynamic_order = sorted(dynamic_customers, key=dynamic_sort_key)

    # Insert static customers first; inventory rules decide whether 999 is needed.
    for customer_id in static_order:
        if customer_id in solution["served"]:
            construction_log.append(
                {
                    "phase": "static",
                    "customer_id": customer_id,
                    "skipped": True,
                    "reason": "already served",
                    "result": None,
                }
            )
            continue

        result = insert_customer_into_best_truck(
            solution=solution,
            customer_id=customer_id,
            customers=customers,
            distance_matrix=distance_matrix,
            truck_time_matrix=truck_time_matrix,
            risk_matrix=risk_matrix,
            periods=periods,
            period_length=period_length,
            truck_capacity_by_truck=truck_capacity_by_truck,
            depot_start=depot_start,
            depot_end=depot_end,
            replenishment_node=replenishment_node,
            start_time=start_time,
            replenishment_time=replenishment_time,
            cost_weights=cost_weights,
        )
        if not result["feasible"] and customer_id not in solution["unserved"]:
            solution["unserved"].append(customer_id)
        construction_log.append(
            {
                "phase": "static",
                "customer_id": customer_id,
                "skipped": False,
                "result": result,
            }
        )

    # Insert dynamic customers after static customers with the same inventory rule.
    for customer_id in dynamic_order:
        if customer_id in solution["served"]:
            construction_log.append(
                {
                    "phase": "dynamic",
                    "customer_id": customer_id,
                    "skipped": True,
                    "reason": "already served",
                    "result": None,
                }
            )
            continue

        result = insert_customer_into_best_truck(
            solution=solution,
            customer_id=customer_id,
            customers=customers,
            distance_matrix=distance_matrix,
            truck_time_matrix=truck_time_matrix,
            risk_matrix=risk_matrix,
            periods=periods,
            period_length=period_length,
            truck_capacity_by_truck=truck_capacity_by_truck,
            depot_start=depot_start,
            depot_end=depot_end,
            replenishment_node=replenishment_node,
            start_time=start_time,
            replenishment_time=replenishment_time,
            cost_weights=cost_weights,
        )
        if not result["feasible"] and customer_id not in solution["unserved"]:
            solution["unserved"].append(customer_id)
        construction_log.append(
            {
                "phase": "dynamic",
                "customer_id": customer_id,
                "skipped": False,
                "result": result,
            }
        )

    solution["construction_log"] = construction_log
    solution["static_order"] = static_order
    solution["dynamic_order"] = dynamic_order
    # 8. 调用 refresh_depot_phase_start_state 更新初始阶段起始状态
    #    （锚点、时间、初始载重等）
    refresh_depot_phase_start_state(
        solution=solution,
        customers=customers,
        depot_start=depot_start,
    )
    solution["feasible"] = True
    solution["cost"] = None
    return solution


def validate_truck_initial_solution(
    solution,
    customers,
    truck_ids,
    distance_matrix,
    truck_time_matrix,
    risk_matrix,
    periods,
    period_length,
    truck_capacity_by_truck,
    depot_start,
    depot_end,
    replenishment_node=999,
    start_time=0.0,
    replenishment_time=0.0,
    cost_weights=None,
    update_solution=True,
    raise_error=False,
):
    """检查 construct_initial_truck_routes 生成的卡车初始解是否合理。"""

    def add_violation(message):
        violations.append(message)

    def add_warning(message):
        warnings.append(message)
    #- customer_is_dynamic: 判断客户是否为动态
    def customer_is_dynamic(customer_id):
        if customer_id not in customers:
            raise ValueError(f"客户 {customer_id} 不在 customers 中")
        return not customers[customer_id].get("is_static", True)

    def get_truck_capacity(truck_id):
        if isinstance(truck_capacity_by_truck, dict):
            if truck_id not in truck_capacity_by_truck:
                raise ValueError(f"truck_capacity_by_truck 缺少卡车 {truck_id} 的容量")
            return truck_capacity_by_truck[truck_id]
        return truck_capacity_by_truck

    required_solution_keys = {
        "truck_routes",
        "drone_routes",
        "unserved",
        "served",
        "cost",
    }
    violations = []
    warnings = []
    truck_evaluations = {}
    route_costs = {}
    served_by_truck = set()#所有出现在卡车路径中的客户ID
    duplicate_customers = {}#{客户ID: [(truck_id, index), ...]} 重复服务的具体位置
    missing_customers = set()#既未服务也未标记为未服务的客户ID
    corrected_served = set()#修正后的已服务集合（通常等于 served_by_truck）
    total_truck_cost = 0.0
    all_routes_feasible = True

    truck_ids_set = set(truck_ids)
    non_customer_nodes = {depot_start, depot_end, replenishment_node}

    missing_solution_keys = required_solution_keys - set(solution)
    if missing_solution_keys:
        add_violation(f"solution 缺少必要键: {sorted(missing_solution_keys)}")

    truck_routes = solution.get("truck_routes")
    if not isinstance(truck_routes, dict):
        add_violation("solution['truck_routes'] 必须是 dict")
        truck_routes = {}

    raw_unserved = solution.get("unserved", [])
    if not isinstance(raw_unserved, (list, set)):
        add_violation("solution['unserved'] 必须是 list 或 set")
        raw_unserved = []
    unserved = set(raw_unserved)

    raw_served = solution.get("served", set())
    try:
        served = set(raw_served)
    except TypeError:
        add_violation("solution['served'] 必须是 set 或可转换为 set")
        served = set()

    for truck_id in truck_routes:
        if truck_id not in truck_ids_set:
            add_violation(f"truck_routes 中存在未知卡车: {truck_id}")

    for truck_id in truck_ids_set:
        if truck_id not in truck_routes:
            add_warning(
                f"卡车 {truck_id} 没有路径；未修改 truck_routes，建议路径为 "
                f"[{depot_start}, {depot_end}]"
            )
    #用于记录每个客户在卡车路径中出现的所有位置（即哪辆卡车的路径中的哪个索引）。它被用来检测客户是否被重复服务
    customer_occurrences = {}

    for truck_id, route in truck_routes.items():
        if not isinstance(route, list):
            add_violation(f"Truck {truck_id} 的 route 必须是 list")
            continue

        if not route:
            add_violation(f"Truck {truck_id} 的 route 不能为空")
            continue

        if route[0] != depot_start:
            add_violation(f"Truck {truck_id} 的 route 起点必须是 {depot_start}")
        if route[-1] != depot_end:
            add_violation(f"Truck {truck_id} 的 route 终点必须是 {depot_end}")

        for index, node in enumerate(route):
            if node == depot_start and index != 0:
                add_violation(
                    f"Truck {truck_id}: depot_start {depot_start} 只能出现在第一个位置"
                )
            if node == depot_end and index != len(route) - 1:
                add_violation(
                    f"Truck {truck_id}: depot_end {depot_end} 只能出现在最后一个位置"
                )
            if node not in non_customer_nodes and node not in customers:
                add_violation(f"Truck {truck_id}: 路径中存在未知节点 {node}")

        for index, node in enumerate(route):
            if node == replenishment_node:
                add_violation(
                    f"Truck {truck_id}: replenishment node {replenishment_node} is deprecated in truck routes"
                )
                continue

            if node in customers:
                served_by_truck.add(node)
                customer_occurrences.setdefault(node, []).append((truck_id, index))
    #用于检查客户是否被重复服务（即同一个客户出现在多条卡车路径中，或同一条路径中出现多次）
    for customer_id, occurrences in customer_occurrences.items():
        """遍历 customer_occurrences 字典的每一项，其中：
        customer_id：客户节点 ID。
        occurrences：一个列表，包含该客户所有出现的位置信息，每个元素是 (truck_id, index) 元组。"""
        if len(occurrences) > 1:
            duplicate_customers[customer_id] = occurrences
            add_violation(
                f"客户 {customer_id} 被重复服务: "
                f"{[(truck_id, index) for truck_id, index in occurrences]}"
            )

    corrected_served = set(served_by_truck)

    if served != served_by_truck:
        add_warning(
            f"solution['served'] 与卡车路径重新计算结果不一致；"
            f"served={sorted(served)}, corrected_served={sorted(corrected_served)}"
        )

    for customer_id in unserved:
        if customer_id not in customers:
            add_violation(f"unserved 中存在未知客户: {customer_id}")
        if customer_id in served_by_truck:
            add_violation(f"客户 {customer_id} 同时出现在 served_by_truck 和 unserved 中")
        if customer_id in served:
            add_violation(f"客户 {customer_id} 同时出现在 solution['served'] 和 unserved 中")

    all_customers = set(customers)
    missing_customers = all_customers - served_by_truck - unserved
    if missing_customers:
        add_warning(f"存在既未服务也未标记 unserved 的客户: {sorted(missing_customers)}")

    for truck_id, route in truck_routes.items():
        if not isinstance(route, list) or not route:
            all_routes_feasible = False
            continue

        try:#开始一个 try 块，用于捕获后续代码可能抛出的异常（如 ValueError）。
            truck_capacity = get_truck_capacity(truck_id)
            evaluation = evaluate_truck_route(
                route=route,
                customers=customers,
                distance_matrix=distance_matrix,
                truck_time_matrix=truck_time_matrix,
                risk_matrix=risk_matrix,
                periods=periods,
                period_length=period_length,
                truck_capacity=truck_capacity,
                depot_start=depot_start,
                depot_end=depot_end,
                replenishment_node=replenishment_node,
                start_time=start_time,
                replenishment_time=replenishment_time,
            )
            cost = calculate_route_cost(evaluation, cost_weights)
        except ValueError as exc:
            """如果 try 块中的任何代码抛出 ValueError（例如 evaluate_truck_route 中缺少矩阵数据、客户字段缺失等），
            则捕获异常，并将异常对象赋值给变量 exc"""
            evaluation = None
            cost = float("inf")
            all_routes_feasible = False
            add_violation(f"Truck {truck_id}: evaluate_truck_route 出错: {exc}")
        else:
            if not evaluation["feasible"]:
                all_routes_feasible = False
                add_violation(
                    f"Truck {truck_id}: evaluate_truck_route 判定不可行: "
                    f"{evaluation.get('violations', [])}"
                )

        truck_evaluations[truck_id] = evaluation
        route_costs[truck_id] = cost
        total_truck_cost += cost

    report = {
        "valid": len(violations) == 0,
        "feasible": all_routes_feasible,
        "total_truck_cost": total_truck_cost,
        "truck_evaluations": truck_evaluations,
        "route_costs": route_costs,
        "served_by_truck": served_by_truck,
        "corrected_served": corrected_served,
        "unserved": unserved,
        "missing_customers": missing_customers,
        "duplicate_customers": duplicate_customers,
        "violations": violations,
        "warnings": warnings,
    }

    if update_solution:
        solution["served"] = corrected_served
        solution["cost"] = total_truck_cost
        solution["feasible"] = len(violations) == 0
        solution["validation_report"] = report

    if raise_error and violations:
        preview = "\n".join(f"- {message}" for message in violations[:10])
        raise ValueError(f"卡车初始解验证失败:\n{preview}")

    return report
