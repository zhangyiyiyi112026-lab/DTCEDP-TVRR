from __future__ import annotations

import csv
import math
from pathlib import Path
from collections.abc import Mapping as MappingABC
from typing import Any, Dict, Hashable, Mapping, Sequence, Tuple

NodeId = Hashable
Period = Hashable
DistanceMatrix = Mapping[Tuple[NodeId, NodeId], float]#DistanceMatrix 是一个只读映射，键为 (from_node, to_node) 元组，值为浮点数距离。
FlatRiskDict = Mapping[Tuple[Period, NodeId, NodeId], int]#风险字典。flat_risk: FlatRiskDict = {(1, 0, 3): 2,
ROAD_RISK_DISTANCE_SCALE = 1000.0
NestedRiskDict = Mapping[Period, Mapping[NodeId, Mapping[NodeId, int]]]#嵌套的风险字典，外层键为时段，中层键为起点节点，内层键为终点节点，值为风险等级。


def time_to_period(current_time: float, period_duration: float) -> int:
    """将当前时间映射到时段编号：0-2 为 1，2-4 为 2。"""
    if not math.isfinite(current_time):
        raise ValueError(f"current_time must be finite, got {current_time}")
    if current_time < 0:
        raise ValueError(f"current_time must be non-negative, got {current_time}")
    if not math.isfinite(period_duration) or period_duration <= 0:
        raise ValueError(f"period_duration must be positive and finite, got {period_duration}")
    return int(current_time // period_duration) + 1


def load_road_risk_csv(csv_path: str | Path) -> Dict[Tuple[int, int, int], int]:
    """读取 road_risk_generator.py 导出的长表 CSV。"""
    path = Path(csv_path)#将输入的路径转换为 pathlib.Path 对象，方便后续调用 exists()、open() 等方法。
    if not path.exists():
        raise FileNotFoundError(f"risk csv does not exist: {path}")

    risk_level_dict: Dict[Tuple[int, int, int], int] = {}#初始化空字典，用于存储最终的风险数据。类型注解明确键为 (int, int, int)，值为 int。
    with path.open("r", encoding="utf-8-sig", newline="") as source:
        reader = csv.DictReader(source)
        required = {"period", "from_node", "to_node", "risk_level"}
        #计算必需列与 CSV 实际列名的差集。若 reader.fieldnames 为 None，则用空列表代替。missing 包含 CSV 中缺失的列名。
        missing = required.difference(reader.fieldnames or [])
        if missing:
            raise ValueError(f"risk csv missing columns: {sorted(missing)}")

        for line_no, row in enumerate(reader, start=2):#遍历 CSV 的每一行数据（从第二行开始计数，因为第一行是列名）。enumerate 的 start=2 使得第一数据行的行号为 2，便于错误提示时定位
            period = int(row["period"])
            from_node = int(row["from_node"])
            to_node = int(row["to_node"])
            risk_level = int(row["risk_level"])
            if risk_level not in {0, 1, 2, 3, 4}:
                raise ValueError(f"line {line_no} has invalid risk_level={risk_level}")
            key = (period, from_node, to_node)
            if key in risk_level_dict:#风险字典的键必须是唯一的，不允许同一个时段、同一条有向边出现多条风险记录。
                raise ValueError(f"duplicate risk record at line {line_no}: {key}")
            risk_level_dict[key] = risk_level
    return risk_level_dict


def get_distance(D_ij: DistanceMatrix, from_node: NodeId, to_node: NodeId) -> float:
    """严格读取距离矩阵中的一条边。"""
    key = (from_node, to_node)
    if key not in D_ij:
        raise KeyError(f"missing distance for edge {key}")
    distance = float(D_ij[key])
    if not math.isfinite(distance) or distance < 0:
        raise ValueError(f"distance for edge {key} must be finite and non-negative, got {distance}")
    return distance


def get_risk_level(
    from_node: NodeId,
    to_node: NodeId,
    current_time: float,
    risk_level_dict: FlatRiskDict | NestedRiskDict,
    period_duration: float,
) -> int:
    """严格读取某时段、某路段的道路风险等级。"""
    if risk_level_dict is None:
        raise ValueError("risk_level_dict is required for truck travel time")

    period = time_to_period(current_time, period_duration)
    # 构建扁平字典的查询键：(period, from_node, to_node) 三元组。
    flat_key = (period, from_node, to_node)
    if flat_key in risk_level_dict:
        risk_level = int(risk_level_dict[flat_key])
    elif period in risk_level_dict:
        period_risk = risk_level_dict[period]#如果 flat_key 不存在，但 period 作为键存在于字典中（即 risk_level_dict 是 NestedRiskDict），
        if from_node not in period_risk:
            raise KeyError(f"risk[{period}] missing from_node {from_node}")
        if to_node not in period_risk[from_node]:
            raise KeyError(f"risk[{period}][{from_node}] missing to_node {to_node}")
        risk_level = int(period_risk[from_node][to_node])
    else:
        raise KeyError(f"missing risk level for period={period}, edge=({from_node}, {to_node})")

    if risk_level not in {0, 1, 2, 3, 4}:
        raise ValueError(
            f"risk level must be in {{0, 1, 2, 3, 4}} for "
            f"period={period}, edge=({from_node}, {to_node}), got {risk_level}"
        )
    return risk_level


def get_risk_effective_speed(
    base_speed: float,
    risk_level: int,
    delta: float = 0.15,
    risk_cancel_level: int = 4,
) -> float:
    """根据道路风险等级计算卡车有效速度；风险达到阻断等级时不可通行。"""
    if not math.isfinite(base_speed) or base_speed <= 0:
        raise ValueError(f"base_speed must be positive and finite, got {base_speed}")
    if not math.isfinite(delta) or delta < 0:
        raise ValueError(f"delta must be finite and non-negative, got {delta}")
    if risk_level not in {0, 1, 2, 3, 4}:
        raise ValueError(f"risk_level must be in {{0, 1, 2, 3, 4}}, got {risk_level}")
    if risk_level >= risk_cancel_level:
        return 0.0
    speed = base_speed * (1.0 - delta * risk_level)
    if speed <= 0:
        raise ValueError(
            f"risk-adjusted truck speed is non-positive: "
            f"base_speed={base_speed}, risk_level={risk_level}, delta={delta}"
        )
    return speed


def calculate_truck_segment_time(
    from_node: NodeId,
    to_node: NodeId,
    D_ij: DistanceMatrix,
    v_t: float,
    current_time: float,
    risk_level_dict: FlatRiskDict | NestedRiskDict,
    period_duration: float,
    delta: float = 0.15,
    risk_cancel_level: int = 4,
) -> float:
    """计算卡车从 from_node 到 to_node 的单段行驶时间。"""
    distance = get_distance(D_ij, from_node, to_node)
    risk_level = get_risk_level(
        from_node,
        to_node,
        current_time,
        risk_level_dict,
        period_duration,
    )
    effective_speed = get_risk_effective_speed(v_t, risk_level, delta, risk_cancel_level)
    if effective_speed <= 0:
        return float("inf")
    return distance / effective_speed


def calculate_drone_segment_time(
    from_node: NodeId,
    to_node: NodeId,
    D_ij: DistanceMatrix,
    v_d: float,
) -> float:
    """计算无人机从 from_node 到 to_node 的单段飞行时间。"""
    if not math.isfinite(v_d) or v_d <= 0:
        raise ValueError(f"v_d must be positive and finite, got {v_d}")
    distance = get_distance(D_ij, from_node, to_node)
    return distance / v_d


def calculate_travel_time(
    route_type: str,
    from_node: NodeId,
    to_node: NodeId,
    D_ij: DistanceMatrix,
    *,
    v_t: float | None = None,
    v_d: float | None = None,
    current_time: float = 0.0,
    risk_level_dict: FlatRiskDict | NestedRiskDict | None = None,
    period_duration: float = 2.0,
    delta: float = 0.15,
    risk_cancel_level: int = 4,
) -> float:
    """calculate_travel_time 是一个统一的时间计算入口函数，
    根据 route_type 参数（"truck" 或 "drone"）分发到对应的具体计算函数：
    卡车调用 calculate_truck_segment_time（考虑时变风险），无人机调用 calculate_drone_segment_time（忽略风险）。
    该函数主要用于兼容旧代码或提供统一的接口，避免调用方需要自己判断类型。"""
    if route_type == "truck":
        if v_t is None:
            raise ValueError("v_t is required when route_type='truck'")
        return calculate_truck_segment_time(
            from_node,
            to_node,
            D_ij,
            v_t,
            current_time,
            risk_level_dict,
            period_duration,
            delta,
            risk_cancel_level,
        )
    if route_type == "drone":
        if v_d is None:
            raise ValueError("v_d is required when route_type='drone'")
        return calculate_drone_segment_time(from_node, to_node, D_ij, v_d)
    raise ValueError(f"unknown route_type: {route_type}")


SUPPORTED_COST_KEYS = {
    "priority_cost",
    "unserved_penalty_cost",
    "road_risk_cost",
    "delay_penalty",
}


def default_cost_weights() -> dict[str, float]:
    return {
        "priority_cost": 1.0,
        "unserved_penalty_cost": 1.0,
        "road_risk_cost": 1.0,
        "delay_penalty": 1.0,
    }


def require_period_index(
    current_time: float,
    periods: Sequence[int],
    period_length: float,
) -> int:
    if not periods:
        raise ValueError("periods must not be empty")
    if period_length <= 0:
        raise ValueError(f"period_length must be positive, got {period_length}")
    if current_time < 0:
        raise ValueError(f"current_time must be non-negative, got {current_time}")
    period_index = int(current_time // period_length)
    if period_index >= len(periods):
        return len(periods) - 1
    return period_index


def require_period_value(
    current_time: float,
    periods: Sequence[int],
    period_length: float,
) -> int:
    return periods[require_period_index(current_time, periods, period_length)]


def require_nested_value(
    matrix: Mapping[Any, Any],
    *keys: Any,
    matrix_name: str = "matrix",
) -> Any:
    value = matrix
    for key in keys:
        if not isinstance(value, MappingABC):
            raise TypeError(f"{matrix_name} path {keys} reaches non-mapping at {key}")
        if key not in value:
            raise ValueError(f"{matrix_name} missing key path: {keys}")
        value = value[key]
    return value


def require_customer_field(
    customers: Mapping[int, Mapping[str, Any]],
    customer_id: int,
    field_name: str,
) -> Any:
    if customer_id not in customers:
        raise ValueError(f"customer {customer_id} is not in customers")
    customer = customers[customer_id]
    if field_name not in customer:
        raise ValueError(f"customer {customer_id} missing required field: {field_name}")
    return customer[field_name]


def require_customer_load(
    customers: Mapping[int, Mapping[str, Any]],
    customer_id: int,
) -> dict[str, float]:
    return {
        "basic": require_customer_field(customers, customer_id, "basic_demand"),
        "emergency": require_customer_field(customers, customer_id, "emergency_demand"),
    }


def require_customer_is_dynamic(
    customers: Mapping[int, Mapping[str, Any]],
    customer_id: int,
) -> bool:
    is_static = require_customer_field(customers, customer_id, "is_static")
    if not isinstance(is_static, bool):
        raise TypeError(
            f"customer {customer_id} is_static must be bool, "
            f"got {type(is_static).__name__}"
        )
    return not is_static


def require_customer_time_window_index(
    customers: Mapping[int, Mapping[str, Any]],
    customer_id: int,
) -> int:
    value = require_customer_field(customers, customer_id, "time_window_index")
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError(
            f"customer {customer_id} time_window_index must be int, "
            f"got {type(value).__name__}"
        )
    if value < 0:
        raise ValueError(
            f"customer {customer_id} time_window_index must be non-negative, "
            f"got {value}"
        )
    return value


def calculate_weighted_cost(
    components: Mapping[str, float],
    cost_weights: Mapping[str, float] | None,
) -> float:
    weights = default_cost_weights() if cost_weights is None else cost_weights
    unknown_keys = set(weights) - SUPPORTED_COST_KEYS
    if unknown_keys:
        raise ValueError(f"cost_weights contains unsupported keys: {sorted(unknown_keys)}")
    missing_components = set(weights) - set(components)
    if missing_components:
        raise ValueError(f"cost components missing keys: {sorted(missing_components)}")
    return sum(components[key] * weight for key, weight in weights.items())


def _get_required_value(source, key: str):
    """从字典或对象中严格读取字段。"""
    if isinstance(source, dict):#检查 source 是否为字典类型。
        if key not in source:
            raise KeyError(f"drone task missing required key '{key}'")
        return source[key]
    if not hasattr(source, key):#如果 source 不是字典（即为对象），则使用 hasattr 检查该对象是否具有名为 key 的属性。
        raise AttributeError(f"drone task missing required attribute '{key}'")
    return getattr(source, key)


def recompute_segment_usage(sol):
    """
    根据卡车路径和无人机任务，重新计算每条卡车路段被无人机占用的次数。
    计数含义：
        若无人机任务从 launch 起飞，并在 recovery 回收，
        则卡车路径中 launch 到 recovery 之间的每一条连续路段使用次数 +1。
    需要的 sol 字段：
        sol.truck_paths: List[List[node]]
        sol.drone_tasks: List[task]
    需要的 task 字段：
        path_idx: 该任务所属卡车路径编号
        launch: 发射节点
        recovery: 回收节点
    返回：
        segment_usage_count[path_idx][(u, v)] = usage_count
    注意：
        这里不做兜底。路径编号非法、发射/回收节点缺失、发射点不在回收点之前，
        都会直接抛出异常。
    """
    """使用 hasattr 检查对象是否包含 truck_paths 和 drone_tasks 属性，缺失则抛出 AttributeError。
取出属性值后，检查是否为 None，若为 None 则抛出 ValueError。"""
    if not hasattr(sol, "truck_paths"):
        raise AttributeError("solution missing required attribute 'truck_paths'")
    if not hasattr(sol, "drone_tasks"):
        raise AttributeError("solution missing required attribute 'drone_tasks'")

    truck_paths = sol.truck_paths
    drone_tasks = sol.drone_tasks
    if truck_paths is None:
        raise ValueError("sol.truck_paths must not be None")
    if drone_tasks is None:
        raise ValueError("sol.drone_tasks must not be None")

    segment_usage_count = {}
    for path_idx, truck_path in enumerate(truck_paths):
        if len(truck_path) < 2:
            raise ValueError(f"truck path {path_idx} must contain at least two nodes")
        segment_usage_count[path_idx] = {}#为当前路径创建一个空字典
        for idx in range(len(truck_path) - 1):
            segment = (truck_path[idx], truck_path[idx + 1])
            #如果某条路段在当前路径内重复出现（例如 [(0,1),(1,2),(0,1)]），则报错（一般路径不应有重复边）
            if segment in segment_usage_count[path_idx]:
                raise ValueError(f"duplicate segment {segment} in truck path {path_idx}")
            segment_usage_count[path_idx][segment] = 0
    #遍历每个无人机任务，更新路段占用计数
    for task_idx, task in enumerate(drone_tasks):
        path_idx = _get_required_value(task, "path_idx")
        launch = _get_required_value(task, "launch")
        recovery = _get_required_value(task, "recovery")
        #校验 path_idx 是否为整数，以及是否在已初始化的路径索引范围内（即 segment_usage_count 中存在该键）。
        if not isinstance(path_idx, int):
            raise TypeError(f"drone task {task_idx} path_idx must be int, got {path_idx!r}")
        if path_idx not in segment_usage_count:
            raise IndexError(f"drone task {task_idx} has invalid path_idx={path_idx}")

        truck_path = truck_paths[path_idx]
        positions = {}
        #如果路径中出现重复节点（即路径不是简单路径），抛出 ValueError。这是为了确保发射点和回收点有唯一的位置。
        for pos, node in enumerate(truck_path):
            if node in positions:
                raise ValueError(f"node {node} appears more than once in truck path {path_idx}")
            positions[node] = pos
        #检查 launch 和 recovery 是否在卡车路径节点集合中，若不在则报错。
        if launch not in positions:
            raise ValueError(
                f"drone task {task_idx} launch node {launch} is not in truck path {path_idx}"
            )
        if recovery not in positions:
            raise ValueError(
                f"drone task {task_idx} recovery node {recovery} is not in truck path {path_idx}"
            )
        #获取两个节点在路径中的位置索引。
        launch_pos = positions[launch]
        recovery_pos = positions[recovery]
        if launch_pos >= recovery_pos:
            raise ValueError(
                f"drone task {task_idx} must launch before recovery on truck path {path_idx}: "
                f"launch_pos={launch_pos}, recovery_pos={recovery_pos}"
            )

        for pos in range(launch_pos, recovery_pos):
            segment = (truck_path[pos], truck_path[pos + 1])
            segment_usage_count[path_idx][segment] += 1

    sol.segment_usage_count = segment_usage_count
    return segment_usage_count




