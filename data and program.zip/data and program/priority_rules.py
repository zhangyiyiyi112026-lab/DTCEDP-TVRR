from typing import Any, Mapping


BASIC_DEMAND_PRIORITY_WEIGHT = 1.0
EMERGENCY_DEMAND_PRIORITY_WEIGHT = 5.0
STATIC_CUSTOMER_URGENCY_FACTOR = 1.0
DYNAMIC_CUSTOMER_URGENCY_FACTOR = 5.0


def require_customer_priority_weight(
    customer_id: int,
    customers: Mapping[int, Mapping[str, Any]],
) -> float:
    if customer_id not in customers:
        raise ValueError(f"customer {customer_id} is not in customers")
    customer = customers[customer_id]
    required_fields = {
        "basic_demand",
        "emergency_demand",
        "is_static",
    }
    missing_fields = required_fields - set(customer)
    if missing_fields:
        raise ValueError(
            f"customer {customer_id} missing required priority fields: "
            f"{sorted(missing_fields)}"
        )

    basic_demand = customer["basic_demand"]
    emergency_demand = customer["emergency_demand"]
    is_static = customer["is_static"]

    if isinstance(basic_demand, bool) or not isinstance(basic_demand, (int, float)):
        raise TypeError(
            f"customer {customer_id} basic_demand must be numeric, "
            f"got {type(basic_demand).__name__}"
        )
    if isinstance(emergency_demand, bool) or not isinstance(emergency_demand, (int, float)):
        raise TypeError(
            f"customer {customer_id} emergency_demand must be numeric, "
            f"got {type(emergency_demand).__name__}"
        )
    if basic_demand < 0:
        raise ValueError(f"customer {customer_id} basic_demand must be non-negative")
    if emergency_demand < 0:
        raise ValueError(f"customer {customer_id} emergency_demand must be non-negative")
    if not isinstance(is_static, bool):
        raise TypeError(
            f"customer {customer_id} is_static must be bool, "
            f"got {type(is_static).__name__}"
        )

    urgency_factor = (
        STATIC_CUSTOMER_URGENCY_FACTOR
        if is_static
        else DYNAMIC_CUSTOMER_URGENCY_FACTOR
    )
    return urgency_factor * (
        (BASIC_DEMAND_PRIORITY_WEIGHT if basic_demand > 0 else 0.0)
        + (EMERGENCY_DEMAND_PRIORITY_WEIGHT if emergency_demand > 0 else 0.0)
    )
