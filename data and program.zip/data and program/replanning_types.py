from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional, Set
import copy


@dataclass
class TruckReplanState:
    """
    卡车在某次重规划开始时的状态。

    locked_prefix:
        已经执行或已经承诺执行、不能再修改的路径前缀。
    anchor_node:
        后续重新规划的起点，必须是 locked_prefix 的最后一个节点。
    anchor_time:
        卡车到达 anchor_node 并能够继续执行新路径的时间。
    remaining_basic_load / remaining_emergency_load:
        卡车到达 anchor_node 后剩余的两类库存。
    """

    truck_id: int
    anchor_node: int
    anchor_position: int
    anchor_time: float
    remaining_basic_load: float
    remaining_emergency_load: float
    locked_prefix: List[int]
    onboard_drone_ids: List[int] = field(default_factory=list)
    completed_customer_ids: Set[int] = field(default_factory=set)

    def __post_init__(self) -> None:
        if isinstance(self.anchor_position, bool) or not isinstance(
            self.anchor_position,
            int,
        ):
            raise TypeError(
                f"anchor_position must be int, got {type(self.anchor_position).__name__}"
            )
        if self.anchor_position < 0:
            raise ValueError("anchor_position must be non-negative")
        if self.anchor_time < 0:
            raise ValueError("anchor_time must be non-negative")
        if self.remaining_basic_load < 0:
            raise ValueError("remaining_basic_load must be non-negative")
        if self.remaining_emergency_load < 0:
            raise ValueError("remaining_emergency_load must be non-negative")
        if not self.locked_prefix:
            raise ValueError("locked_prefix must not be empty")
        if self.locked_prefix[-1] != self.anchor_node:
            raise ValueError("locked_prefix must end with anchor_node")
        if self.anchor_position != len(self.locked_prefix) - 1:
            raise ValueError(
                "anchor_position must match the last index of locked_prefix"
            )


@dataclass
class DroneReplanState:
    """
    无人机在某次重规划开始时的状态。
    onboard:
        无人机已经回收到卡车上，可以执行新任务。
    airborne:
        无人机正在执行已经起飞的任务，在回收前不能重新分配。
    """

    truck_id: int
    drone_id: int
    status: Literal["onboard", "airborne"]
    task_id: Optional[int] = None
    launch_node: Optional[int] = None
    customer: Optional[int] = None
    recovery_node: Optional[int] = None
    launch_time: Optional[float] = None
    recovery_time: Optional[float] = None

    def __post_init__(self) -> None:
        if self.status not in {"onboard", "airborne"}:
            raise ValueError(f"invalid drone status: {self.status}")
        if self.status == "airborne":
            required_values = {
                "task_id": self.task_id,
                "launch_node": self.launch_node,
                "customer": self.customer,
                "recovery_node": self.recovery_node,
                "launch_time": self.launch_time,
                "recovery_time": self.recovery_time,
            }
            missing = [
                name
                for name, value in required_values.items()
                if value is None
            ]
            if missing:
                raise ValueError(f"airborne drone missing fields: {missing}")
            if self.recovery_time <= self.launch_time:
                raise ValueError("recovery_time must be greater than launch_time")


@dataclass
class ReplanContext:
    """
    某次重规划阶段需要保存的上下文。
    本对象只保存状态，不执行事件揭示、路径切分或 ALNS 搜索。
    """
    phase_index: int
    phase_start_time: float
    trigger_reason: str
    revealed_customer_ids: Set[int]
    newly_revealed_customer_ids: Set[int]
    future_dynamic_customer_ids: Set[int]
    completed_customer_ids: Set[int]
    locked_customer_ids: Set[int]
    locked_drone_task_ids: Set[int]
    truck_states: Dict[int, TruckReplanState]
    drone_states: Dict[int, DroneReplanState]

    def __post_init__(self) -> None:
        if self.phase_index < 0:
            raise ValueError("phase_index must be non-negative")
        if self.phase_start_time < 0:
            raise ValueError("phase_start_time must be non-negative")
        if not self.trigger_reason:
            raise ValueError("trigger_reason must not be empty")
        if not self.newly_revealed_customer_ids <= self.revealed_customer_ids:
            raise ValueError(
                "newly revealed customers must belong to revealed customers"
            )
        if self.future_dynamic_customer_ids & self.revealed_customer_ids:
            raise ValueError("future dynamic customers cannot be revealed")
        if not self.locked_customer_ids <= self.completed_customer_ids:
            raise ValueError("locked customers must be completed customers")


@dataclass
class LockedCostState:
    """Record executed costs that must not be charged again."""

    locked_cost_components: Dict[str, float] = field(
        default_factory=lambda: {
            "priority_cost": 0.0,
            "road_risk_cost": 0.0,
            "delay_penalty": 0.0,
        }
    )
    locked_edge_count_by_truck: Dict[int, int] = field(default_factory=dict)
    locked_customer_ids: Set[int] = field(default_factory=set)
    locked_drone_task_ids: Set[int] = field(default_factory=set)

    def __post_init__(self) -> None:
        required_keys = {
            "priority_cost",
            "road_risk_cost",
            "delay_penalty",
        }
        if set(self.locked_cost_components) != required_keys:
            raise ValueError(
                "locked_cost_components must contain exactly "
                f"{sorted(required_keys)}"
            )
        for key, value in self.locked_cost_components.items():
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise TypeError(f"locked_cost_components[{key}] must be numeric")
            if value < 0:
                raise ValueError(f"locked_cost_components[{key}] must be non-negative")
        if not isinstance(self.locked_edge_count_by_truck, dict):
            raise TypeError("locked_edge_count_by_truck must be a dict")
        for truck_id, edge_count in self.locked_edge_count_by_truck.items():
            if isinstance(truck_id, bool) or not isinstance(truck_id, int):
                raise TypeError("locked_edge_count_by_truck keys must be int")
            if isinstance(edge_count, bool) or not isinstance(edge_count, int):
                raise TypeError("locked edge counts must be int")
            if edge_count < 0:
                raise ValueError("locked edge counts must be non-negative")
        for field_name in ("locked_customer_ids", "locked_drone_task_ids"):
            value = getattr(self, field_name)
            if not isinstance(value, set):
                raise TypeError(f"{field_name} must be a set")

    @property
    def locked_executed_cost(self) -> float:
        return sum(self.locked_cost_components.values())


def validate_unique_drone_task_ids(
    drone_routes: List[Dict[str, Any]],
) -> None:
    """检查无人机任务 ID 是否存在且唯一。"""
    task_ids = []
    for index, task in enumerate(drone_routes):
        if "task_id" not in task:
            raise ValueError(f"drone task {index} missing task_id")
        task_id = task["task_id"]
        if not isinstance(task_id, int) or task_id <= 0:
            raise ValueError(f"invalid drone task_id: {task_id}")
        task_ids.append(task_id)
    if len(task_ids) != len(set(task_ids)):
        raise ValueError(f"duplicate drone task ids: {task_ids}")


def preview_next_drone_task_id(
    solution_data: Dict[str, Any],
) -> int:
    """读取下一个任务 ID，不修改原解。
    只查看“下一个新无人机任务应该用哪个编号”，但不真的修改解。"""
    task_id = solution_data["next_drone_task_id"]
    if not isinstance(task_id, int) or task_id <= 0:
        raise ValueError(f"invalid next_drone_task_id: {task_id}")
    return task_id

def append_new_drone_task(
    solution_data: Dict[str, Any],
    drone_task: Dict[str, Any],
) -> None:
    """唯一入口，负责把一个“已经决定采用”的无人机任务正式写入 solution_data["drone_routes"]，并同步推进 next_drone_task_id    候选任务先用：
task_id = preview_next_drone_task_id(sol.data)
得到当前应使用的编号。
等 move 真正被接受时，再调用：
append_new_drone_task(sol.data, drone_task)
这个函数会检查 drone_task["task_id"] 是否正好等于当前 next_drone_task_id，然后才追加任务并把计数器加 1。"""
    expected_task_id = preview_next_drone_task_id(solution_data)
    if drone_task["task_id"] != expected_task_id:
        raise ValueError(
            f"task_id must be {expected_task_id}, got {drone_task['task_id']}"
        )
    validate_unique_drone_task_ids(solution_data["drone_routes"])
    solution_data["drone_routes"].append(copy.deepcopy(drone_task))
    solution_data["next_drone_task_id"] += 1
    validate_unique_drone_task_ids(solution_data["drone_routes"])
