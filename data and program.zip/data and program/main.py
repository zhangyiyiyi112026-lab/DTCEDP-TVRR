from __future__ import annotations

import argparse
import csv
import json
import os
import time
from pathlib import Path

from ALNS import ALNS, Solution, _profile_enabled, _profile_print_summary, _profile_reset
from data_loader import compute_distances, load_solomon_data
from truck_routes import construct_initial_truck_routes, validate_truck_initial_solution
from UAV_routes import construct_drone_routes, validate_full_solution
from replanning_events import build_replanning_events, run_replanning_triggers


PROJECT_ROOT = Path(__file__).resolve().parent

TOTAL_COST_COMPONENT_KEYS = (
    "priority_cost",
    "road_risk_cost",
    "delay_penalty",
    "unserved_penalty_cost",
)


def instance_name_from_data_path(data_path: Path) -> str:
    stem = data_path.stem
    supported_suffixes = ("_with_time_windows", "_experiment")
    for suffix in supported_suffixes:
        if stem.endswith(suffix):
            return stem[: -len(suffix)]
    raise ValueError(
        "cannot infer instance name from data filename; expected one of "
        f"{supported_suffixes}: {data_path}"
    )


def infer_risk_csv_path(data_path: Path, period_count: int) -> Path:
    if isinstance(period_count, bool) or not isinstance(period_count, int):
        raise TypeError(f"period_count must be int, got {type(period_count).__name__}")
    if period_count <= 0:
        raise ValueError(f"period_count must be positive, got {period_count}")
    instance_name = instance_name_from_data_path(data_path)
    return (
        PROJECT_ROOT
        / "data11"
        / "scenarios"
        / f"risk_{instance_name}_period{period_count}_seed42.csv"
    )


#file：Python 内置变量，表示当前文件的路径（可能是相对路径或绝对路径）。

def _resolve_project_path(path_value, field_name: str) -> Path:
    if not isinstance(path_value, str) or not path_value:
        raise TypeError(f"experiment config {field_name} must be a non-empty string")
    path = Path(path_value)
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    return path


def apply_experiment_time_config(args) -> None:
    if not args.use_experiment_time_config:
        return None
    config_path = args.experiment_time_config
    if not config_path.is_absolute():
        config_path = PROJECT_ROOT / config_path
    if not config_path.exists():
        raise FileNotFoundError(
            f"experiment time config does not exist: {config_path}"
        )

    with config_path.open("r", encoding="utf-8") as source:
        config = json.load(source)

    required_root_keys = {"periods", "period_count", "instances"}
    missing_root_keys = required_root_keys - set(config)
    if missing_root_keys:
        raise ValueError(
            f"experiment time config missing root keys: {sorted(missing_root_keys)}"
        )
    periods = config["periods"]
    if not isinstance(periods, list) or not periods:
        raise TypeError('experiment time config "periods" must be a non-empty list')
    if any(isinstance(period, bool) or not isinstance(period, int) for period in periods):
        raise TypeError('experiment time config "periods" must contain only ints')
    if len(set(periods)) != len(periods):
        raise ValueError(
            f'experiment time config "periods" contains duplicates: {periods}'
        )
    period_count = config["period_count"]
    if isinstance(period_count, bool) or not isinstance(period_count, int):
        raise TypeError('experiment time config "period_count" must be int')
    if period_count != len(periods):
        raise ValueError(
            "experiment time config period_count does not match periods length: "
            f"{period_count} != {len(periods)}"
        )
    instances = config["instances"]
    if not isinstance(instances, dict):
        raise TypeError('experiment time config "instances" must be a dict')

    instance_name = instance_name_from_data_path(args.data)
    if instance_name not in instances:
        raise ValueError(
            f"experiment time config missing instance {instance_name!r}; "
            "add it to the config or run with --no-experiment-time-config"
        )
    instance_config = instances[instance_name]
    if not isinstance(instance_config, dict):
        raise TypeError(f"experiment config for {instance_name} must be a dict")
    required_instance_keys = {"period_length", "risk_csv"}
    missing_instance_keys = required_instance_keys - set(instance_config)
    if missing_instance_keys:
        raise ValueError(
            f"experiment config for {instance_name} missing keys: "
            f"{sorted(missing_instance_keys)}"
        )

    period_length = instance_config["period_length"]
    if isinstance(period_length, bool) or not isinstance(period_length, (int, float)):
        raise TypeError(
            f"experiment config period_length for {instance_name} must be numeric"
        )
    if period_length <= 0:
        raise ValueError(
            f"experiment config period_length for {instance_name} must be positive"
        )
    risk_csv = _resolve_project_path(instance_config["risk_csv"], "risk_csv")
    if not risk_csv.exists():
        raise FileNotFoundError(
            f"experiment config risk_csv for {instance_name} does not exist: "
            f"{risk_csv}"
        )

    args.periods = list(periods)
    args.period_length = float(period_length)
    args.risk_csv = risk_csv
    args.applied_experiment_time_config = {
        "config_path": config_path,
        "instance_name": instance_name,
        "period_length": args.period_length,
        "periods": list(args.periods),
        "risk_csv": risk_csv,
    }
    return None


def apply_algorithm_config(args) -> None:
    if args.algorithm == "greedy":
        if args.operator_set is None:
            args.operator_set = "basic"
        if args.acceptance_rule is None:
            args.acceptance_rule = "only_improve"
        args.forced_destroy_operator = None
        args.forced_repair_operator = None
    elif args.algorithm == "lns":
        if args.operator_set is None:
            args.operator_set = "basic"
        if args.acceptance_rule is None:
            args.acceptance_rule = "only_improve"
        if args.acceptance_rule != "only_improve":
            raise ValueError("--algorithm lns requires --acceptance-rule only_improve")
        args.forced_destroy_operator = "random"
        args.forced_repair_operator = "greedy"
    elif args.algorithm == "basic_alns":
        if args.operator_set is None:
            args.operator_set = "basic"
        if args.operator_set != "basic":
            raise ValueError("--algorithm basic_alns requires --operator-set basic")
        if args.acceptance_rule is None:
            args.acceptance_rule = "sa"
        args.forced_destroy_operator = None
        args.forced_repair_operator = None
    elif args.algorithm == "full_alns":
        if args.operator_set is None:
            args.operator_set = "full"
        if args.operator_set != "full":
            raise ValueError("--algorithm full_alns requires --operator-set full")
        if args.acceptance_rule is None:
            args.acceptance_rule = "sa"
        args.forced_destroy_operator = None
        args.forced_repair_operator = None
    elif args.algorithm == "full_alns_no_risk_ops":
        if args.operator_set is None:
            args.operator_set = "full_no_risk_ops"
        if args.operator_set != "full_no_risk_ops":
            raise ValueError(
                "--algorithm full_alns_no_risk_ops requires "
                "--operator-set full_no_risk_ops"
            )
        if args.acceptance_rule is None:
            args.acceptance_rule = "sa"
        if args.acceptance_rule != "sa":
            raise ValueError(
                "--algorithm full_alns_no_risk_ops requires --acceptance-rule sa"
            )
        args.forced_destroy_operator = None
        args.forced_repair_operator = None
    elif args.algorithm == "full_alns_no_drone_specialized_ops":
        if args.operator_set is None:
            args.operator_set = "full_no_drone_specialized_ops"
        if args.operator_set != "full_no_drone_specialized_ops":
            raise ValueError(
                "--algorithm full_alns_no_drone_specialized_ops requires "
                "--operator-set full_no_drone_specialized_ops"
            )
        if args.acceptance_rule is None:
            args.acceptance_rule = "sa"
        if args.acceptance_rule != "sa":
            raise ValueError(
                "--algorithm full_alns_no_drone_specialized_ops requires "
                "--acceptance-rule sa"
            )
        args.forced_destroy_operator = None
        args.forced_repair_operator = None
    else:
        raise ValueError(f"unknown algorithm: {args.algorithm}")


def normalize_every_for_algorithm(args):
    if args.algorithm == "lns":
        return None
    return args.normalize_every

def parse_args():
    parser = argparse.ArgumentParser(
        description="Run the truck-drone emergency logistics ALNS workflow."
    )
    parser.add_argument(
        "--data",
        type=Path,
        default=PROJECT_ROOT / "data3.0" / "c101_50_experiment.txt",
    )
    parser.add_argument(
        "--risk-csv",
        type=Path,
        default=PROJECT_ROOT / "data3.0" / "scenarios" / "risk_c101_50_period6_seed42.csv",
    )
    parser.add_argument(
        "--algorithm",
        choices=[
            "greedy",
            "lns",
            "basic_alns",
            "full_alns",
            "full_alns_no_risk_ops",
            "full_alns_no_drone_specialized_ops",
        ],
        default="full_alns",
    )#每个规模要匹配每个的车辆数！
    parser.add_argument(
        "--acceptance-rule",
        choices=["sa", "only_improve"],
        default=None,
    )
    parser.add_argument(
        "--operator-set",
        choices=[
            "basic",
            "full",
            "full_no_risk_ops",
            "full_no_drone_specialized_ops",
        ],
        default=None,
    )
    parser.add_argument("--truck-ids", type=int, nargs="+", default=[1, 2,3,4,5,6,7,8])#,3,4,5,6,7,8
    parser.add_argument("--depot-start", type=int, default=0)
    parser.add_argument("--replenishment-node", type=int, default=999)
    parser.add_argument("--periods", type=int, nargs="+", default=[1, 2, 3, 4, 5, 6])#,3,4,5,6,7,8
    parser.add_argument("--period-length", type=float, default=1.0)
    parser.add_argument(
        "--experiment-time-config",
        type=Path,
        default=PROJECT_ROOT / "data11" / "experiment_time_config.json",
    )
    parser.add_argument(
        "--no-experiment-time-config",
        action="store_false",
        dest="use_experiment_time_config",
    )
    parser.add_argument(
        "--use-experiment-time-config",
        action="store_true",
        dest="use_experiment_time_config",
    )
    parser.set_defaults(use_experiment_time_config=False)
    parser.add_argument("--calibrate-dynamic-times", action="store_true")
    parser.add_argument("--no-calibrate-dynamic-times", action="store_true")#程序默认情况下是会执行“动态时间校准”的。只有当你显式地在命令中加上 --no-calibrate-dynamic-times 时，才会跳过校准。
    parser.add_argument("--dynamic-reveal-start-fraction", type=float, default=0.05)
    parser.add_argument("--dynamic-reveal-end-fraction", type=float, default=0.45)
    parser.add_argument("--truck-speed-kmh", type=float, default=35.0)
    parser.add_argument("--drone-speed-kmh", type=float, default=50.0)
    parser.add_argument("--truck-capacity", type=float, default=500.0)
    parser.add_argument("--drone-capacity", type=float, default=30.0)
    parser.add_argument("--drone-endurance", type=float, default=1.0)
    parser.add_argument("--drones-per-truck", type=int, default=2)
    parser.add_argument("--risk-slowdown", type=float, default=0.15)
    parser.add_argument("--replenishment-time", type=float, default=0.0)
    parser.add_argument("--unserved-penalty", type=float, default=10000.0)
    parser.add_argument("--iters", type=int, default=500)
    parser.add_argument("--replanning", action="store_true", default=True)
    parser.add_argument("--phase1-iters", type=int, default=500)
    parser.add_argument("--replan-iters", type=int, default=500)
    parser.add_argument(
        "--trigger-source",
        choices=["dynamic_customers"],
        default="dynamic_customers",
    )
    parser.add_argument(
        "--reveal-all-dynamic-at-once",
        action="store_true",
        default=False,
    )
    parser.add_argument(
        "--separate-dynamic-reveals",
        action="store_false",
        dest="reveal_all_dynamic_at_once",
    )
    parser.add_argument("--remove-ratio", type=float, default=0.25)
    parser.add_argument("--temp-init", type=float, default=1.0)
    parser.add_argument("--temp-final", type=float, default=0.01)
    parser.add_argument("--normalize-every", type=int, default=50)#归一化算子权重的间隔迭代次数，默认每 50 次迭代归一化一次。
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--truck-insert-tw-radius", type=int, default=1)
    parser.add_argument("--output-dir", type=Path, default=PROJECT_ROOT / "result" / "main_runs")
    parser.add_argument(
        "--result-json",
        type=Path,
        default=None,
        help="Write one machine-readable final result JSON; existing files are never overwritten.",
    )
    #--no-save 是一个布尔标志（store_true）。如果命令行中出现了 --no-save，则对应属性值为 True；否则为 False。用于控制是否保存结果文件。
    parser.add_argument("--no-save", action="store_true")
    parser.add_argument(
        "--no-cost-breakdown",
        action="store_true",
        help="Do not print the final cost breakdown.",
    )
    parser.add_argument("--profile", action="store_true")
    args = parser.parse_args()
    if args.use_experiment_time_config:
        if args.risk_csv is not None:
            raise ValueError(
                "--risk-csv cannot be used with --experiment-time-config; "
                "run with --no-experiment-time-config for manual risk CSV"
            )
        apply_experiment_time_config(args)
    if args.risk_csv is None:
        raise ValueError(
            "--risk-csv is required when not using --use-experiment-time-config; "
            "manually pass the risk CSV that matches --data"
        )
    apply_algorithm_config(args)
    if args.calibrate_dynamic_times and args.no_calibrate_dynamic_times:
        raise ValueError(
            "--calibrate-dynamic-times and --no-calibrate-dynamic-times "
            "cannot be used together"
        )
    return args


def validate_args(args) -> None:
    if not args.data.exists():
        raise FileNotFoundError(f"data file does not exist: {args.data}")
    if not args.risk_csv.exists():
        raise FileNotFoundError(f"risk CSV does not exist: {args.risk_csv}")
    if not args.truck_ids:
        raise ValueError("--truck-ids must not be empty")
    if len(set(args.truck_ids)) != len(args.truck_ids):
        raise ValueError(f"--truck-ids contains duplicates: {args.truck_ids}")
    if not args.periods:
        raise ValueError("--periods must not be empty")
    if len(set(args.periods)) != len(args.periods):
        raise ValueError(f"--periods contains duplicates: {args.periods}")
    if args.period_length <= 0:
        raise ValueError("--period-length must be positive")
    if args.truck_speed_kmh <= 0:
        raise ValueError("--truck-speed-kmh must be positive")
    if args.drone_speed_kmh <= 0:
        raise ValueError("--drone-speed-kmh must be positive")
    if args.truck_capacity <= 0:
        raise ValueError("--truck-capacity must be positive")
    if args.drone_capacity <= 0:
        raise ValueError("--drone-capacity must be positive")
    if args.drone_endurance <= 0:
        raise ValueError("--drone-endurance must be positive")
    if args.drones_per_truck <= 0:
        raise ValueError("--drones-per-truck must be positive")
    if args.risk_slowdown < 0:
        raise ValueError("--risk-slowdown must be non-negative")
    if args.replenishment_time < 0:
        raise ValueError("--replenishment-time must be non-negative")
    if args.unserved_penalty < 0:
        raise ValueError("--unserved-penalty must be non-negative")
    if args.iters <= 0:
        raise ValueError("--iters must be positive")
    if args.phase1_iters is not None and args.phase1_iters <= 0:
        raise ValueError("--phase1-iters must be positive")
    if args.replan_iters is not None and args.replan_iters < 0:
        raise ValueError("--replan-iters must be non-negative")
    if not args.replanning and args.replan_iters is not None:
        raise ValueError(
            "--replan-iters requires --replanning; remove --replan-iters for "
            "normal ALNS, or add --replanning for dynamic replanning"
        )
    if args.remove_ratio <= 0 or args.remove_ratio > 1:
        raise ValueError("--remove-ratio must be in (0, 1]")
    if args.temp_init <= 0:
        raise ValueError("--temp-init must be positive")
    if args.temp_final <= 0:
        raise ValueError("--temp-final must be positive")
    if args.temp_final > args.temp_init:
        raise ValueError("--temp-final must not be greater than --temp-init")
    if args.normalize_every <= 0:
        raise ValueError("--normalize-every must be positive")
    if args.truck_insert_tw_radius < 0:
        raise ValueError("--truck-insert-tw-radius must be non-negative")
    if args.result_json is not None:
        if args.result_json.exists():
            raise FileExistsError(
                f"--result-json already exists and will not be overwritten: {args.result_json}"
            )
        if args.result_json.name in {"", ".", ".."}:
            raise ValueError(f"--result-json must name a file: {args.result_json}")
    if args.dynamic_reveal_start_fraction < 0:
        raise ValueError("--dynamic-reveal-start-fraction must be non-negative")
    if args.dynamic_reveal_end_fraction <= args.dynamic_reveal_start_fraction:
        raise ValueError(
            "--dynamic-reveal-end-fraction must be greater than "
            "--dynamic-reveal-start-fraction"
        )
    if args.dynamic_reveal_end_fraction > 1:
        raise ValueError("--dynamic-reveal-end-fraction must be at most 1")


def cost_weights():
    return {
        "priority_cost": 1.0,
        "unserved_penalty_cost": 1.0,
        "road_risk_cost": 1.0,
        "delay_penalty": 1.0,
    }


def convert_customers_for_route_evaluator(raw_customers, depot_start, depot_end, period_length):
    """该函数用于将原始客户数据（例如从 Solomon 格式数据加载得到的字典）转换成 route_evaluator
    和后续 ALNS 算法所要求的客户字段格式。它负责补全默认优先级、紧急度，并计算时间窗索引等派生字段。"""
    if period_length <= 0:
        raise ValueError(f"period_length must be positive, got {period_length}")

    converted = {}#初始化空字典 converted 用于存储转换后的客户数据
    for customer_id, customer in raw_customers.items():#遍历原始客户字典中的每一项
        if customer_id in {depot_start, depot_end}:
            continue

        demand_status = customer["demand_status"]
        if demand_status not in {"static", "dynamic"}:
            raise ValueError(
                f"customer {customer_id} demand_status must be static or dynamic, "
                f"got {demand_status}"
            )

        basic_demand = customer["q"]
        emergency_demand = customer["p"]
        converted[customer_id] = {
            "basic_demand": basic_demand,
            "emergency_demand": emergency_demand,
            "basic_priority": 1,
            "emergency_priority": 2 if emergency_demand > 0 else 1,
            "urgency": 5 if demand_status == "dynamic" or emergency_demand > 0 else 1,
            "is_static": demand_status == "static",
            "earliest": customer["ready_time"],
            "latest": customer["due_time"],
            "time_window_index": int(customer["ready_time"] // period_length),
            "service_time": 0.0,
            "release_time": customer["release_time"],
            "reveal_time": customer["release_time"],
        }
    return converted


def select_static_customers_for_phase1(customers):
    static_customers = {}
    for customer_id, customer in customers.items():
        if "is_static" not in customer:
            raise ValueError(f"customer {customer_id} missing required key: is_static")
        is_static = customer["is_static"]
        if not isinstance(is_static, bool):
            raise TypeError(
                f"customer {customer_id} is_static must be bool, "
                f"got {type(is_static).__name__}"
            )
        if is_static:
            static_customers[customer_id] = customer
    if not static_customers:
        raise ValueError("phase1 static customer set must not be empty")
    return static_customers


def build_nested_distance_matrix(raw_customers, node_ids, depot_start, depot_end, replenishment_node):
    #该函数用于构建一个嵌套的距离矩阵（dict of dict），其中 distance_matrix[i][j] 表示从节点 i 到节点 j 的距离。
    flat_distances = compute_distances(raw_customers)#raw_customers是 从 Solomon 格式数据文件中加载的原始客户数据字典
    distance_matrix = {i: {} for i in node_ids}
    same_place_nodes = {depot_start, depot_end, replenishment_node}

    def physical_node(node):
        if node in same_place_nodes:
            return depot_start
        return node

    for i in node_ids:
        for j in node_ids:
            if i == j:
                distance_matrix[i][j] = 0.0
                continue

            physical_i = physical_node(i)
            physical_j = physical_node(j)
            if physical_i == physical_j:
                distance_matrix[i][j] = 0.0
                continue

            key = (physical_i, physical_j)
            if key not in flat_distances:
                raise ValueError(f"distance matrix missing edge {key}")
            distance_matrix[i][j] = flat_distances[key]

    return distance_matrix


def load_nested_risk_matrix(csv_path, node_ids, periods):
    risk_matrix = {
        period: {
            i: {
                j: 0 if i == j else None
                for j in node_ids
            }
            for i in node_ids
        }
        for period in periods
    }#初始化一个三级嵌套字典。最外层键：时段 period。中层键：起点节点 i。内层键：终点节点 j。



    with csv_path.open("r", encoding="utf-8-sig", newline="") as source:
        reader = csv.DictReader(source)
        required_cols = {"period", "from_node", "to_node", "risk_level"}
        #检查 CSV 文件是否包含所有必需列。如果缺少某些列，计算差集并抛出 ValueError，列出缺失的列名（排序后）。
        missing_cols = required_cols.difference(reader.fieldnames or [])
        if missing_cols:
            raise ValueError(f"risk CSV missing required columns: {sorted(missing_cols)}")

        for row in reader:
            period = int(row["period"])
            from_node = int(row["from_node"])
            to_node = int(row["to_node"])
            risk_level = int(row["risk_level"])

            if period not in risk_matrix:
                raise ValueError(f"risk CSV contains unexpected period: {period}")
            if from_node not in risk_matrix[period]:
                raise ValueError(f"risk CSV contains unexpected from_node: {from_node}")
            if to_node not in risk_matrix[period][from_node]:
                raise ValueError(f"risk CSV contains unexpected to_node: {to_node}")
            if risk_level not in {0, 1, 2, 3, 4}:
                raise ValueError(
                    f"risk_level must be in 0-4: period={period}, "
                    f"edge=({from_node}, {to_node}), risk={risk_level}"
                )

            risk_matrix[period][from_node][to_node] = risk_level

    for period in periods:
        for i in node_ids:
            for j in node_ids:
                if risk_matrix[period][i][j] is None:
                    raise ValueError(f"risk matrix missing edge: period={period}, edge=({i}, {j})")

    return risk_matrix


def build_truck_time_matrix(
    distance_matrix,
    risk_matrix,
    node_ids,
    periods,
    truck_speed_m_per_hour,
    risk_slowdown,
):
    if truck_speed_m_per_hour <= 0:
        raise ValueError("truck_speed_m_per_hour must be positive")
    if risk_slowdown < 0:
        raise ValueError("risk_slowdown must be non-negative")

    truck_time_matrix = {period: {i: {} for i in node_ids} for period in periods}
    for period in periods:
        for i in node_ids:
            for j in node_ids:
                distance = distance_matrix[i][j]
                risk_level = risk_matrix[period][i][j]

                if i == j:
                    travel_time = 0.0
                elif risk_level == 4:
                    travel_time = float("inf")
                else:
                    effective_speed = truck_speed_m_per_hour * (1 - risk_slowdown * risk_level)
                    if effective_speed <= 0:
                        raise ValueError(
                            f"effective_speed must be positive: period={period}, edge=({i}, {j})"
                        )
                    travel_time = distance / effective_speed

                truck_time_matrix[period][i][j] = travel_time

    return truck_time_matrix


def build_drone_time_matrix(distance_matrix, node_ids, drone_speed_m_per_hour):
    if drone_speed_m_per_hour <= 0:
        raise ValueError("drone_speed_m_per_hour must be positive")

    return {
        i: {
            j: distance_matrix[i][j] / drone_speed_m_per_hour
            for j in node_ids
        }
        for i in node_ids
    }


def build_drone_resources(truck_ids, drones_per_truck, drone_capacity, drone_endurance):
    """该函数用于初始化无人机资源，根据每辆卡车携带的无人机数量，为每架无人机分配全局唯一的 ID"""
    drone_ids_by_truck = {}#每辆卡车拥有的无人机 ID 集合（drone_ids_by_truck）
    drone_capacity_by_drone = {}
    drone_endurance_by_drone = {}
    next_drone_id = 1#下一个可用的无人机 ID，从 1 开始

    for truck_id in truck_ids:
        drone_ids = set()
        for _ in range(drones_per_truck):
            drone_id = next_drone_id
            next_drone_id += 1
            drone_ids.add(drone_id)
            drone_capacity_by_drone[drone_id] = drone_capacity
            drone_endurance_by_drone[drone_id] = drone_endurance
        drone_ids_by_truck[truck_id] = drone_ids

    return drone_ids_by_truck, drone_capacity_by_drone, drone_endurance_by_drone


def print_solution_summary(label, sol):
    print(label)
    print(f"  cost={sol.data['cost']}")
    print(f"  feasible={sol.data['feasible']}")
    print(f"  served={sorted(sol.data['served'])}")
    print(f"  unserved={sorted(sol.data['unserved'])}")
    print("  truck_routes:")
    for truck_id in sorted(sol.data["truck_routes"]):
        print(f"    Truck {truck_id}: {sol.data['truck_routes'][truck_id]}")
    print("  drone_routes:")
    if not sol.data["drone_routes"]:
        print("    []")
    for task in sol.data["drone_routes"]:
        print(
            "    "
            f"truck={task['truck_id']}, "
            f"drone={task['drone_id']}, "
            f"{task['launch_node']} -> {task['customer']} -> {task['recovery_node']}, "
            f"period={task['period_index']}, "
            f"cost={task['cost']}"
        )


def calculate_solution_makespan(sol):
    if not hasattr(sol, "data"):
        raise TypeError("solution must expose data")
    if "validation_report" not in sol.data:
        raise ValueError('solution.data missing required key: validation_report')
    validation_report = sol.data["validation_report"]
    if not isinstance(validation_report, dict):
        raise TypeError('solution.data["validation_report"] must be a dict')
    if "truck_evaluations" not in validation_report:
        raise ValueError('validation_report missing required key: truck_evaluations')
    truck_evaluations = validation_report["truck_evaluations"]
    if not isinstance(truck_evaluations, dict):
        raise TypeError('validation_report["truck_evaluations"] must be a dict')
    #初始化结束时间列表：用于收集每辆卡车路径上最后一个节点的离开时间。
    end_times = []
    for truck_id, evaluation in truck_evaluations.items():
        if not isinstance(evaluation, dict):
            raise TypeError(f"truck evaluation of truck {truck_id} must be a dict")
        if "timeline_by_position" not in evaluation:
            raise ValueError(
                f"truck evaluation of truck {truck_id} missing timeline_by_position"
            )
        timeline_by_position = evaluation["timeline_by_position"]
        if not isinstance(timeline_by_position, dict):
            raise TypeError(
                f'truck evaluation of truck {truck_id} "timeline_by_position" '
                "must be a dict"
            )
        if not timeline_by_position:
            raise ValueError(f"truck {truck_id} timeline_by_position must not be empty")
        last_position = max(timeline_by_position)#获得最大索引，即路径的最后一个节点
        last_record = timeline_by_position[last_position]
        if not isinstance(last_record, dict):
            raise TypeError(
                f"truck {truck_id} timeline record {last_position} must be a dict"
            )
        if "departure_time" not in last_record:
            raise ValueError(
                f"truck {truck_id} final timeline record missing departure_time"
            )
        departure_time = last_record["departure_time"]
        if isinstance(departure_time, bool) or not isinstance(
            departure_time,
            (int, float),
        ):
            raise TypeError(
                f"truck {truck_id} final departure_time must be numeric, "
                f"got {type(departure_time).__name__}"
            )
        if departure_time < 0:
            raise ValueError(f"truck {truck_id} final departure_time is negative")
        end_times.append(departure_time)

    if not end_times:
        raise ValueError("cannot calculate makespan from empty truck_evaluations")
    return max(end_times)#返回最大完工时间


def calibrate_dynamic_customer_times(
    customers,
    phase1_makespan,
    start_fraction,
    end_fraction,
):
    '''customers：客户数据字典，包含所有客户（静态和动态）的信息。该字典会被直接修改（添加原始时间备份并覆盖 release_time 和 reveal_time）。
    start_fraction：时间窗口起始比例（例如 0.05，表示在 makespan 的 5% 处开始）
    end_fraction：时间窗口结束比例（例如 0.45，表示在 makespan 的 45% 处结束）。要求 end_fraction > start_fraction 且 end_fraction ≤ 1。'''
    if isinstance(phase1_makespan, bool) or not isinstance(phase1_makespan, (int, float)):
        raise TypeError(
            f"phase1_makespan must be numeric, got {type(phase1_makespan).__name__}"
        )
    if phase1_makespan <= 0:
        raise ValueError(f"phase1_makespan must be positive, got {phase1_makespan}")
    if start_fraction < 0:
        raise ValueError("start_fraction must be non-negative")
    if end_fraction <= start_fraction:
        raise ValueError("end_fraction must be greater than start_fraction")
    if end_fraction > 1:
        raise ValueError("end_fraction must be at most 1")

    dynamic_customer_ids = []#收集所有动态客户
    for customer_id, customer in customers.items():
        if "is_static" not in customer:
            raise ValueError(f"customer {customer_id} missing required key: is_static")
        if not isinstance(customer["is_static"], bool):
            raise TypeError(
                f'customers[{customer_id}]["is_static"] must be bool, '
                f"got {type(customer['is_static']).__name__}"
            )
        if customer["is_static"]:
            continue
        for field_name in ("release_time", "reveal_time"):
            if field_name not in customer:
                raise ValueError(
                    f"dynamic customer {customer_id} missing required key: {field_name}"
                )
            value = customer[field_name]
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise TypeError(
                    f"dynamic customer {customer_id} {field_name} must be numeric, "
                    f"got {type(value).__name__}"
                )
        dynamic_customer_ids.append(customer_id)

    if not dynamic_customer_ids:
        return {
            "dynamic_customer_count": 0,
            "start_time": None,
            "end_time": None,
            "assigned_times": {},
        }
    '''按 reveal_time（揭示时间）升序排列；若相同，则按 release_time（释放时间）升序；若仍相同，按客户 ID 升序。'''
    dynamic_customer_ids.sort(
        key=lambda customer_id: (
            customers[customer_id]["reveal_time"],
            customers[customer_id]["release_time"],
            customer_id,
        )
    )
    start_time = phase1_makespan * start_fraction
    end_time = phase1_makespan * end_fraction
    if len(dynamic_customer_ids) == 1:
        assigned_times = {
            dynamic_customer_ids[0]: (start_time + end_time) / 2.0
        }#若只有一个动态客户，则将其时间设在窗口的中点。
    else:
        step = (end_time - start_time) / (len(dynamic_customer_ids) - 1)
        assigned_times = {
            customer_id: start_time + index * step
            for index, customer_id in enumerate(dynamic_customer_ids)
        }#则按排序后的顺序在 start_time 和 end_time 之间均匀线性分布（步长 = 区间长度 / (客户数 - 1)）。

    for customer_id, assigned_time in assigned_times.items():
        customer = customers[customer_id]
        customer["original_release_time"] = customer["release_time"]#保存原始数据
        customer["original_reveal_time"] = customer["reveal_time"]
        customer["release_time"] = assigned_time#更新客户时间
        customer["reveal_time"] = assigned_time
    #返回校准报告
    return {
        "dynamic_customer_count": len(dynamic_customer_ids),
        "start_time": start_time,
        "end_time": end_time,
        "assigned_times": dict(assigned_times),
    }


def merge_dynamic_replanning_events_once(events):
    if not isinstance(events, list):
        raise TypeError("events must be a list")
    if not events:
        raise ValueError("--reveal-all-dynamic-at-once requires at least one dynamic event")

    trigger_times = []
    customer_ids = []
    seen_customer_ids = set()
    for event_index, event in enumerate(events):
        if not isinstance(event, dict):
            raise TypeError(f"event {event_index} must be a dict")
        for required_key in ("trigger_time", "customer_ids"):
            if required_key not in event:
                raise ValueError(
                    f"event {event_index} missing required key: {required_key}"
                )

        trigger_time = event["trigger_time"]
        if isinstance(trigger_time, bool) or not isinstance(trigger_time, (int, float)):
            raise TypeError(
                f"event {event_index} trigger_time must be numeric, "
                f"got {type(trigger_time).__name__}"
            )
        if trigger_time < 0:
            raise ValueError(f"event {event_index} trigger_time must be non-negative")
        trigger_times.append(float(trigger_time))

        event_customer_ids = event["customer_ids"]
        if not isinstance(event_customer_ids, list):
            raise TypeError(f"event {event_index} customer_ids must be a list")
        if not event_customer_ids:
            raise ValueError(f"event {event_index} customer_ids must not be empty")
        for customer_id in event_customer_ids:
            if isinstance(customer_id, bool) or not isinstance(customer_id, int):
                raise TypeError(
                    f"event {event_index} customer_id must be int, "
                    f"got {type(customer_id).__name__}"
                )
            if customer_id in seen_customer_ids:
                raise ValueError(f"dynamic customer {customer_id} appears in multiple events")
            seen_customer_ids.add(customer_id)
            customer_ids.append(customer_id)

    return [
        {
            "trigger_time": min(trigger_times),
            "customer_ids": sorted(customer_ids),
        }
    ]


def final_dynamic_cost_report(sol):
    if "replanning_report" not in sol.data:
        return None
    replanning_report = sol.data["replanning_report"]
    if not isinstance(replanning_report, dict):
        raise TypeError('solution.data["replanning_report"] must be a dict')
    if "final_dynamic_cost_report" not in replanning_report:
        raise ValueError("replanning_report missing final_dynamic_cost_report")
    report = replanning_report["final_dynamic_cost_report"]
    if not isinstance(report, dict):
        raise TypeError("final_dynamic_cost_report must be a dict")
    required_keys = {
        "dynamic_total_cost",
        "locked_executed_cost",
        "active_suffix_cost",
    }
    missing_keys = required_keys - set(report)
    if missing_keys:
        raise ValueError(
            f"final_dynamic_cost_report missing keys: {sorted(missing_keys)}"
        )
    return report


def solution_service_counts(sol, customers, depot_start, depot_end, replenishment_node):
    truck_served = set()
    for truck_id in sorted(sol.data["truck_routes"]):
        route = sol.data["truck_routes"][truck_id]
        for node in route:
            if node in {depot_start, depot_end, replenishment_node}:
                continue
            if node not in customers:
                raise ValueError(f"truck route contains unknown customer {node}")
            truck_served.add(node)

    drone_served = set()
    for task_index, task in enumerate(sol.data["drone_routes"]):
        if "customer" not in task:
            raise ValueError(f"drone task {task_index} missing required key: customer")
        customer_id = task["customer"]
        if customer_id not in customers:
            raise ValueError(f"drone task {task_index} contains unknown customer {customer_id}")
        drone_served.add(customer_id)

    return {
        "served_count": len(sol.data["served"]),
        "unserved_count": len(sol.data["unserved"]),
        "drone_served_count": len(drone_served),
        "truck_served_count": len(truck_served),
        "replenishment_count": sum(
            route.count(replenishment_node)
            for route in sol.data["truck_routes"].values()
        ),
    }


def _require_total_cost_components(components, label):
    if not isinstance(components, dict):
        raise TypeError(f"{label} must be a dict")
    missing_keys = [key for key in TOTAL_COST_COMPONENT_KEYS if key not in components]
    if missing_keys:
        raise ValueError(f"{label} missing required keys: {missing_keys}")
    return {key: float(components[key]) for key in TOTAL_COST_COMPONENT_KEYS}


def ledger_total_cost_components(sol):
    if "validation_report" not in sol.data:
        raise ValueError("solution missing validation_report")
    validation_report = sol.data["validation_report"]
    if "cost_ledger" not in validation_report:
        raise ValueError("validation_report missing cost_ledger")
    cost_ledger = validation_report["cost_ledger"]
    if not isinstance(cost_ledger, dict):
        raise TypeError("validation_report cost_ledger must be a dict")
    if "cost_components" not in cost_ledger:
        raise ValueError("cost_ledger missing cost_components")
    return _require_total_cost_components(
        cost_ledger["cost_components"],
        "cost_ledger cost_components",
    )


def objective_total_cost_components(sol):
    dynamic_report = final_dynamic_cost_report(sol)
    if dynamic_report is not None:
        if "dynamic_cost_components" not in dynamic_report:
            raise ValueError("final_dynamic_cost_report missing dynamic_cost_components")
        return _require_total_cost_components(
            dynamic_report["dynamic_cost_components"],
            "dynamic_cost_components",
        )
    return ledger_total_cost_components(sol)


def print_total_cost_components(title, components):
    checked = _require_total_cost_components(components, title)
    print(title)
    for key in TOTAL_COST_COMPONENT_KEYS:
        print(f"  {key}={checked[key]}")
    print(f"  total_cost_component_sum={sum(checked.values())}")


def solution_cost_components(sol):
    if "validation_report" not in sol.data:
        raise ValueError("solution missing validation_report")
    if "truck_evaluations" not in sol.data["validation_report"]:
        raise ValueError("validation_report missing truck_evaluations")
    if "cost_info" not in sol.data:
        raise ValueError("solution missing cost_info")

    truck_priority_cost = 0.0
    truck_risk_cost = 0.0
    truck_delay_penalty = 0.0
    drone_priority_cost = 0.0
    drone_delay_penalty = 0.0

    for truck_id, evaluation in sol.data["validation_report"]["truck_evaluations"].items():
        for key in ("priority_cost", "road_risk_cost", "delay_penalty"):
            if key not in evaluation:
                raise ValueError(f"truck evaluation {truck_id} missing {key}")
        truck_priority_cost += evaluation["priority_cost"]
        truck_risk_cost += evaluation["road_risk_cost"]
        truck_delay_penalty += evaluation["delay_penalty"]

    for task_index, task in enumerate(sol.data["drone_routes"]):
        if "evaluation" not in task:
            raise ValueError(f"drone task {task_index} missing evaluation")
        evaluation = task["evaluation"]
        for key in ("priority_cost", "delay_penalty"):
            if key not in evaluation:
                raise ValueError(f"drone task {task_index} evaluation missing {key}")
        drone_priority_cost += evaluation["priority_cost"]
        drone_delay_penalty += evaluation["delay_penalty"]

    cost_info = sol.data["cost_info"]
    if "unserved_penalty_cost" not in cost_info:
        raise ValueError("cost_info missing unserved_penalty_cost")

    return {
        "truck_priority_cost": truck_priority_cost,
        "truck_risk_cost": truck_risk_cost,
        "truck_delay_penalty": truck_delay_penalty,
        "drone_priority_cost": drone_priority_cost,
        "drone_delay_penalty": drone_delay_penalty,
        "unserved_penalty_cost": cost_info["unserved_penalty_cost"],
    }


def print_cost_breakdown(title, components):
    required_keys = [
        "truck_priority_cost",
        "truck_risk_cost",
        "truck_delay_penalty",
        "drone_priority_cost",
        "drone_delay_penalty",
        "unserved_penalty_cost",
    ]
    missing_keys = [key for key in required_keys if key not in components]
    if missing_keys:
        raise ValueError(f"cost components missing required keys: {missing_keys}")

    print(title)
    for key in required_keys:
        print(f"  {key}={components[key]}")


def _format_rate(served_count, total_count):
    if total_count == 0:
        return "N/A (total=0)"
    return f"{served_count / total_count:.4f} ({served_count}/{total_count})"


def _require_numeric(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{label} must be numeric, got {type(value).__name__}")
    return float(value)


def _drone_task_time(task, field_name, task_index):
    if field_name in task:
        return _require_numeric(task[field_name], f"drone task {task_index} {field_name}")
    evaluation = task.get("evaluation")
    if not isinstance(evaluation, dict):
        raise ValueError(f"drone task {task_index} missing evaluation")
    if field_name in evaluation:
        return _require_numeric(
            evaluation[field_name],
            f"drone task {task_index} evaluation {field_name}",
        )
    recomputed = evaluation.get("recomputed")
    if isinstance(recomputed, dict) and field_name in recomputed:
        return _require_numeric(
            recomputed[field_name],
            f"drone task {task_index} recomputed {field_name}",
        )
    raise ValueError(f"drone task {task_index} missing time field: {field_name}")


def _served_group_counts(served_ids, customer_ids):
    total_count = len(customer_ids)
    served_count = len(served_ids.intersection(customer_ids))
    return served_count, total_count


def _period_for_time(current_time, periods, period_length):
    current_time = _require_numeric(current_time, "current_time")
    period_length = _require_numeric(period_length, "period_length")
    if period_length <= 0:
        raise ValueError(f"period_length must be positive, got {period_length}")
    if not periods:
        raise ValueError("periods must not be empty")
    period_index = int(current_time // period_length)
    if period_index < 0:
        raise ValueError(f"period index must be non-negative, got {period_index}")
    if period_index >= len(periods):
        period_index = len(periods) - 1
    return periods[period_index]


def solution_console_metrics(
    sol,
    customers,
    depot_start,
    depot_end,
    replenishment_node,
    risk_matrix,
    periods,
    period_length,
):
    customer_ids = set(customers)
    served_ids = set(sol.data["served"]).intersection(customer_ids)
    static_ids = {
        customer_id
        for customer_id, customer in customers.items()
        if customer["is_static"]
    }
    dynamic_ids = customer_ids - static_ids
    urgent_ids = {
        customer_id
        for customer_id, customer in customers.items()
        if customer["emergency_demand"] > 0
    }
    service_counts = solution_service_counts(
        sol,
        customers,
        depot_start=depot_start,
        depot_end=depot_end,
        replenishment_node=replenishment_node,
    )

    truck_evaluations = sol.data["validation_report"]["truck_evaluations"]
    truck_service_start_by_customer = {}
    truck_total_distance = 0.0
    high_risk_road_use_count = 0
    for truck_id, route in sol.data["truck_routes"].items():
        if truck_id not in truck_evaluations:
            raise ValueError(f"truck_evaluations missing truck_id {truck_id}")
        evaluation = truck_evaluations[truck_id]
        truck_total_distance += _require_numeric(
            evaluation["total_distance"],
            f"truck {truck_id} total_distance",
        )
        arrival_times = evaluation["arrival_times"]
        departure_times_by_index = evaluation.get("departure_times_by_index")
        for edge_index, (from_node, to_node) in enumerate(zip(route, route[1:])):
            if departure_times_by_index is not None:
                edge_start_time = departure_times_by_index[edge_index]
            else:
                edge_start_time = arrival_times[from_node]
            period = _period_for_time(edge_start_time, periods, period_length)
            risk_level = risk_matrix[period][from_node][to_node]
            if risk_level >= 3:
                high_risk_road_use_count += 1
        for customer_id in route:
            if customer_id not in customers:
                continue
            if customer_id not in arrival_times:
                raise ValueError(
                    f"truck {truck_id} arrival_times missing customer {customer_id}"
                )
            arrival_time = _require_numeric(
                arrival_times[customer_id],
                f"truck {truck_id} customer {customer_id} arrival_time",
            )
            release_time = _require_numeric(
                customers[customer_id]["release_time"],
                f"customer {customer_id} release_time",
            )
            truck_service_start_by_customer[customer_id] = max(arrival_time, release_time)

    drone_service_start_by_customer = {}
    for task_index, task in enumerate(sol.data["drone_routes"]):
        customer_id = task["customer"]
        drone_service_start_by_customer[customer_id] = _drone_task_time(
            task,
            "customer_service_start",
            task_index,
        )

    dynamic_response_times = []
    for customer_id in sorted(dynamic_ids.intersection(served_ids)):
        release_time = _require_numeric(
            customers[customer_id]["release_time"],
            f"customer {customer_id} release_time",
        )
        if customer_id in drone_service_start_by_customer:
            service_start = drone_service_start_by_customer[customer_id]
        elif customer_id in truck_service_start_by_customer:
            service_start = truck_service_start_by_customer[customer_id]
        else:
            raise ValueError(f"served dynamic customer {customer_id} missing service time")
        dynamic_response_times.append(max(0.0, service_start - release_time))

    objective_components = objective_total_cost_components(sol)
    return {
        "cost_components": objective_components,
        "overall_service": _served_group_counts(served_ids, customer_ids),
        "static_service": _served_group_counts(served_ids, static_ids),
        "dynamic_service": _served_group_counts(served_ids, dynamic_ids),
        "urgent_service": _served_group_counts(served_ids, urgent_ids),
        "unserved_count": len(set(sol.data["unserved"]).intersection(customer_ids)),
        "dynamic_response_times": dynamic_response_times,
        "truck_served_count": service_counts["truck_served_count"],
        "drone_served_count": service_counts["drone_served_count"],
        "drone_task_count": len(sol.data["drone_routes"]),
        "truck_total_distance": truck_total_distance,
        "high_risk_road_use_count": high_risk_road_use_count,
        "risk_exposure_level": objective_components["road_risk_cost"],
    }


def print_console_result_report(
    sol,
    customers,
    depot_start,
    depot_end,
    replenishment_node,
    risk_matrix,
    periods,
    period_length,
    elapsed_seconds,
):
    metrics = solution_console_metrics(
        sol=sol,
        customers=customers,
        depot_start=depot_start,
        depot_end=depot_end,
        replenishment_node=replenishment_node,
        risk_matrix=risk_matrix,
        periods=periods,
        period_length=period_length,
    )
    cost_components = metrics["cost_components"]
    total_served = metrics["overall_service"][0]
    drone_served_count = metrics["drone_served_count"]
    if total_served == 0:
        drone_service_ratio = "N/A (served=0)"
    else:
        drone_service_ratio = f"{drone_served_count / total_served:.4f} ({drone_served_count}/{total_served})"
    dynamic_response_times = metrics["dynamic_response_times"]
    if dynamic_response_times:
        dynamic_response_time_text = (
            f"avg={sum(dynamic_response_times) / len(dynamic_response_times):.6f}, "
            f"min={min(dynamic_response_times):.6f}, "
            f"max={max(dynamic_response_times):.6f}, "
            f"count={len(dynamic_response_times)}"
        )
    else:
        dynamic_response_time_text = "N/A (served_dynamic=0)"

    print("\n" + "=" * 60)
    print("最终实验指标")
    print("=" * 60)
    print("成本构成：")
    print(f"  优先级成本={cost_components['priority_cost']}")
    print(f"  道路风险成本={cost_components['road_risk_cost']}")
    print(f"  延迟成本={cost_components['delay_penalty']}")
    print(f"  未服务惩罚成本={cost_components['unserved_penalty_cost']}")
    print("服务效果记录：")
    print(f"  总体客户服务率={_format_rate(*metrics['overall_service'])}")
    print(f"  静态客户服务率={_format_rate(*metrics['static_service'])}")
    print(f"  动态客户服务率={_format_rate(*metrics['dynamic_service'])}")
    print(f"  紧急客户服务率={_format_rate(*metrics['urgent_service'])}")
    print(f"  未服务客户数={metrics['unserved_count']}")
    print(f"  动态客户响应时间={dynamic_response_time_text}")
    print("卡车-无人机协同记录：")
    print(f"  卡车服务客户数={metrics['truck_served_count']}")
    print(f"  无人机服务客户数={metrics['drone_served_count']}")
    print(f"  无人机任务数={metrics['drone_task_count']}")
    print(f"  无人机服务比例={drone_service_ratio}")
    print(f"  卡车总行驶距离={metrics['truck_total_distance']}")
    print(f"  高风险道路使用次数={metrics['high_risk_road_use_count']}")
    print(f"  风险暴露水平={metrics['risk_exposure_level']}")
    print("计算性能记录：")
    print(f"  总运行时间={elapsed_seconds:.6f}")

def save_solution_summary(
    output_dir,
    initial_solution,
    best_solution,
    elapsed_seconds,
    alns,
    args,
    customers,
    depot_end,
):
    """该函数用于将 ALNS 最终得到的最优解（best_solution）以及优化耗时（elapsed_seconds）保存到指定目录的 solution_summary.txt 文件中。
    调用方负责传入带时间戳的唯一目录；若目录已存在则报错，避免覆盖旧结果。"""
    output_dir.mkdir(parents=True, exist_ok=False)
    summary_path = output_dir / "solution_summary.txt"

    best_cost_components = solution_cost_components(best_solution)
    best_objective_cost_components = objective_total_cost_components(best_solution)
    dynamic_report = final_dynamic_cost_report(best_solution)

    with summary_path.open("w", encoding="utf-8") as target:
        target.write(f"elapsed_seconds={elapsed_seconds:.6f}\n")
        target.write(f"cost={best_solution.data['cost']}\n")
        target.write(f"merged_full_route_cost={best_solution.data['cost']}\n")
        if dynamic_report is not None:
            target.write(
                f"dynamic_total_cost={dynamic_report['dynamic_total_cost']}\n"
            )
            target.write(
                f"locked_executed_cost={dynamic_report['locked_executed_cost']}\n"
            )
            target.write(
                f"active_suffix_cost={dynamic_report['active_suffix_cost']}\n"
            )
        target.write(f"best_iteration={best_solution.data['best_iteration']}\n")
        target.write(f"feasible={best_solution.data['feasible']}\n")
        target.write(f"served={sorted(best_solution.data['served'])}\n")
        target.write(f"unserved={sorted(best_solution.data['unserved'])}\n")
        target.write("truck_routes=\n")
        for truck_id in sorted(best_solution.data["truck_routes"]):
            target.write(f"  Truck {truck_id}: {best_solution.data['truck_routes'][truck_id]}\n")
        target.write("drone_routes=\n")
        for task in best_solution.data["drone_routes"]:
            target.write(
                "  "
                f"truck={task['truck_id']}, "
                f"drone={task['drone_id']}, "
                f"{task['launch_node']} -> {task['customer']} -> {task['recovery_node']}, "
                f"period={task['period_index']}, "
                f"cost={task['cost']}\n"
            )
        target.write("objective_cost_components=\n")
        for key in TOTAL_COST_COMPONENT_KEYS:
            target.write(f"  {key}={best_objective_cost_components[key]}\n")
        target.write(
            f"  total_cost_component_sum={sum(best_objective_cost_components.values())}\n"
        )
        target.write("cost_breakdown=\n")
        for key in (
            "truck_priority_cost",
            "truck_risk_cost",
            "truck_delay_penalty",
            "drone_priority_cost",
            "drone_delay_penalty",
            "unserved_penalty_cost",
        ):
            target.write(f"  {key}={best_cost_components[key]}\n")
        target.write(f"cost_info={best_solution.data['cost_info']}\n")
        target.write(f"violations={best_solution.data['full_validation_report']['violations']}\n")
        target.write(f"warnings={best_solution.data['full_validation_report']['warnings']}\n")

    return summary_path


def save_machine_readable_result(
    result_path,
    args,
    best_solution,
    customers,
    depot_end,
    risk_matrix,
    elapsed_seconds,
    summary_path,
):
    metrics = solution_console_metrics(
        sol=best_solution,
        customers=customers,
        depot_start=args.depot_start,
        depot_end=depot_end,
        replenishment_node=args.replenishment_node,
        risk_matrix=risk_matrix,
        periods=args.periods,
        period_length=args.period_length,
    )
    components = metrics["cost_components"]
    _require_total_cost_components(components, "machine-readable result")

    def service_group(values, label):
        served_count, total_count = values
        if isinstance(served_count, bool) or not isinstance(served_count, int):
            raise TypeError(f"{label} served_count must be int")
        if isinstance(total_count, bool) or not isinstance(total_count, int):
            raise TypeError(f"{label} total_count must be int")
        if served_count < 0 or total_count < 0 or served_count > total_count:
            raise ValueError(
                f"invalid {label} service counts: served={served_count}, total={total_count}"
            )
        return {
            "served": served_count,
            "total": total_count,
            "rate": None if total_count == 0 else served_count / total_count,
        }

    response_times = [
        _require_numeric(value, f"dynamic_response_times[{index}]")
        for index, value in enumerate(metrics["dynamic_response_times"])
    ]
    if response_times:
        response_summary = {
            "count": len(response_times),
            "average": sum(response_times) / len(response_times),
            "minimum": min(response_times),
            "maximum": max(response_times),
        }
    else:
        response_summary = {
            "count": 0,
            "average": None,
            "minimum": None,
            "maximum": None,
        }

    payload = {
        "schema_version": 1,
        "instance": instance_name_from_data_path(args.data),
        "data_path": str(args.data.resolve()),
        "risk_csv": str(args.risk_csv.resolve()),
        "algorithm": args.algorithm,
        "operator_set": args.operator_set,
        "acceptance_rule": args.acceptance_rule,
        "registered_operators": {
            "phase1": args.phase1_registered_operators,
            "replanning": args.replanning_registered_operators,
        },
        "seed": args.seed,
        "iterations": {
            "iters": args.iters,
            "phase1_iters": args.phase1_iters,
            "replan_iters": args.replan_iters,
        },
        "resources": {
            "truck_ids": list(args.truck_ids),
            "drones_per_truck": args.drones_per_truck,
            "truck_capacity": args.truck_capacity,
            "drone_capacity": args.drone_capacity,
            "drone_endurance": args.drone_endurance,
        },
        "risk_periods": {
            "periods": list(args.periods),
            "period_length": args.period_length,
        },
        "elapsed_seconds": _require_numeric(elapsed_seconds, "elapsed_seconds"),
        "feasible": best_solution.data["feasible"] is True,
        "best_iteration": best_solution.data["best_iteration"],
        "cost_components": {
            key: _require_numeric(components[key], f"cost_components.{key}")
            for key in TOTAL_COST_COMPONENT_KEYS
        },
        "total_cost": sum(components[key] for key in TOTAL_COST_COMPONENT_KEYS),
        "service": {
            "overall": service_group(metrics["overall_service"], "overall"),
            "static": service_group(metrics["static_service"], "static"),
            "dynamic": service_group(metrics["dynamic_service"], "dynamic"),
            "urgent": service_group(metrics["urgent_service"], "urgent"),
            "unserved_count": metrics["unserved_count"],
        },
        "dynamic_response_time": response_summary,
        "truck_drone": {
            "truck_served_count": metrics["truck_served_count"],
            "drone_served_count": metrics["drone_served_count"],
            "drone_task_count": metrics["drone_task_count"],
            "drone_service_ratio": (
                None
                if metrics["overall_service"][0] == 0
                else metrics["drone_served_count"] / metrics["overall_service"][0]
            ),
            "truck_total_distance": _require_numeric(
                metrics["truck_total_distance"], "truck_total_distance"
            ),
            "high_risk_road_use_count": metrics["high_risk_road_use_count"],
            "risk_exposure_level": _require_numeric(
                metrics["risk_exposure_level"], "risk_exposure_level"
            ),
        },
        "summary_path": None if summary_path is None else str(summary_path.resolve()),
    }
    if payload["feasible"] is not True:
        raise ValueError("refusing to write result JSON for an infeasible final solution")
    result_path.parent.mkdir(parents=True, exist_ok=True)
    with result_path.open("x", encoding="utf-8") as target:
        json.dump(payload, target, ensure_ascii=False, indent=2)
        target.write("\n")
    return result_path


def main():
    args = parse_args()
    if args.profile:
        os.environ["ALNS_PROFILE"] = "1"
        os.environ["ALNS_PROFILE_SESSION_ACTIVE"] = "1"
        _profile_reset()
    validate_args(args)

    start_clock = time.time()
    truck_speed_m_per_hour = args.truck_speed_kmh * 1000.0#这两行代码将用户输入的卡车速度和无人机速度从公里每小时（km/h）转换为米每小时（m/h）
    drone_speed_m_per_hour = args.drone_speed_kmh * 1000.0
    weights = cost_weights()

    print("=" * 60)
    print("Truck-drone emergency logistics ALNS workflow")
    print("=" * 60)
    print(f"data={args.data}")
    print(f"risk_csv={args.risk_csv}")
    print(
        "algorithm="
        f"{args.algorithm}, operator_set={args.operator_set}, "
        f"acceptance_rule={args.acceptance_rule}, "
        f"forced_destroy={args.forced_destroy_operator}, "
        f"forced_repair={args.forced_repair_operator}"
    )
    if hasattr(args, "applied_experiment_time_config"):
        applied_config = args.applied_experiment_time_config
        print(
            "experiment_time_config="
            f"{applied_config['config_path']} "
            f"instance={applied_config['instance_name']} "
            f"period_length={applied_config['period_length']} "
            f"periods={applied_config['periods']}"
        )

    print("\n1. Load instance data")
    raw_customers, depot_end = load_solomon_data(str(args.data))
    customers = convert_customers_for_route_evaluator(
        raw_customers=raw_customers,
        depot_start=args.depot_start,
        depot_end=depot_end,
        period_length=args.period_length,
    )
    if args.replanning:
        phase1_customers = select_static_customers_for_phase1(customers)
        dynamic_customer_count = len(customers) - len(phase1_customers)
        print(
            "  replanning enabled: "
            f"phase1_static_customers={len(phase1_customers)}, "
            f"dynamic_customers={dynamic_customer_count}"
        )
    else:
        phase1_customers = customers
    node_ids = [args.depot_start] + sorted(customers) + [depot_end, args.replenishment_node]

    print("\n2. Build distance, risk, truck time, and drone time matrices")
    distance_matrix = build_nested_distance_matrix(
        raw_customers=raw_customers,
        node_ids=node_ids,
        depot_start=args.depot_start,
        depot_end=depot_end,
        replenishment_node=args.replenishment_node,
    )
    risk_matrix = load_nested_risk_matrix(
        csv_path=args.risk_csv,
        node_ids=node_ids,
        periods=args.periods,
    )
    truck_time_matrix = build_truck_time_matrix(
        distance_matrix=distance_matrix,
        risk_matrix=risk_matrix,
        node_ids=node_ids,
        periods=args.periods,
        truck_speed_m_per_hour=truck_speed_m_per_hour,
        risk_slowdown=args.risk_slowdown,
    )
    drone_distance_matrix = distance_matrix
    drone_time_matrix = build_drone_time_matrix(
        distance_matrix=distance_matrix,
        node_ids=node_ids,
        drone_speed_m_per_hour=drone_speed_m_per_hour,
    )

    truck_capacity_by_truck = {
        truck_id: args.truck_capacity
        for truck_id in args.truck_ids
    }
    (
        drone_ids_by_truck,
        drone_capacity_by_drone,
        drone_endurance_by_drone,
    ) = build_drone_resources(
        truck_ids=args.truck_ids,
        drones_per_truck=args.drones_per_truck,
        drone_capacity=args.drone_capacity,
        drone_endurance=args.drone_endurance,
    )

    print("\n3. Construct initial truck routes")
    solution_data = construct_initial_truck_routes(
        truck_ids=args.truck_ids,
        customers=phase1_customers,
        distance_matrix=distance_matrix,
        truck_time_matrix=truck_time_matrix,
        risk_matrix=risk_matrix,
        periods=args.periods,
        period_length=args.period_length,
        truck_capacity_by_truck=truck_capacity_by_truck,
        depot_start=args.depot_start,
        depot_end=depot_end,
        replenishment_node=args.replenishment_node,
        start_time=0.0,
        replenishment_time=args.replenishment_time,
        cost_weights=weights,
        depot_node_for_sort=args.depot_start,
    )

    print("\n4. Validate initial truck solution")
    truck_report = validate_truck_initial_solution(
        solution=solution_data,
        customers=phase1_customers,
        truck_ids=args.truck_ids,
        distance_matrix=distance_matrix,
        truck_time_matrix=truck_time_matrix,
        risk_matrix=risk_matrix,
        periods=args.periods,
        period_length=args.period_length,
        truck_capacity_by_truck=truck_capacity_by_truck,
        depot_start=args.depot_start,
        depot_end=depot_end,
        replenishment_node=args.replenishment_node,
        start_time=0.0,
        replenishment_time=args.replenishment_time,
        cost_weights=weights,
        update_solution=True,
        raise_error=True,
    )
    if not truck_report["valid"] or not truck_report["feasible"]:
        raise ValueError(f"initial truck solution invalid: {truck_report}")

    print("\n5. Construct initial drone routes for unserved customers")
    solution_data, drone_report = construct_drone_routes(
        solution=solution_data,
        customers=phase1_customers,
        drone_ids_by_truck=drone_ids_by_truck,
        distance_matrix=distance_matrix,
        truck_time_matrix=truck_time_matrix,
        risk_matrix=risk_matrix,
        drone_distance_matrix=drone_distance_matrix,
        drone_time_matrix=drone_time_matrix,
        truck_capacity_by_truck=truck_capacity_by_truck,
        drone_capacity_by_drone=drone_capacity_by_drone,
        drone_endurance_by_drone=drone_endurance_by_drone,
        periods=args.periods,
        period_length=args.period_length,
        depot_start=args.depot_start,
        depot_end=depot_end,
        replenishment_node=args.replenishment_node,
        start_time=0.0,
        replenishment_time=args.replenishment_time,
        cost_weights=weights,
        truck_cost_weights=weights,
        unserved_penalty=args.unserved_penalty,
        update_solution=True,
    )
    print(
        "  "
        f"drone_assigned={drone_report['assigned_count']}, "
        f"remaining_unserved={drone_report['remaining_unserved']}"
    )

    print("\n6. Validate full initial solution")
    full_report = validate_full_solution(
        solution=solution_data,
        customers=phase1_customers,
        drone_ids_by_truck=drone_ids_by_truck,
        depot_start=args.depot_start,
        depot_end=depot_end,
        replenishment_node=args.replenishment_node,
        periods=args.periods,
        period_length=args.period_length,
        unserved_penalty=args.unserved_penalty,
        update_solution=True,
        raise_error=True,
    )
    if not full_report["valid"] or not full_report["feasible"]:
        raise ValueError(f"full initial solution invalid: {full_report}")

    print("\n7. Initialize ALNS")
    alns = ALNS(
        customers=phase1_customers,
        distance_matrix=distance_matrix,
        truck_time_matrix=truck_time_matrix,
        risk_matrix=risk_matrix,
        drone_distance_matrix=drone_distance_matrix,
        drone_time_matrix=drone_time_matrix,
        periods=args.periods,
        period_length=args.period_length,
        truck_capacity_by_truck=truck_capacity_by_truck,
        drone_capacity_by_drone=drone_capacity_by_drone,
        drone_endurance_by_drone=drone_endurance_by_drone,
        drone_ids_by_truck=drone_ids_by_truck,
        depot_start=args.depot_start,
        depot_end=depot_end,
        replenishment_node=args.replenishment_node,
        cost_weights=weights,
        unserved_penalty=args.unserved_penalty,
        truck_insert_tw_radius=args.truck_insert_tw_radius,
        random_seed=args.seed,
        forced_destroy_operator=args.forced_destroy_operator,
        forced_repair_operator=args.forced_repair_operator,
        operator_set=args.operator_set,
        acceptance_rule=args.acceptance_rule,
    )
    args.phase1_registered_operators = alns.registered_operator_names()
    args.replanning_registered_operators = None

    initial_solution = Solution(solution_data)
    alns._rebuild_solution(initial_solution)
    initial_solution, initial_drone_repair_report = alns.repair_initial_unserved_by_drone(
        initial_solution
    )
    alns._rebuild_solution(initial_solution, full_validate=True)
    if (
        not initial_solution.data["full_validation_report"]["valid"]
        or not initial_solution.data["full_validation_report"]["feasible"]
    ):
        raise ValueError(
            "initial solution invalid after ALNS initial drone repair: "
            f"{initial_solution.data['full_validation_report']}"
        )
    print(
        "ALNS initial drone repair "
        f"assigned={initial_drone_repair_report['assigned_count']}, "
        f"before_unserved={initial_drone_repair_report['before_unserved']}, "
        f"remaining_unserved={initial_drone_repair_report['after_unserved']}, "
        f"rejected_insert_moves={initial_drone_repair_report['rejected_insert_moves_count']}"
    )
    print_solution_summary("Initial solution", initial_solution)

    phase1_iterations = args.phase1_iters if args.phase1_iters is not None else args.iters
    replan_iterations = args.replan_iters if args.replan_iters is not None else args.iters
    effective_normalize_every = normalize_every_for_algorithm(args)
    if args.algorithm == "greedy":
        phase1_iterations = 0
        replan_iterations = 0

    print("\n8. Run ALNS")
    if args.algorithm == "greedy":
        print("  algorithm=greedy, skip ALNS search")
        best_solution = initial_solution.deepcopy()
        best_solution.data["best_iteration"] = 0
    else:
        if args.replanning:
            print(f"  phase1_iters={phase1_iterations}")
        best_solution = alns.solve(
            init=initial_solution,
            iters=phase1_iterations,
            x_remove=args.remove_ratio,
            temp_init=args.temp_init,
            temp_final=args.temp_final,
            normalize_every=effective_normalize_every,
            stage_breaks=(0.3, 0.7),
            verbose=True,
        )
    alns._rebuild_solution(best_solution, full_validate=True)
    phase1_best_solution = best_solution
    replanning_period_length = args.period_length
    phase1_makespan = None
    if args.replanning and args.calibrate_dynamic_times:
        phase1_makespan = calculate_solution_makespan(phase1_best_solution)
        dynamic_time_report = calibrate_dynamic_customer_times(
            customers=customers,
            phase1_makespan=phase1_makespan,
            start_fraction=args.dynamic_reveal_start_fraction,
            end_fraction=args.dynamic_reveal_end_fraction,
        )
        print(
            "  calibrated_dynamic_times="
            f"count={dynamic_time_report['dynamic_customer_count']}, "
            f"window=[{dynamic_time_report['start_time']}, "
            f"{dynamic_time_report['end_time']}]"
        )

    replanning_report = None
    if args.replanning:
        print("\n9. Run dynamic replanning")
        if args.trigger_source != "dynamic_customers":
            raise ValueError(f"unsupported trigger_source: {args.trigger_source}")
        events = build_replanning_events(customers)
        if args.reveal_all_dynamic_at_once:
            events = merge_dynamic_replanning_events_once(events)
            print(
                "  reveal_all_dynamic_at_once=True, "
                f"trigger_time={events[0]['trigger_time']}, "
                f"customer_ids={events[0]['customer_ids']}"
            )
        print(
            "  "
            f"trigger_source={args.trigger_source}, "
            f"event_count={len(events)}, "
            f"replan_iters={replan_iterations}"
        )
        replan_alns = ALNS(
            customers=customers,
            distance_matrix=distance_matrix,
            truck_time_matrix=truck_time_matrix,
            risk_matrix=risk_matrix,
            drone_distance_matrix=drone_distance_matrix,
            drone_time_matrix=drone_time_matrix,
            periods=args.periods,
            period_length=replanning_period_length,
            truck_capacity_by_truck=truck_capacity_by_truck,
            drone_capacity_by_drone=drone_capacity_by_drone,
            drone_endurance_by_drone=drone_endurance_by_drone,
            drone_ids_by_truck=drone_ids_by_truck,
            depot_start=args.depot_start,
            depot_end=depot_end,
            replenishment_node=args.replenishment_node,
            cost_weights=weights,
            unserved_penalty=args.unserved_penalty,
            truck_insert_tw_radius=args.truck_insert_tw_radius,
            random_seed=args.seed,
        forced_destroy_operator=args.forced_destroy_operator,
        forced_repair_operator=args.forced_repair_operator,
        operator_set=args.operator_set,
        acceptance_rule=args.acceptance_rule,
        )
        args.replanning_registered_operators = replan_alns.registered_operator_names()
        replan_alns.allow_drone_insertions = True
        best_solution, replanning_report = run_replanning_triggers(
            initial_solution=best_solution,
            customers=customers,
            depot_end=depot_end,
            alns=replan_alns,
            drone_ids_by_truck=drone_ids_by_truck,
            iters=replan_iterations,
            events=events,
            first_phase_index=2,
            trigger_reason="dynamic_customer_reveal",
            x_remove=args.remove_ratio,
            temp_init=args.temp_init,
            temp_final=args.temp_final,
            normalize_every=effective_normalize_every,
            stage_breaks=(0.3, 0.7),
            verbose=True,
        )
        alns = replan_alns
        alns._rebuild_solution(best_solution, full_validate=True)
        if "best_iteration" not in best_solution.data:
            if "best_iteration" not in phase1_best_solution.data:
                raise ValueError("phase1 solution missing best_iteration")
            best_solution.data["best_iteration"] = phase1_best_solution.data["best_iteration"]
        best_solution.data["phase1_best_iteration"] = phase1_best_solution.data["best_iteration"]
        best_solution.data["replanning_report"] = replanning_report
        if best_solution.data["feasible"] is not True:
            raise ValueError(
                "final replanning solution infeasible: "
                f"{best_solution.data['full_validation_report']}"
            )

    elapsed_seconds = time.time() - start_clock
    print("\n" + "=" * 60)
    print("Optimization finished")
    print("=" * 60)
    print(f"elapsed_seconds={elapsed_seconds:.2f}")
    print_solution_summary("Best solution", best_solution)
    dynamic_report = final_dynamic_cost_report(best_solution)
    if dynamic_report is not None:
        print("Best objective")
        print(f"  dynamic_total_cost={dynamic_report['dynamic_total_cost']}")
        print(f"  merged_full_route_cost={best_solution.data['cost']}")
        print(f"  locked_executed_cost={dynamic_report['locked_executed_cost']}")
        print(f"  active_suffix_cost={dynamic_report['active_suffix_cost']}")
    print_total_cost_components(
        "Objective cost components",
        objective_total_cost_components(best_solution),
    )
    print("Best validation")
    print(f"  valid={best_solution.data['full_validation_report']['valid']}")
    print(f"  feasible={best_solution.data['full_validation_report']['feasible']}")
    print(f"  violations={best_solution.data['full_validation_report']['violations']}")
    print(f"  warnings={best_solution.data['full_validation_report']['warnings']}")
    print(f"  cost_info={best_solution.data['cost_info']}")
    if replanning_report is not None:
        print("Replanning report")
        print(f"  executed_phase_count={replanning_report['executed_phase_count']}")
        print(f"  locked_executed_cost={replanning_report['locked_executed_cost']}")
        print(
            "  final_dynamic_cost_report="
            f"{replanning_report['final_dynamic_cost_report']}"
        )
        for trigger_report in replanning_report["phase_reports"]:
            phase_report = trigger_report["phase_report"]
            diagnostics = phase_report["remaining_unserved_diagnostics"]
            if not diagnostics:
                continue
            print(
                "  phase "
                f"{phase_report['phase_index']} remaining_unserved_diagnostics:"
            )
            for diagnostic in diagnostics:
                print(
                    "    "
                    f"customer={diagnostic['customer']}, "
                    f"is_static={diagnostic['is_static']}, "
                    f"in_initial_pool={diagnostic['in_initial_repair_pool']}, "
                    f"newly_revealed={diagnostic['newly_revealed']}, "
                    f"truck_candidates={diagnostic['truck_candidate_count']}, "
                    f"drone_candidates={diagnostic['drone_candidate_count']}, "
                    "initial_repair_rejected_reasons="
                    f"{diagnostic['initial_repair_rejected_reason_counts']}"
                )
                detail_counts = diagnostic["initial_repair_rejected_detail_counts"]
                if detail_counts:
                    top_details = sorted(
                        detail_counts.items(),
                        key=lambda item: (-item[1], item[0]),
                    )[:3]
                    print(
                        "      post_rebuild_detail_counts="
                        f"{dict(top_details)}"
                    )
    print_console_result_report(
        sol=best_solution,
        customers=customers,
        depot_start=args.depot_start,
        depot_end=depot_end,
        replenishment_node=args.replenishment_node,
        risk_matrix=risk_matrix,
        periods=args.periods,
        period_length=args.period_length,
        elapsed_seconds=elapsed_seconds,
    )

    if not args.no_cost_breakdown:
        print_cost_breakdown("Cost breakdown", solution_cost_components(best_solution))
    if _profile_enabled():
        _profile_print_summary()

    summary_path = None
    if not args.no_save:
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        instance_name = instance_name_from_data_path(args.data)
        run_dir = args.output_dir / f"{timestamp}_{instance_name}_seed_{args.seed}_iters_{args.iters}"
        summary_path = save_solution_summary(
            output_dir=run_dir,
            initial_solution=initial_solution,
            best_solution=best_solution,
            elapsed_seconds=elapsed_seconds,
            alns=alns,
            args=args,
            customers=customers,
            depot_end=depot_end,
        )
        print(f"Saved summary: {summary_path}")
    if args.result_json is not None:
        result_path = save_machine_readable_result(
            result_path=args.result_json,
            args=args,
            best_solution=best_solution,
            customers=customers,
            depot_end=depot_end,
            risk_matrix=risk_matrix,
            elapsed_seconds=elapsed_seconds,
            summary_path=summary_path,
        )
        print(f"Saved result JSON: {result_path}")


if __name__ == "__main__":
    main()
