from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict

from replanning_types import LockedCostState, ReplanContext

if TYPE_CHECKING:
    from ALNS import Solution


LOCKED_COMPONENT_KEYS = (
    "priority_cost",
    "road_risk_cost",
    "delay_penalty",
)


def _require_cost_ledger(solution: "Solution") -> Dict[str, Any]:
    if not hasattr(solution, "data"):
        raise TypeError("solution must expose data")
    if "validation_report" not in solution.data:
        raise ValueError("solution missing validation_report")
    validation_report = solution.data["validation_report"]
    if not isinstance(validation_report, dict):
        raise TypeError('solution.data["validation_report"] must be a dict')
    if "cost_ledger" not in validation_report:
        raise ValueError('solution.data["validation_report"] missing cost_ledger')
    cost_ledger = validation_report["cost_ledger"]
    if not isinstance(cost_ledger, dict):
        raise TypeError("cost_ledger must be a dict")
    return cost_ledger


def _require_ledger_section(
    cost_ledger: Dict[str, Any],
    section_name: str,
) -> Dict[Any, Any]:
    if section_name not in cost_ledger:
        raise ValueError(f"cost_ledger missing section: {section_name}")
    section = cost_ledger[section_name]
    if not isinstance(section, dict):
        raise TypeError(f"cost_ledger[{section_name}] must be a dict")
    return section


def _require_numeric(value: Any, label: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{label} must be numeric")
    if value < 0:
        raise ValueError(f"{label} must be non-negative")
    return float(value)


def calculate_executed_cost_increment(
    full_solution: "Solution",
    context: ReplanContext,
    locked_cost_state: LockedCostState,
) -> Dict[str, Any]:
    """Return the newly executed cost increment without mutating locked state."""

    if not isinstance(context, ReplanContext):
        raise TypeError("context must be a ReplanContext")
    if not isinstance(locked_cost_state, LockedCostState):
        raise TypeError("locked_cost_state must be a LockedCostState")
    if "feasible" not in full_solution.data:
        raise ValueError("full_solution missing feasible")
    if full_solution.data["feasible"] is not True:
        raise ValueError("full_solution must be feasible before locking costs")

    cost_ledger = _require_cost_ledger(full_solution)
    edge_costs_by_truck = _require_ledger_section(
        cost_ledger,
        "truck_edge_road_risk_cost_by_position",
    )
    priority_cost_by_customer = _require_ledger_section(
        cost_ledger,
        "priority_cost_by_customer",
    )
    delay_penalty_by_customer = _require_ledger_section(
        cost_ledger,
        "delay_penalty_by_customer",
    )
    drone_cost_by_task_id = _require_ledger_section(
        cost_ledger,
        "drone_cost_by_task_id",
    )

    increment_components = {
        "priority_cost": 0.0,
        "road_risk_cost": 0.0,
        "delay_penalty": 0.0,
    }
    new_locked_edge_count_by_truck = {}

    for truck_id, truck_state in context.truck_states.items():
        current_locked_edge_count = max(0, len(truck_state.locked_prefix) - 1)
        previous_locked_edge_count = (
            locked_cost_state.locked_edge_count_by_truck.get(truck_id, 0)
        )
        if current_locked_edge_count < previous_locked_edge_count:
            raise ValueError(
                f"truck {truck_id} locked edge count decreased from "
                f"{previous_locked_edge_count} to {current_locked_edge_count}"
            )
        if truck_id not in edge_costs_by_truck:
            raise ValueError(f"cost_ledger missing edge costs for truck {truck_id}")
        truck_edge_costs = edge_costs_by_truck[truck_id]
        if not isinstance(truck_edge_costs, dict):
            raise TypeError(f"edge cost ledger for truck {truck_id} must be a dict")
        for edge_position in range(
            previous_locked_edge_count,
            current_locked_edge_count,
        ):
            if edge_position not in truck_edge_costs:
                raise ValueError(
                    f"cost_ledger missing truck {truck_id} edge {edge_position}"
                )
            increment_components["road_risk_cost"] += _require_numeric(
                truck_edge_costs[edge_position],
                f"truck {truck_id} edge {edge_position} road risk cost",
            )
        new_locked_edge_count_by_truck[truck_id] = current_locked_edge_count

    newly_locked_customer_ids = (
        context.completed_customer_ids - locked_cost_state.locked_customer_ids
    )
    for customer_id in newly_locked_customer_ids:
        if customer_id not in priority_cost_by_customer:
            raise ValueError(
                f"cost_ledger missing priority cost for customer {customer_id}"
            )
        if customer_id not in delay_penalty_by_customer:
            raise ValueError(
                f"cost_ledger missing delay penalty for customer {customer_id}"
            )
        increment_components["priority_cost"] += _require_numeric(
            priority_cost_by_customer[customer_id],
            f"customer {customer_id} priority cost",
        )
        increment_components["delay_penalty"] += _require_numeric(
            delay_penalty_by_customer[customer_id],
            f"customer {customer_id} delay penalty",
        )

    newly_locked_drone_task_ids = (
        context.locked_drone_task_ids - locked_cost_state.locked_drone_task_ids
    )
    for task_id in newly_locked_drone_task_ids:
        if task_id in drone_cost_by_task_id:
            increment_components["priority_cost"] += _require_numeric(
                drone_cost_by_task_id[task_id],
                f"drone task {task_id} cost",
            )

    return {
        "increment_components": increment_components,
        "new_locked_edge_count_by_truck": new_locked_edge_count_by_truck,
        "newly_locked_customer_ids": set(newly_locked_customer_ids),
        "newly_locked_drone_task_ids": set(newly_locked_drone_task_ids),
    }


def commit_locked_cost_increment(
    locked_cost_state: LockedCostState,
    increment_result: Dict[str, Any],
) -> None:
    if not isinstance(locked_cost_state, LockedCostState):
        raise TypeError("locked_cost_state must be a LockedCostState")
    if not isinstance(increment_result, dict):
        raise TypeError("increment_result must be a dict")

    required_keys = {
        "increment_components",
        "new_locked_edge_count_by_truck",
        "newly_locked_customer_ids",
        "newly_locked_drone_task_ids",
    }
    missing_keys = required_keys - set(increment_result)
    if missing_keys:
        raise ValueError(f"increment_result missing keys: {sorted(missing_keys)}")

    increment_components = increment_result["increment_components"]
    if set(increment_components) != set(LOCKED_COMPONENT_KEYS):
        raise ValueError(
            "increment_components must contain exactly "
            f"{sorted(LOCKED_COMPONENT_KEYS)}"
        )
    for key, value in increment_components.items():
        locked_cost_state.locked_cost_components[key] += _require_numeric(
            value,
            f"increment_components[{key}]",
        )

    new_edge_counts = increment_result["new_locked_edge_count_by_truck"]
    if not isinstance(new_edge_counts, dict):
        raise TypeError("new_locked_edge_count_by_truck must be a dict")
    locked_cost_state.locked_edge_count_by_truck.update(new_edge_counts)

    newly_locked_customer_ids = increment_result["newly_locked_customer_ids"]
    newly_locked_drone_task_ids = increment_result["newly_locked_drone_task_ids"]
    if not isinstance(newly_locked_customer_ids, set):
        raise TypeError("newly_locked_customer_ids must be a set")
    if not isinstance(newly_locked_drone_task_ids, set):
        raise TypeError("newly_locked_drone_task_ids must be a set")
    locked_cost_state.locked_customer_ids.update(newly_locked_customer_ids)
    locked_cost_state.locked_drone_task_ids.update(newly_locked_drone_task_ids)


def calculate_dynamic_objective(
    locked_cost_state: LockedCostState,
    active_suffix_solution: "Solution",
) -> Dict[str, Any]:
    if not isinstance(locked_cost_state, LockedCostState):
        raise TypeError("locked_cost_state must be a LockedCostState")

    cost_ledger = _require_cost_ledger(active_suffix_solution)
    active_cost_components = _require_ledger_section(
        cost_ledger,
        "cost_components",
    )
    required_components = {
        "priority_cost",
        "road_risk_cost",
        "delay_penalty",
        "unserved_penalty_cost",
    }
    missing_components = required_components - set(active_cost_components)
    if missing_components:
        raise ValueError(
            "active cost_components missing keys: "
            f"{sorted(missing_components)}"
        )

    dynamic_cost_components = {
        "priority_cost": (
            locked_cost_state.locked_cost_components["priority_cost"]
            + _require_numeric(
                active_cost_components["priority_cost"],
                "active priority_cost",
            )
        ),
        "road_risk_cost": (
            locked_cost_state.locked_cost_components["road_risk_cost"]
            + _require_numeric(
                active_cost_components["road_risk_cost"],
                "active road_risk_cost",
            )
        ),
        "delay_penalty": (
            locked_cost_state.locked_cost_components["delay_penalty"]
            + _require_numeric(
                active_cost_components["delay_penalty"],
                "active delay_penalty",
            )
        ),
        "unserved_penalty_cost": _require_numeric(
            active_cost_components["unserved_penalty_cost"],
            "active unserved_penalty_cost",
        ),
    }
    active_suffix_cost = sum(
        _require_numeric(active_cost_components[key], f"active {key}")
        for key in required_components
    )
    dynamic_total_cost = sum(dynamic_cost_components.values())

    return {
        "locked_executed_cost": locked_cost_state.locked_executed_cost,
        "active_suffix_cost": active_suffix_cost,
        "dynamic_cost_components": dynamic_cost_components,
        "dynamic_total_cost": dynamic_total_cost,
    }
