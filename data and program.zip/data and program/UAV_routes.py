from __future__ import annotations

import math
from typing import Dict, Hashable, Mapping, Sequence, Tuple

from priority_rules import require_customer_priority_weight
from replanning_types import (
    append_new_drone_task,
    preview_next_drone_task_id,
    validate_unique_drone_task_ids,
)
from solution import refresh_depot_phase_start_state
from utils import (
    ROAD_RISK_DISTANCE_SCALE,
    FlatRiskDict,
    NestedRiskDict,
    SUPPORTED_COST_KEYS,
    calculate_drone_segment_time,
    calculate_truck_segment_time,
    calculate_weighted_cost,
    default_cost_weights,
    require_customer_field as require_common_customer_field,
    require_customer_is_dynamic,
    require_customer_load,
    require_nested_value,
    require_period_index,
    require_period_value,
)

NodeId = Hashable
DistanceMatrix = Mapping[Tuple[NodeId, NodeId], float]


def get_period_index(current_time: float, periods: Sequence[int], period_length: float) -> int:
    """根据当前时间返回周期索引；超过最后周期时使用最后一个周期索引。"""
    return require_period_index(current_time, periods, period_length)


def recompute_truck_arrival(
    path: Sequence[NodeId],
    D_ij: DistanceMatrix,
    v_t: float,
    start_time: float = 0.0,
    risk_level_dict: FlatRiskDict | NestedRiskDict | None = None,
    period_duration: float = 2.0,
    delta: float = 0.15,
    risk_cancel_level: int = 4,
) -> Dict[NodeId, float]:
    """
    计算卡车沿给定路径的各节点到达时间。
    返回：
        {node: arrival_time}
    若某段道路风险等级达到阻断等级，则抛出 ValueError。
    """
    arrivals: Dict[NodeId, float] = {path[0]: start_time}#创建一个字典 arrivals：键为节点 ID（NodeId），值为该节点的到达时间（浮点数）
    current_time = start_time

    for from_node, to_node in zip(path, path[1:]):
        travel_time = calculate_truck_segment_time(
            from_node=from_node,
            to_node=to_node,
            D_ij=D_ij,
            v_t=v_t,
            current_time=current_time,
            risk_level_dict=risk_level_dict,
            period_duration=period_duration,
            delta=delta,
            risk_cancel_level=risk_cancel_level,
        )
        current_time += travel_time
        arrivals[to_node] = current_time
    return arrivals


def compute_drone_arrival(
    path: Sequence[NodeId],
    start_time: float,
    D_ij: DistanceMatrix,
    v_d: float,
) -> Dict[NodeId, float]:
    """
    计算无人机沿给定路径的各节点到达时间。
    返回：
        {node: arrival_time}
    """
    arrivals: Dict[NodeId, float] = {path[0]: start_time}
    current_time = start_time
    for from_node, to_node in zip(path, path[1:]):
        travel_time = calculate_drone_segment_time(
            from_node=from_node,
            to_node=to_node,
            D_ij=D_ij,
            v_d=v_d,
        )
        current_time += travel_time
        arrivals[to_node] = current_time
    return arrivals


def evaluate_drone_sortie(
    truck_route,
    truck_evaluation,
    truck_id,
    drone_id,
    launch_node,
    customer_id,
    recovery_node,
    customers,
    drone_distance_matrix,
    drone_time_matrix,
    drone_capacity,
    drone_endurance,
    depot_start,
    depot_end,
    replenishment_node=999,
    periods=None,
    period_length=None,
    cost_weights=None,
    launch_idx=None,
    recovery_idx=None,
):
    """评价单次无人机任务 launch_node -> customer_id -> recovery_node。"""

    violations = []
    warnings = []
    occupied_segments = []# 无人机占用的卡车路段列表

    def get_customer_field(field_name):
        return require_common_customer_field(customers, customer_id, field_name)

    def get_matrix_value(matrix, from_node, to_node, matrix_name):
        return require_nested_value(
            matrix,
            from_node,
            to_node,
            matrix_name=matrix_name,
        )

    def build_result(
        feasible,
        launch_time=None,
        customer_arrival_time=None,
        customer_service_start=None,
        customer_departure_time=None,
        recovery_time=None,
        truck_recovery_arrival=None,
        truck_waiting_time=0.0,
        flight_distance=0.0,
        flight_time=0.0,
        total_drone_time=0.0,
        delay_penalty=0.0,
        priority_cost=0.0,
        road_risk_cost=0.0,
        unserved_penalty_cost=0.0,
        cost=0.0,
        period_index=None,
        launch_idx=None,
        recovery_idx=None,
    ):
        """构造统一的结果字典，包含所有评价指标。"""
        return {
            "feasible": feasible,
            "truck_id": truck_id,
            "drone_id": drone_id,
            "launch_node": launch_node,
            "launch_idx": launch_idx,
            "customer_id": customer_id,
            "recovery_node": recovery_node,
            "recovery_idx": recovery_idx,
            "launch_time": launch_time,
            "customer_arrival_time": customer_arrival_time,
            "customer_service_start": customer_service_start,
            "customer_departure_time": customer_departure_time,
            "recovery_time": recovery_time,
            "truck_recovery_arrival": truck_recovery_arrival,
            "truck_waiting_time": truck_waiting_time,
            "flight_distance": flight_distance,
            "flight_time": flight_time,
            "total_drone_time": total_drone_time,
            "delay_penalty": delay_penalty,
            "priority_cost": priority_cost,
            "road_risk_cost": road_risk_cost,
            "unserved_penalty_cost": unserved_penalty_cost,
            "cost": cost,
            "period_index": period_index,
            "occupied_segments": occupied_segments,
            "violations": violations,
            "warnings": warnings,
        }

    def make_infeasible_result(message, **kwargs):
        """统一返回不可行结果，保留已经计算出的信息。"""
        violations.append(message)
        return build_result(False, **kwargs)

    def calculate_sortie_cost(priority_cost, delay_penalty):
        return calculate_weighted_cost(
            {
                "priority_cost": priority_cost,
                "unserved_penalty_cost": 0.0,
                "road_risk_cost": 0.0,
                "delay_penalty": delay_penalty,
            },
            cost_weights,
        )

    def get_period_index(current_time):
        """返回时间所在周期索引；超过最后周期时使用最后一个周期索引。"""
        if periods is None and period_length is None:
            return None
        if periods is None or period_length is None:
            raise ValueError("periods and period_length must be provided together")
        return require_period_index(current_time, periods, period_length)

    # 一、基础合法性检查。
    if customer_id not in customers:
        return make_infeasible_result(f"customer_id {customer_id} is not in customers")
    if customer_id in {depot_start, depot_end, replenishment_node}:
        return make_infeasible_result(f"customer_id {customer_id} cannot be depot or replenishment node")
    if "is_static" not in customers[customer_id]:
        return make_infeasible_result(f"customer {customer_id} missing required field: is_static")
    if not isinstance(customers[customer_id]["is_static"], bool):
        return make_infeasible_result(
            f"customer {customer_id} is_static must be bool, "
            f"got {type(customers[customer_id]['is_static']).__name__}"
        )
    customer_is_static = customers[customer_id]["is_static"]
    if launch_node not in truck_route:
        return make_infeasible_result(f"launch_node {launch_node} is not in truck_route")
    if recovery_node not in truck_route:
        return make_infeasible_result(f"recovery_node {recovery_node} is not in truck_route")
    if launch_node == recovery_node:
        return make_infeasible_result("launch_node and recovery_node cannot be the same")

    # 第四部分：解析发射点和回收点在卡车路径中的位置索引
    def resolve_route_position(node, node_role, provided_index):
        """
                解析节点在卡车路径中的位置索引。
                若 provided_index 不为 None，则验证其有效性。
                否则，若节点在路径中唯一出现，则自动返回其位置；
                若出现多次，则必须提供索引（否则无法唯一确定）。
                """
        if provided_index is not None:
            if isinstance(provided_index, bool) or not isinstance(provided_index, int):
                return None, (
                    f"{node_role}_idx must be int, got "
                    f"{type(provided_index).__name__}"
                )
            if provided_index < 0 or provided_index >= len(truck_route):
                return None, (
                    f"{node_role}_idx {provided_index} outside truck_route length "
                    f"{len(truck_route)}"
                )
            if truck_route[provided_index] != node:
                return None, (
                    f"{node_role}_idx {provided_index} points to "
                    f"{truck_route[provided_index]}, expected {node}"
                )
            return provided_index, None
        # 未提供索引：查找节点在路径中的所有出现位置
        node_positions = [
            index
            for index, route_node in enumerate(truck_route)
            if route_node == node
        ]
        if len(node_positions) != 1:
            return None, (
                f"{node_role} {node} appears {len(node_positions)} times in "
                f"truck_route; {node_role}_idx is required"
            )
        return node_positions[0], None

    launch_pos, launch_pos_error = resolve_route_position(
        launch_node,
        "launch_node",
        launch_idx,
    )
    if launch_pos_error is not None:
        return make_infeasible_result(launch_pos_error)
    recovery_pos, recovery_pos_error = resolve_route_position(
        recovery_node,
        "recovery_node",
        recovery_idx,
    )
    if recovery_pos_error is not None:
        return make_infeasible_result(recovery_pos_error)
    if launch_pos >= recovery_pos:
        return make_infeasible_result(
            f"launch_node {launch_node} must appear before recovery_node {recovery_node}"
        )

    # 无人机从 launch_node 起飞到 recovery_node 回收期间，
    # 会占用卡车路径 launch_pos 到 recovery_pos 之间的每一条路段。
    occupied_segments = [
        (truck_id, seg_idx)
        for seg_idx in range(launch_pos, recovery_pos)
    ]


    if customer_id in truck_route:
        return make_infeasible_result(
            f"customer_id {customer_id} is already served by truck_route"
        )

    arrival_times = truck_evaluation.get("arrival_times")
    if not isinstance(arrival_times, Mapping):
        return make_infeasible_result("truck_evaluation missing arrival_times")
    if launch_node not in arrival_times:
        return make_infeasible_result(
            f"truck_evaluation arrival_times missing launch_node {launch_node}"
        )
    if recovery_node not in arrival_times:
        return make_infeasible_result(
            f"truck_evaluation arrival_times missing recovery_node {recovery_node}"
        )

    basic_demand = get_customer_field("basic_demand")
    emergency_demand = get_customer_field("emergency_demand")
    earliest = get_customer_field("earliest")
    latest = get_customer_field("latest")
    service_time = get_customer_field("service_time")

    # 二、无人机载重检查。
    total_demand = basic_demand + emergency_demand
    if total_demand > drone_capacity:
        return make_infeasible_result(
            f"customer {customer_id} demand {total_demand} exceeds drone_capacity {drone_capacity}"
        )

    # 三、飞行距离、飞行时间和续航检查。
    launch_to_customer_distance = get_matrix_value(
        drone_distance_matrix, launch_node, customer_id, "drone_distance_matrix"
    )
    customer_to_recovery_distance = get_matrix_value(
        drone_distance_matrix, customer_id, recovery_node, "drone_distance_matrix"
    )
    launch_to_customer_time = get_matrix_value(
        drone_time_matrix, launch_node, customer_id, "drone_time_matrix"
    )
    customer_to_recovery_time = get_matrix_value(
        drone_time_matrix, customer_id, recovery_node, "drone_time_matrix"
    )

    flight_distance = launch_to_customer_distance + customer_to_recovery_distance
    flight_time = launch_to_customer_time + customer_to_recovery_time
    minimum_drone_time = flight_time + service_time
    if minimum_drone_time > drone_endurance:
        return make_infeasible_result(
            f"minimum_drone_time {minimum_drone_time} exceeds drone_endurance {drone_endurance}",
            flight_distance=flight_distance,
            flight_time=flight_time,
            total_drone_time=minimum_drone_time,
        )

    # 四、时间窗与同步等待。
    arrival_times_by_index = truck_evaluation.get("arrival_times_by_index")
    if arrival_times_by_index is None:
        route_start_node = truck_route[0]
        if route_start_node not in arrival_times:
            return make_infeasible_result(
                f"truck_evaluation arrival_times missing route start node {route_start_node}"
            )
        route_start_time = arrival_times[route_start_node]
        launch_time = arrival_times[launch_node]
        truck_recovery_arrival = arrival_times[recovery_node]
    else:
        if not isinstance(arrival_times_by_index, Mapping):
            return make_infeasible_result("truck_evaluation arrival_times_by_index must be a mapping")
        if 0 not in arrival_times_by_index:
            return make_infeasible_result("truck_evaluation arrival_times_by_index missing route start index 0")
        if launch_pos not in arrival_times_by_index:
            return make_infeasible_result(
                f"truck_evaluation arrival_times_by_index missing launch_idx {launch_pos}"
            )
        if recovery_pos not in arrival_times_by_index:
            return make_infeasible_result(
                f"truck_evaluation arrival_times_by_index missing recovery_idx {recovery_pos}"
            )
        route_start_time = arrival_times_by_index[0]
        launch_time = arrival_times_by_index[launch_pos]
        truck_recovery_arrival = arrival_times_by_index[recovery_pos]
    customer_arrival_time = launch_time + launch_to_customer_time
    customer_service_start = customer_arrival_time
    release_time = None
    #动态客户的release time检查
    if not customer_is_static:
        release_time = get_customer_field("release_time")
        if isinstance(release_time, bool) or not isinstance(release_time, (int, float)):
            return make_infeasible_result(
                f"dynamic customer {customer_id} release_time must be numeric, "
                f"got {type(release_time).__name__}"
            )
        if customer_service_start < release_time:
            customer_service_start = release_time

    customer_weight = require_customer_priority_weight(customer_id, customers)
    if customer_is_static:
        priority_time = customer_service_start
    else:
        priority_time = customer_service_start - release_time
    priority_cost = customer_weight * max(0.0, priority_time)

    delay_penalty = 0.0
    if customer_service_start > latest:
        delay = customer_service_start - latest
        delay_penalty = delay * customer_weight
        warnings.append(f"Customer {customer_id} served late by {delay}")

    customer_departure_time = customer_service_start + service_time
    drone_recovery_time = customer_departure_time + customer_to_recovery_time
    truck_waiting_time = max(0.0, drone_recovery_time - truck_recovery_arrival)
    total_drone_time = drone_recovery_time - launch_time
    if total_drone_time > drone_endurance:
        return make_infeasible_result(
            f"total_drone_time {total_drone_time} exceeds drone_endurance {drone_endurance}",
            launch_time=launch_time,
            customer_arrival_time=customer_arrival_time,
            customer_service_start=customer_service_start,
            customer_departure_time=customer_departure_time,
            recovery_time=drone_recovery_time,
            truck_recovery_arrival=truck_recovery_arrival,
            truck_waiting_time=truck_waiting_time,
            flight_distance=flight_distance,
            flight_time=flight_time,
            total_drone_time=total_drone_time,
            delay_penalty=delay_penalty,
            priority_cost=priority_cost,
            period_index=get_period_index(launch_time),
            launch_idx=launch_pos,
            recovery_idx=recovery_pos,
        )

    # 无人机单次任务不能跨周期：起飞、服务、回收必须在同一周期内。
    launch_period_index = get_period_index(launch_time)
    customer_period_index = get_period_index(customer_service_start)
    recovery_period_index = get_period_index(drone_recovery_time)
    period_index = launch_period_index
    if launch_period_index != customer_period_index or launch_period_index != recovery_period_index:
        warnings.append(
            "Drone sortie crosses time period: "
            f"launch period {launch_period_index}, "
            f"customer period {customer_period_index}, "
            f"recovery period {recovery_period_index}"
        )

    cost = calculate_sortie_cost(
        priority_cost=priority_cost,
        delay_penalty=delay_penalty,
    )

    return build_result(
        feasible=True,
        launch_time=launch_time,
        customer_arrival_time=customer_arrival_time,
        customer_service_start=customer_service_start,
        customer_departure_time=customer_departure_time,
        recovery_time=drone_recovery_time,
        truck_recovery_arrival=truck_recovery_arrival,
        truck_waiting_time=truck_waiting_time,
        flight_distance=flight_distance,
        flight_time=flight_time,
        total_drone_time=total_drone_time,
        delay_penalty=delay_penalty,
        priority_cost=priority_cost,
        cost=cost,
        period_index=period_index,
        launch_idx=launch_pos,
        recovery_idx=recovery_pos,
    )


def get_drone_capacity(drone_id, drone_capacity_by_drone):
    """读取无人机容量；支持统一容量或按无人机编号配置。"""
    if isinstance(drone_capacity_by_drone, dict):
        if drone_id not in drone_capacity_by_drone:
            raise ValueError(f"drone_capacity_by_drone missing drone_id {drone_id}")
        return drone_capacity_by_drone[drone_id]
    return drone_capacity_by_drone


def get_drone_endurance(drone_id, drone_endurance_by_drone):
    """读取无人机续航；支持统一续航或按无人机编号配置。"""
    if isinstance(drone_endurance_by_drone, dict):
        if drone_id not in drone_endurance_by_drone:
            raise ValueError(f"drone_endurance_by_drone missing drone_id {drone_id}")
        return drone_endurance_by_drone[drone_id]
    return drone_endurance_by_drone


def build_drone_period_usage(drone_routes):
    """根据已有无人机任务统计每架无人机在每个周期的使用次数。"""
    drone_period_usage = {}
    for task_idx, task in enumerate(drone_routes):
        if "drone_id" not in task:
            raise ValueError(f"drone task {task_idx} missing drone_id")
        if "period_index" not in task:
            raise ValueError(f"drone task {task_idx} missing period_index")
        key = (task["drone_id"], task["period_index"])
        drone_period_usage[key] = drone_period_usage.get(key, 0) + 1
    return drone_period_usage


def _build_segment_usage_from_drone_routes(drone_routes):
    """根据 drone_routes 中的 occupied_segments 统计路段占用次数。"""
    segment_usage = {}
    for task_idx, task in enumerate(drone_routes):
        if "occupied_segments" not in task:
            raise ValueError(f"drone task {task_idx} missing occupied_segments")
        for seg in task["occupied_segments"]:
            segment_usage[seg] = segment_usage.get(seg, 0) + 1
    return segment_usage


def _get_drone_task_time(task, field_name):
    if field_name in task:
        value = task[field_name]
    else:
        evaluation = task.get("evaluation")
        if isinstance(evaluation, dict) and field_name in evaluation:
            value = evaluation[field_name]
        else:
            recomputed = evaluation.get("recomputed") if isinstance(evaluation, dict) else None
            if isinstance(recomputed, dict) and field_name in recomputed:
                value = recomputed[field_name]
            else:
                raise ValueError(f"drone task missing time field: {field_name}")
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(
            f"drone task time field {field_name} must be numeric, "
            f"got {type(value).__name__}"
        )
    return float(value)


def intervals_overlap(start_a, end_a, start_b, end_b, eps=1e-9):
    """判断两个无人机任务时间区间是否重叠。"""
    if start_a is None or end_a is None or start_b is None or end_b is None:
        raise ValueError("drone interval time must not be None")

    if isinstance(start_a, bool) or not isinstance(start_a, (int, float)):
        raise TypeError(f"start_a must be numeric, got {type(start_a).__name__}")
    if isinstance(end_a, bool) or not isinstance(end_a, (int, float)):
        raise TypeError(f"end_a must be numeric, got {type(end_a).__name__}")
    if isinstance(start_b, bool) or not isinstance(start_b, (int, float)):
        raise TypeError(f"start_b must be numeric, got {type(start_b).__name__}")
    if isinstance(end_b, bool) or not isinstance(end_b, (int, float)):
        raise TypeError(f"end_b must be numeric, got {type(end_b).__name__}")

    if end_a < start_a:
        raise ValueError(f"invalid interval [{start_a}, {end_a}]")
    if end_b < start_b:
        raise ValueError(f"invalid interval [{start_b}, {end_b}]")

    return start_a < end_b - eps and start_b < end_a - eps


def get_drone_task_interval(task):
    """
    从无人机任务中读取 launch_time 和 recovery_time。
    优先读取 task 顶层字段，其次读取 evaluation["recomputed"]，最后读取 evaluation。
    """
    if not isinstance(task, dict):
        raise TypeError("drone task must be a dict")

    if "launch_time" in task and "recovery_time" in task:
        launch_time = task["launch_time"]
        recovery_time = task["recovery_time"]
    else:
        evaluation = task.get("evaluation")
        if not isinstance(evaluation, dict):
            raise ValueError(
                f"drone task {task.get('task_id')} missing evaluation"
            )

        recomputed = evaluation.get("recomputed")
        if isinstance(recomputed, dict) and (
            "launch_time" in recomputed
            and "recovery_time" in recomputed
        ):
            launch_time = recomputed["launch_time"]
            recovery_time = recomputed["recovery_time"]
        elif "launch_time" in evaluation and "recovery_time" in evaluation:
            launch_time = evaluation["launch_time"]
            recovery_time = evaluation["recovery_time"]
        else:
            raise ValueError(
                f"drone task {task.get('task_id')} missing launch_time/recovery_time"
            )

    if launch_time is None or recovery_time is None:
        raise ValueError(
            f"drone task {task.get('task_id')} launch_time/recovery_time must not be None"
        )
    if isinstance(launch_time, bool) or not isinstance(launch_time, (int, float)):
        raise TypeError(
            f"drone task {task.get('task_id')} launch_time must be numeric, "
            f"got {type(launch_time).__name__}"
        )
    if isinstance(recovery_time, bool) or not isinstance(recovery_time, (int, float)):
        raise TypeError(
            f"drone task {task.get('task_id')} recovery_time must be numeric, "
            f"got {type(recovery_time).__name__}"
        )
    if recovery_time < launch_time:
        raise ValueError(
            f"drone task {task.get('task_id')} has invalid interval "
            f"[{launch_time}, {recovery_time}]"
        )

    return float(launch_time), float(recovery_time)


def _drone_time_intervals_overlap(first_launch, first_recovery, second_launch, second_recovery):
    return intervals_overlap(first_launch, first_recovery, second_launch, second_recovery)


def can_add_drone_sortie(
    sortie_eval,
    solution,
    drone_ids_by_truck,
    drone_period_usage,
    segment_usage,
):
    """检查候选无人机任务是否满足全局无人机资源约束。"""
    violations = []

    if not sortie_eval.get("feasible", False):
        violations.append("sortie_eval is infeasible")

    customer_id = sortie_eval.get("customer_id")
    truck_id = sortie_eval.get("truck_id")
    drone_id = sortie_eval.get("drone_id")
    period_index = sortie_eval.get("period_index")
    launch_time = sortie_eval.get("launch_time")
    recovery_time = sortie_eval.get("recovery_time")
    if truck_id is None:
        violations.append("sortie_eval missing truck_id")
    if drone_id is None:
        violations.append("sortie_eval missing drone_id")
    if launch_time is None or recovery_time is None:
        violations.append("sortie_eval missing launch_time or recovery_time")
    elif (
        isinstance(launch_time, bool)
        or isinstance(recovery_time, bool)
        or not isinstance(launch_time, (int, float))
        or not isinstance(recovery_time, (int, float))
    ):
        violations.append("sortie_eval launch_time and recovery_time must be numeric")
    elif recovery_time < launch_time:
        violations.append(
            f"sortie_eval recovery_time {recovery_time} is before launch_time {launch_time}"
        )

    served = solution.get("served", set())
    if customer_id in served:
        violations.append(f"customer {customer_id} is already served")

    for task in solution.get("drone_routes", []):
        if task.get("customer") == customer_id:
            violations.append(f"customer {customer_id} is already served by an existing drone task")
            break
        if task.get("truck_id") == truck_id and task.get("drone_id") == drone_id:
            existing_launch_time, existing_recovery_time = get_drone_task_interval(task)
            if (
                isinstance(launch_time, (int, float))
                and not isinstance(launch_time, bool)
                and isinstance(recovery_time, (int, float))
                and not isinstance(recovery_time, bool)
                and intervals_overlap(
                    float(launch_time),
                    float(recovery_time),
                    existing_launch_time,
                    existing_recovery_time,
                )
            ):
                violations.append(
                    "candidate drone task overlaps existing task: "
                    f"truck={truck_id}, drone={drone_id}, "
                    f"candidate_customer={customer_id} "
                    f"[{launch_time}, {recovery_time}], "
                    f"existing_task={task.get('task_id')}, "
                    f"existing_customer={task.get('customer')} "
                    f"[{existing_launch_time}, {existing_recovery_time}]"
                )
    if period_index is None:
        violations.append("sortie_eval missing period_index")
    # 6. 检查路段占用情况（遍历 sortie_eval["occupied_segments"]）：
    for seg in sortie_eval.get("occupied_segments", []):
        truck_id = seg[0]
        if truck_id not in drone_ids_by_truck:
            violations.append(f"drone_ids_by_truck missing truck_id {truck_id}")
            continue
        limit = len(drone_ids_by_truck[truck_id])
        if segment_usage.get(seg, 0) + 1 > limit:
            violations.append(
                f"segment {seg} usage would exceed truck {truck_id} drone limit {limit}"
            )

    return {
        "can_add": len(violations) == 0,
        "violations": violations,
    }


def recompute_truck_timeline_with_drone_waiting(
    truck_route,
    truck_id,
    truck_drone_tasks,
    customers,
    distance_matrix,
    truck_time_matrix,
    risk_matrix,
    drone_time_matrix,
    drone_distance_matrix,
    periods,
    period_length,
    truck_capacity,
    drone_capacity_by_drone,
    drone_endurance_by_drone,
    depot_start,
    depot_end,
    replenishment_node=999,
    start_time=0.0,
    anchor_node=None,
    initial_basic_load=None,
    initial_emergency_load=None,
    replenishment_time=0.0,
    risk_cost_weight=1.0,
    delay_cost_weight=1.0,
    cost_weights=None,
):
    """在已有卡车路径和无人机任务下，重新模拟某辆卡车的完整时间线。
    本函数负责：
    1. 根据当前卡车路径、该卡车负责的所有无人机任务、初始状态（锚点、起始时间、载重等），
       逐段模拟卡车的行驶、补货、客户服务，以及无人机任务的发射、飞行、回收，
       并同步更新卡车时间线（到达/离开时间、剩余载重）和无人机任务的时间字段。
    2. 返回详细的评价结果，包括可行性、成本分量、时间线、补货记录等。"""

    if not truck_route:
        raise ValueError("truck_route must not be empty")
    if anchor_node is None:
        anchor_node = depot_start
    has_phase_initial_load = (
        initial_basic_load is not None
        or initial_emergency_load is not None
    )
    if has_phase_initial_load and (
        initial_basic_load is None or initial_emergency_load is None
    ):
        raise ValueError(
            "initial_basic_load and initial_emergency_load must be provided together"
        )
    if truck_route[0] != anchor_node:
        raise ValueError(
            f"truck_route must start with anchor_node {anchor_node}, got {truck_route[0]}"
        )
    if truck_route[-1] != depot_end:
        raise ValueError(f"truck_route must end with depot_end {depot_end}")
    if not periods:
        raise ValueError("periods must not be empty")
    if period_length <= 0:
        raise ValueError(f"period_length must be positive, got {period_length}")

    def calculate_unified_cost(priority_cost, delay_penalty, road_risk_cost=0.0, unserved_penalty_cost=0.0):
        return calculate_weighted_cost(
            {
                "priority_cost": priority_cost,
                "unserved_penalty_cost": unserved_penalty_cost,
                "road_risk_cost": road_risk_cost,
                "delay_penalty": delay_penalty,
            },
            cost_weights,
        )

    def get_period_by_time(current_time):
        return require_period_value(current_time, periods, period_length)

    def get_period_index(current_time):
        return require_period_index(current_time, periods, period_length)

    def require_customer_field(customer_id, field_name):
        return require_common_customer_field(customers, customer_id, field_name)

    def get_matrix_value(matrix, *keys):
        return require_nested_value(matrix, *keys)

    def copy_load(load):
        return {
            "basic": load["basic"],
            "emergency": load["emergency"],
        }

    def get_customer_load(customer_id):
        return require_customer_load(customers, customer_id)

    def is_load_sufficient(load, customer_id):
        customer_load = get_customer_load(customer_id)
        return (
            load["basic"] >= customer_load["basic"]
            and load["emergency"] >= customer_load["emergency"]
        )

    def get_customer_weight(customer_id):
        return require_customer_priority_weight(customer_id, customers)

    def is_dynamic_customer(customer_id):
        return require_customer_is_dynamic(customers, customer_id)

    def exceeds_truck_capacity(load):
        if isinstance(truck_capacity, dict):
            if "basic" not in truck_capacity or "emergency" not in truck_capacity:
                raise ValueError("truck_capacity dict must contain basic and emergency")
            return (
                load["basic"] > truck_capacity["basic"]
                or load["emergency"] > truck_capacity["emergency"]
            )
        return load["basic"] + load["emergency"] > truck_capacity

    def get_task_key(task_index, task):
        """严格使用 _rebuild_solution 写入的 task_id 追踪无人机任务。"""
        if "task_id" not in task:
            raise ValueError(f"drone task {task_index} missing required key: task_id")
        return task["task_id"]

    def build_task_timing(task_index, task, feasible, violations=None, warnings=None):
        #为每个无人机任务构造初始时间线占位结构（暂为空值）。
        required_timing_keys = {
            "task_id",
            "truck_id",
            "drone_id",
            "launch_node",
            "customer",
            "recovery_node",
        }
        missing_timing_keys = required_timing_keys - set(task)
        if missing_timing_keys:
            raise ValueError(
                f"drone task {task_index} missing required keys for timing: "
                f"{sorted(missing_timing_keys)}"
            )
        return {
            "task_id": task["task_id"],
            "task_index": task_index,
            "truck_id": task["truck_id"],
            "drone_id": task["drone_id"],
            "launch_node": task["launch_node"],
            "customer_id": task["customer"],
            "recovery_node": task["recovery_node"],
            "launch_time": None,
            "customer_arrival_time": None,
            "customer_service_start": None,
            "customer_departure_time": None,
            "recovery_time": None,
            "period_index": None,
            "delay_penalty": 0.0,
            "priority_cost": 0.0,
            "road_risk_cost": 0.0,
            "unserved_penalty_cost": 0.0,
            "truck_waiting_time": 0.0,
            "flight_distance": 0.0,
            "flight_time": 0.0,
            "total_drone_time": 0.0,
            "cost": 0.0,
            "feasible": feasible,
            "violations": list(violations or []),
            "warnings": list(warnings or []),
        }

    required_task_keys = {
        "task_id",
        "truck_id",
        "drone_id",
        "launch_node",
        "customer",
        "recovery_node",
    }
    route_positions = {}
    route_indices_by_node = {}
    for index, node in enumerate(truck_route):
        route_indices_by_node.setdefault(node, []).append(index)
        if node not in route_positions:
            route_positions[node] = index

    def resolve_task_route_index(task_index, task, node_key, index_key):
        #node_key: 节点字段名，如 "launch_node" 或 "recovery_node"
        if node_key not in task:
            raise ValueError(f"drone task {task_index} missing required key: {node_key}")
        node = task[node_key]
        if node not in route_indices_by_node:
            return None, f"drone task {task_index} {node_key} {node} not in truck_route"
        if index_key in task:
            index_value = task[index_key]
            if isinstance(index_value, bool) or not isinstance(index_value, int):
                return None, (
                    f"drone task {task_index} {index_key} must be int, "
                    f"got {type(index_value).__name__}"
                )
            if index_value < 0 or index_value >= len(truck_route):
                return None, (
                    f"drone task {task_index} {index_key} {index_value} "
                    f"outside truck_route length {len(truck_route)}"
                )
            if truck_route[index_value] != node:
                return None, (
                    f"drone task {task_index} {index_key} points to "
                    f"{truck_route[index_value]}, expected {node}"
                )
            return index_value, None

        indices = route_indices_by_node[node]
        if len(indices) != 1:
            return None, (
                f"drone task {task_index} {node_key} {node} is ambiguous without "
                f"{index_key}: indices={indices}"
            )
        return indices[0], None

    launch_tasks_by_position = {}
    recovery_tasks_by_position = {}
    static_drone_initial_load = {"basic": 0.0, "emergency": 0.0}
    static_drone_initial_customers = []
    dynamic_drone_loads_by_launch_position = {}
    dynamic_drone_customers_by_launch_position = {}
    dynamic_truck_direct_dispatch_by_replenishment = {}
    drone_task_timings = {}
    violations = []
    warnings = []

    for task_index, task in enumerate(truck_drone_tasks):
        task_key = get_task_key(task_index, task)
        missing_keys = required_task_keys - set(task)
        if missing_keys:
            message = f"drone task {task_index} missing required keys: {sorted(missing_keys)}"
            violations.append(message)
            drone_task_timings[task_key] = build_task_timing(
                task_index, task, False, violations=[message]
            )
            continue

        if task["truck_id"] != truck_id:
            raise ValueError(
                f"drone task {task_index} belongs to truck {task['truck_id']}, "
                f"not truck {truck_id}"
            )

        task_violations = []
        launch_node = task["launch_node"]
        recovery_node = task["recovery_node"]
        customer_id = task["customer"]
        launch_position = None
        recovery_position = None
        # 解析发射位置和回收位置在卡车路径中的索引
        launch_position, launch_position_error = resolve_task_route_index(
            task_index, task, "launch_node", "launch_idx"
        )
        if launch_position_error is not None:
            task_violations.append(launch_position_error)
        recovery_position, recovery_position_error = resolve_task_route_index(
            task_index, task, "recovery_node", "recovery_idx"
        )
        if recovery_position_error is not None:
            task_violations.append(recovery_position_error)
        if customer_id not in customers:
            task_violations.append(
                f"drone task {task_index} customer {customer_id} not in customers"
            )
        if customer_id in route_positions:
            task_violations.append(
                f"drone task {task_index} customer {customer_id} is already in truck_route"
            )
        if launch_position is not None and recovery_position is not None:
            if launch_position >= recovery_position:
                task_violations.append(
                    f"drone task {task_index} launch_node must appear before recovery_node"
                )
        if customer_id in customers:
            customer_is_static = require_customer_field(customer_id, "is_static")
            if not isinstance(customer_is_static, bool):
                task_violations.append(
                    f"drone task {task_index} customer {customer_id} is_static must be bool, "
                    f"got {type(customer_is_static).__name__}"
                )
        if task_violations:
            violations.extend(task_violations)
            drone_task_timings[task_key] = build_task_timing(
                task_index, task, False, violations=task_violations
            )
            continue
        # 任务合法，将其按发射位置和回收位置分别存入对应的字典
        launch_tasks_by_position.setdefault(launch_position, []).append((task_index, task))
        recovery_tasks_by_position.setdefault(recovery_position, []).append((task_index, task))
        if require_customer_field(customer_id, "is_static"):
            customer_load = get_customer_load(customer_id)
            static_drone_initial_load["basic"] += customer_load["basic"]
            static_drone_initial_load["emergency"] += customer_load["emergency"]
            static_drone_initial_customers.append(customer_id)
        elif launch_node == replenishment_node:
            customer_load = get_customer_load(customer_id)
            position_load = dynamic_drone_loads_by_launch_position.setdefault(
                launch_position,
                {"basic": 0.0, "emergency": 0.0},
            )
            position_load["basic"] += customer_load["basic"]
            position_load["emergency"] += customer_load["emergency"]
            dynamic_drone_customers_by_launch_position.setdefault(
                launch_position,
                [],
            ).append(customer_id)
        drone_task_timings[task_key] = build_task_timing(task_index, task, True)
    # 初始化模拟状态变量
    current_time = start_time
    total_distance = 0.0
    total_travel_time = 0.0
    risk_cost = 0.0
    delay_penalty = 0.0
    priority_cost = 0.0
    replenishment_count = 0
    total_basic_replenishment = 0.0
    total_emergency_replenishment = 0.0
    arrival_times = {}
    departure_times = {}
    arrival_times_by_index = {}
    departure_times_by_index = {}
    timeline_by_position = {}
    remaining_loads = {}
    replenishment_records = []
    # 判断是否提供了阶段起始载重（由调用方传入）
    if has_phase_initial_load:
        initial_load = {
            "basic": initial_basic_load,
            "emergency": initial_emergency_load,
        }
    else:# 否则，从卡车路径中所有静态客户的需求累加初始载重
        initial_load = {"basic": 0.0, "emergency": 0.0}
        for node in truck_route:
            if node in customers and not is_dynamic_customer(node):
                customer_load = get_customer_load(node)
                initial_load["basic"] += customer_load["basic"]
                initial_load["emergency"] += customer_load["emergency"]
        initial_load["basic"] += static_drone_initial_load["basic"]
        initial_load["emergency"] += static_drone_initial_load["emergency"]

    remaining_load = copy_load(initial_load)
    if exceeds_truck_capacity(remaining_load):
        violations.append(f"initial_load exceeds truck_capacity: {initial_load}")

    def record_timeline_position(node_index):
        node = truck_route[node_index]
        if node_index not in arrival_times_by_index:
            raise ValueError(f"arrival_times_by_index missing position {node_index}")
        if node_index not in departure_times_by_index:
            raise ValueError(f"departure_times_by_index missing position {node_index}")
        if node not in remaining_loads:
            raise ValueError(f"remaining_loads missing node {node}")
        node_load = remaining_loads[node]
        timeline_by_position[node_index] = {
            "node": node,
            "arrival_time": arrival_times_by_index[node_index],
            "departure_time": departure_times_by_index[node_index],
            "remaining_basic_load": node_load["basic"],
            "remaining_emergency_load": node_load["emergency"],
        }


    def process_launch_tasks(node_index, node):
        """卡车到达发射点时立即发射该点上的无人机任务。"""
        for task_index, task in launch_tasks_by_position.get(node_index, []):
            task_key = get_task_key(task_index, task)
            task_timing = drone_task_timings[task_key]
            if not task_timing["feasible"]:
                continue

            customer_id = task["customer"]
            recovery_node = task["recovery_node"]
            drone_id = task["drone_id"]

            basic_demand = require_customer_field(customer_id, "basic_demand")
            emergency_demand = require_customer_field(customer_id, "emergency_demand")
            earliest = require_customer_field(customer_id, "earliest")
            latest = require_customer_field(customer_id, "latest")
            service_time = require_customer_field(customer_id, "service_time")
            customer_weight = get_customer_weight(customer_id)
            customer_is_static = require_customer_field(customer_id, "is_static")
            if not isinstance(customer_is_static, bool):
                raise TypeError(
                    f"customer {customer_id} is_static must be bool, "
                    f"got {type(customer_is_static).__name__}"
                )

            launch_to_customer_time = get_matrix_value(
                drone_time_matrix, node, customer_id
            )
            customer_to_recovery_time = get_matrix_value(
                drone_time_matrix, customer_id, recovery_node
            )
            launch_to_customer_distance = get_matrix_value(
                drone_distance_matrix, node, customer_id
            )
            customer_to_recovery_distance = get_matrix_value(
                drone_distance_matrix, customer_id, recovery_node
            )

            launch_time = arrival_times[node]
            customer_arrival_time = launch_time + launch_to_customer_time
            customer_service_start = customer_arrival_time
            release_time = None
            if not customer_is_static:
                release_time = require_customer_field(customer_id, "release_time")
                if isinstance(release_time, bool) or not isinstance(release_time, (int, float)):
                    task_timing["feasible"] = False
                    task_timing["violations"].append(
                        f"dynamic customer {customer_id} release_time must be numeric, "
                        f"got {type(release_time).__name__}"
                    )
                else:
                    if customer_service_start < release_time:
                        customer_service_start = release_time
            drone_delay_penalty = 0.0
            if customer_service_start > latest:
                drone_delay = customer_service_start - latest
                drone_delay_penalty = (
                    drone_delay * customer_weight * delay_cost_weight
                )
                task_timing["warnings"].append(
                    f"Drone customer {customer_id} served late by {drone_delay}"
                )
            if customer_is_static:
                drone_priority_time = customer_service_start
            else:
                if isinstance(release_time, bool) or not isinstance(release_time, (int, float)):
                    raise TypeError(
                        f"dynamic customer {customer_id} release_time must be numeric, "
                        f"got {type(release_time).__name__}"
                    )
                drone_priority_time = customer_service_start - release_time
            drone_priority_cost = customer_weight * max(0.0, drone_priority_time)

            customer_departure_time = customer_service_start + service_time
            recovery_time = customer_departure_time + customer_to_recovery_time
            flight_time = launch_to_customer_time + customer_to_recovery_time
            total_drone_time = recovery_time - launch_time
            flight_distance = launch_to_customer_distance + customer_to_recovery_distance

            drone_capacity = get_drone_capacity(drone_id, drone_capacity_by_drone)
            drone_endurance = get_drone_endurance(drone_id, drone_endurance_by_drone)
            total_demand = basic_demand + emergency_demand
            if total_demand > drone_capacity:
                task_timing["feasible"] = False
                task_timing["violations"].append(
                    f"drone task {task_index} demand {total_demand} exceeds "
                    f"drone_capacity {drone_capacity}"
                )
            if customer_is_static:
                if remaining_load["basic"] < basic_demand:
                    task_timing["feasible"] = False
                    task_timing["violations"].append(
                        f"launching static drone customer {customer_id} lacks basic load: "
                        f"load={remaining_load['basic']}, demand={basic_demand}"
                    )
                if remaining_load["emergency"] < emergency_demand:
                    task_timing["feasible"] = False
                    task_timing["violations"].append(
                        f"launching static drone customer {customer_id} lacks emergency load: "
                        f"load={remaining_load['emergency']}, demand={emergency_demand}"
                    )
                remaining_load["basic"] -= basic_demand
                remaining_load["emergency"] -= emergency_demand
                remaining_loads[node] = copy_load(remaining_load)
            if total_drone_time > drone_endurance:
                task_timing["feasible"] = False
                task_timing["violations"].append(
                    f"drone task {task_index} total_drone_time {total_drone_time} "
                    f"exceeds drone_endurance {drone_endurance}"
                )

            launch_period_index = get_period_index(launch_time)
            customer_period_index = get_period_index(customer_service_start)
            recovery_period_index = get_period_index(recovery_time)
            if launch_period_index != customer_period_index or launch_period_index != recovery_period_index:
                task_timing["warnings"].append(
                    "Drone sortie crosses time period: "
                    f"launch period {launch_period_index}, "
                    f"customer period {customer_period_index}, "
                    f"recovery period {recovery_period_index}"
                )

            task_timing.update(
                {
                    "launch_time": launch_time,
                    "customer_arrival_time": customer_arrival_time,
                    "customer_service_start": customer_service_start,
                    "customer_departure_time": customer_departure_time,
                    "recovery_time": recovery_time,
                    "period_index": launch_period_index,
                    "delay_penalty": drone_delay_penalty,
                    "priority_cost": drone_priority_cost,
                    "road_risk_cost": 0.0,
                    "unserved_penalty_cost": 0.0,
                    "flight_distance": flight_distance,
                    "flight_time": flight_time,
                    "total_drone_time": total_drone_time,
                    "cost": calculate_unified_cost(
                        priority_cost=drone_priority_cost,
                        delay_penalty=drone_delay_penalty,
                        road_risk_cost=0.0,
                        unserved_penalty_cost=0.0,
                    ),
                }
            )

    def process_recovery_tasks(node_index, node):
        """卡车在回收点按最晚无人机回收时间等待。"""
        nonlocal current_time
        max_recovery_time = None

        for task_index, task in recovery_tasks_by_position.get(node_index, []):
            task_key = get_task_key(task_index, task)
            task_timing = drone_task_timings[task_key]
            if not task_timing["feasible"]:
                message = (
                    f"drone task {task_index} is infeasible before recovery at node {node}: "
                    f"{task_timing['violations']}"
                )
                violations.append(message)

            recovery_time = task_timing["recovery_time"]
            if recovery_time is None:
                message = f"drone task {task_index} has no recomputed recovery_time"
                task_timing["feasible"] = False
                task_timing["violations"].append(message)
                violations.append(message)
                continue

            truck_recovery_arrival = arrival_times[node]
            waiting = max(0.0, recovery_time - truck_recovery_arrival)
            task_timing["truck_waiting_time"] = waiting
            if max_recovery_time is None or recovery_time > max_recovery_time:
                max_recovery_time = recovery_time

        if max_recovery_time is not None and max_recovery_time > current_time:
            current_time = max_recovery_time
            departure_times[node] = current_time

    def process_truck_node(node, previous_node=None, next_node=None, node_index=None):
        """处理卡车当前节点的补货、服务或仓库停靠。"""
        # 声明需要修改的外部变量（当前时间、成本累计、补货统计）
        nonlocal current_time
        nonlocal delay_penalty
        nonlocal priority_cost
        nonlocal replenishment_count
        nonlocal total_basic_replenishment
        nonlocal total_emergency_replenishment

        if node == depot_start or node == depot_end:
            departure_times[node] = current_time
            remaining_loads[node] = copy_load(remaining_load)
            return

        if node == replenishment_node:
            violations.append(
                f"replenishment node {replenishment_node} is deprecated in truck routes"
            )
            departure_times[node] = current_time
            remaining_loads[node] = copy_load(remaining_load)
            return

        if node not in customers:
            violations.append(f"truck_route contains unknown node {node}")
            departure_times[node] = current_time
            remaining_loads[node] = copy_load(remaining_load)
            return

        earliest = require_customer_field(node, "earliest")
        latest = require_customer_field(node, "latest")
        service_time = require_customer_field(node, "service_time")
        customer_load = get_customer_load(node)
        customer_weight = get_customer_weight(node)

        #if current_time < earliest:
         #   current_time = earliest

        service_start_time = current_time
        customer_is_dynamic = is_dynamic_customer(node)
        direct_dispatch_replenishment_index = (
            node_index - 1
            if (
                node_index is not None
                and node_index > 0
                and previous_node == replenishment_node
            )
            else None
        )
        dynamic_truck_direct_dispatch = (
            customer_is_dynamic
            and direct_dispatch_replenishment_index in dynamic_truck_direct_dispatch_by_replenishment
            and dynamic_truck_direct_dispatch_by_replenishment[
                direct_dispatch_replenishment_index
            ]
            == node
        )
        if customer_is_dynamic:
            release_time = require_customer_field(node, "release_time")
            if isinstance(release_time, bool) or not isinstance(release_time, (int, float)):
                raise TypeError(
                    f"dynamic customer {node} release_time must be numeric, "
                    f"got {type(release_time).__name__}"
                )
            if service_start_time < release_time:
                service_start_time = release_time
                current_time = release_time
            if previous_node == replenishment_node and not dynamic_truck_direct_dispatch:
                raise ValueError(
                    f"dynamic customer {node} follows replenishment node without "
                    f"dynamic_truck_direct_dispatch record"
                )
        if customer_is_dynamic:
            priority_time = service_start_time - release_time
        else:
            priority_time = service_start_time
        priority_cost += customer_weight * max(0.0, priority_time)

        if service_start_time > latest:
            delay = service_start_time - latest
            delay_penalty += delay * customer_weight * delay_cost_weight
            warnings.append(f"Customer {node} served late by {delay}")
        #这个客户是否计入卡车载重容量约束
        customer_counts_against_truck_capacity = not customer_is_dynamic
        if customer_counts_against_truck_capacity and remaining_load["basic"] < customer_load["basic"]:
            violations.append(
                f"serving customer {node} lacks basic load: "
                f"load={remaining_load['basic']}, demand={customer_load['basic']}"
            )
        if (
            customer_counts_against_truck_capacity
            and remaining_load["emergency"] < customer_load["emergency"]
        ):
            violations.append(
                f"serving customer {node} lacks emergency load: "
                f"load={remaining_load['emergency']}, demand={customer_load['emergency']}"
            )

        remaining_load["basic"] -= (
            customer_load["basic"] if customer_counts_against_truck_capacity else 0.0
        )
        remaining_load["emergency"] -= (
            customer_load["emergency"] if customer_counts_against_truck_capacity else 0.0
        )
        current_time += service_time
        departure_times[node] = current_time
        remaining_loads[node] = copy_load(remaining_load)

    start_node = truck_route[0]
    arrival_times[start_node] = start_time
    departure_times[start_node] = start_time
    arrival_times_by_index[0] = start_time
    remaining_loads[start_node] = copy_load(remaining_load)
    #在卡车当前 Phase 路径的第 0 个位置，也就是起点节点 start_node，处理所有“计划从这个位置起飞”的无人机任务。
    process_launch_tasks(0, start_node)
    if start_node == depot_start:
        process_truck_node(
            start_node,
            previous_node=None,
            next_node=truck_route[1] if len(truck_route) > 1 else None,
            node_index=0,
        )
    process_recovery_tasks(0, start_node)
    departure_times_by_index[0] = current_time
    record_timeline_position(0)

    for node_index in range(1, len(truck_route)):
        previous_node = truck_route[node_index - 1]
        node = truck_route[node_index]
        next_node = truck_route[node_index + 1] if node_index + 1 < len(truck_route) else None

        period = get_period_by_time(current_time)
        risk_level = get_matrix_value(risk_matrix, period, previous_node, node)
        if risk_level not in {0, 1, 2, 3, 4}:
            raise ValueError(
                f"risk level must be in {{0,1,2,3,4}}, got {risk_level} "
                f"for period={period}, edge=({previous_node}, {node})"
            )
        if risk_level == 4:
            violations.append(
                f"road ({previous_node}, {node}) is blocked in period {period}"
            )
            break

        travel_time = get_matrix_value(truck_time_matrix, period, previous_node, node)
        distance = get_matrix_value(distance_matrix, previous_node, node)

        current_time += travel_time
        total_distance += distance
        total_travel_time += travel_time
        risk_cost += (distance / ROAD_RISK_DISTANCE_SCALE) * risk_level * risk_cost_weight
        arrival_times[node] = current_time
        arrival_times_by_index[node_index] = current_time

        if node == replenishment_node:
            process_truck_node(
                node,
                previous_node=previous_node,
                next_node=next_node,
                node_index=node_index,
            )
            process_launch_tasks(node_index, node)
        else:
            process_launch_tasks(node_index, node)
            process_truck_node(
                node,
                previous_node=previous_node,
                next_node=next_node,
                node_index=node_index,
            )
        process_recovery_tasks(node_index, node)
        departure_times_by_index[node_index] = current_time
        record_timeline_position(node_index)

    for task_index, task in enumerate(truck_drone_tasks):
        task_key = get_task_key(task_index, task)
        task_timing = drone_task_timings[task_key]
        if task_timing["feasible"] and task_timing["recovery_time"] is None:
            message = f"drone task {task_index} was not launched during truck timeline recomputation"
            task_timing["feasible"] = False
            task_timing["violations"].append(message)
            violations.append(message)
        if task_timing["violations"]:
            violations.extend(
                message
                for message in task_timing["violations"]
                if message not in violations
            )
        if task_timing["warnings"]:
            warnings.extend(
                message
                for message in task_timing["warnings"]
                if message not in warnings
            )

        task["launch_time"] = task_timing["launch_time"]
        task["recovery_time"] = task_timing["recovery_time"]
        task["period_index"] = task_timing["period_index"]
        task["truck_waiting_time"] = task_timing["truck_waiting_time"]
        if "evaluation" not in task:
            raise ValueError(f"drone task {task_index} missing evaluation")
        if not isinstance(task["evaluation"], dict):
            raise ValueError(f"drone task {task_index} evaluation must be a dict")
        task["evaluation"]["recomputed"] = task_timing

    feasible = len(violations) == 0
    return {
        "feasible": feasible,
        "arrival_times": arrival_times,
        "departure_times": departure_times,
        "arrival_times_by_index": arrival_times_by_index,
        "departure_times_by_index": departure_times_by_index,
        "timeline_by_position": timeline_by_position,
        "remaining_loads": remaining_loads,
        "total_distance": total_distance,
        "total_travel_time": total_travel_time,
        "total_time": current_time - start_time,
        "risk_cost": risk_cost,
        "road_risk_cost": risk_cost,
        "priority_cost": priority_cost,
        "unserved_penalty_cost": 0.0,
        "delay_penalty": delay_penalty,
        "replenishment_count": replenishment_count,
        "total_basic_replenishment": total_basic_replenishment,
        "total_emergency_replenishment": total_emergency_replenishment,
        "replenishment_records": replenishment_records,
        "initial_load": copy_load(initial_load),
        "initial_loads": copy_load(initial_load),
        "static_drone_initial_load": copy_load(static_drone_initial_load),
        "static_drone_initial_customers": list(static_drone_initial_customers),
        "final_load": copy_load(remaining_load),
        "final_loads": copy_load(remaining_load),
        "drone_task_timings": drone_task_timings,
        "updated_drone_tasks": truck_drone_tasks,
        "violations": violations,
        "warnings": warnings,
    }


def get_truck_capacity(truck_id, truck_capacity_by_truck):
    """读取卡车容量；支持统一容量或按卡车编号配置。"""
    if isinstance(truck_capacity_by_truck, dict):
        if truck_id not in truck_capacity_by_truck:
            raise ValueError(f"truck_capacity_by_truck missing truck_id {truck_id}")
        return truck_capacity_by_truck[truck_id]
    return truck_capacity_by_truck


def calculate_truck_evaluation_cost(evaluation, cost_weights=None):
    """按卡车评价结果计算卡车路径成本。"""
    if cost_weights is None:
        cost_weights = {
            "priority_cost": 1.0,
            "unserved_penalty_cost": 1.0,
            "road_risk_cost": 1.0,
            "delay_penalty": 1.0,
        }

    allowed_keys = {
        "priority_cost",
        "unserved_penalty_cost",
        "road_risk_cost",
        "delay_penalty",
    }
    unknown_keys = set(cost_weights) - allowed_keys
    if unknown_keys:
        raise ValueError(f"truck cost_weights contains unsupported keys: {sorted(unknown_keys)}")

    total_cost = 0.0
    for key, weight in cost_weights.items():
        if key not in evaluation:
            raise ValueError(f"truck evaluation missing cost field: {key}")
        total_cost += evaluation[key] * weight
    return total_cost


def apply_drone_sortie_to_solution(
    solution,
    drone_task,
    customers,
    drone_ids_by_truck,
    distance_matrix,
    truck_time_matrix,
    risk_matrix,
    drone_time_matrix,
    drone_distance_matrix,
    periods,
    period_length,
    truck_capacity_by_truck,
    drone_capacity_by_drone,
    drone_endurance_by_drone,
    depot_start,
    depot_end,
    replenishment_node=999,
    start_time=0.0,
    replenishment_time=0.0,
    risk_cost_weight=1.0,
    delay_cost_weight=1.0,
    truck_cost_weights=None,
    unserved_penalty=10000,
):
    """接受一个无人机任务，更新解并重算对应卡车的完整时间线。"""
    required_solution_keys = {
        "truck_routes",
        "drone_routes",
        "next_drone_task_id",
        "phase_start_state_by_truck",
        "unserved",
        "served",
        "validation_report",
    }
    missing_solution_keys = required_solution_keys - set(solution)
    if missing_solution_keys:
        raise ValueError(f"solution missing required keys: {sorted(missing_solution_keys)}")
    if not isinstance(solution["truck_routes"], dict):
        raise ValueError("solution['truck_routes'] must be a dict")
    if not isinstance(solution["drone_routes"], list):
        raise ValueError("solution['drone_routes'] must be a list")
    if not isinstance(solution["served"], set):
        raise ValueError("solution['served'] must be a set")
    if not isinstance(solution["unserved"], (list, set)):
        raise ValueError("solution['unserved'] must be list or set")
    if not isinstance(solution["phase_start_state_by_truck"], dict):
        raise ValueError("solution['phase_start_state_by_truck'] must be a dict")

    required_task_keys = {
        "task_id",
        "truck_id",
        "drone_id",
        "launch_node",
        "customer",
        "recovery_node",
        "period_index",
        "occupied_segments",
        "evaluation",
    }
    missing_task_keys = required_task_keys - set(drone_task)
    if missing_task_keys:
        raise ValueError(f"drone_task missing required keys: {sorted(missing_task_keys)}")

    truck_id = drone_task["truck_id"]
    drone_id = drone_task["drone_id"]
    customer_id = drone_task["customer"]

    if truck_id not in solution["truck_routes"]:
        raise ValueError(f"truck_id {truck_id} is not in solution['truck_routes']")
    if truck_id not in drone_ids_by_truck:
        raise ValueError(f"drone_ids_by_truck missing truck_id {truck_id}")
    if drone_id not in drone_ids_by_truck[truck_id]:
        raise ValueError(f"drone_id {drone_id} does not belong to truck {truck_id}")
    if customer_id not in customers:
        raise ValueError(f"drone customer {customer_id} is not in customers")
    if customer_id in solution["served"]:
        raise ValueError(f"customer {customer_id} is already served")
    if customer_id not in solution["unserved"]:
        raise ValueError(f"customer {customer_id} is not in solution['unserved']")

    validate_unique_drone_task_ids(solution["drone_routes"])
    for existing_task in solution["drone_routes"]:
        if "customer" not in existing_task:
            raise ValueError("existing drone task missing required key: customer")
        if existing_task["customer"] == customer_id:
            raise ValueError(f"customer {customer_id} is already served by a drone task")
        if existing_task.get("truck_id") == truck_id and existing_task.get("drone_id") == drone_id:
            candidate_launch_time, candidate_recovery_time = get_drone_task_interval(
                drone_task
            )
            existing_launch_time, existing_recovery_time = get_drone_task_interval(
                existing_task
            )
            if intervals_overlap(
                candidate_launch_time,
                candidate_recovery_time,
                existing_launch_time,
                existing_recovery_time,
            ):
                raise ValueError(
                    "candidate drone task overlaps existing task: "
                    f"truck={truck_id}, drone={drone_id}, "
                    f"candidate_customer={customer_id} "
                    f"[{candidate_launch_time}, {candidate_recovery_time}], "
                    f"existing_task={existing_task.get('task_id')}, "
                    f"existing_customer={existing_task.get('customer')} "
                    f"[{existing_launch_time}, {existing_recovery_time}]"
                )

    validation_report = solution["validation_report"]
    if "truck_evaluations" not in validation_report:
        raise ValueError("solution['validation_report'] missing truck_evaluations")
    truck_evaluations = validation_report["truck_evaluations"]
    if truck_id not in truck_evaluations:
        raise ValueError(f"validation_report missing evaluation for truck {truck_id}")

    # 1-3. 接受无人机任务，并同步客户服务状态。
    #solution["drone_routes"].append(drone_task)
    append_new_drone_task(solution, drone_task)
    solution["served"].add(customer_id)
    if isinstance(solution["unserved"], set):
        solution["unserved"].remove(customer_id)
    else:
        solution["unserved"].remove(customer_id)
    #这段代码的作用是：在“正式接受一个无人机任务后”，确保当前卡车的 phase_start_state_by_truck 起点状态是存在且正确的，尤其是静态初始阶段的起始载重需要重新计算。
    if truck_id not in solution["phase_start_state_by_truck"]:
        raise ValueError(f"phase_start_state_by_truck missing truck_id {truck_id}")
    start_state = solution["phase_start_state_by_truck"][truck_id]
    #判断当前是不是“静态初始阶段”。
    if start_state["anchor_node"] == depot_start and start_state["anchor_time"] == 0.0:
        """刷新静态阶段的初始载重。为什么需要刷新？
        因为这段代码通常出现在“接受无人机任务”之后。无人机任务加入后，
        某些静态客户可能由无人机服务，而静态无人机客户的需求也要在仓库初始装载时计入卡车库存。"""
        refresh_depot_phase_start_state(
            solution=solution,
            customers=customers,
            depot_start=depot_start,
        )
        #刷新之后重新读取一次。
        start_state = solution["phase_start_state_by_truck"][truck_id]

    # 4-5. 根据所有已接受无人机任务重新统计资源占用，避免局部增量漏算。
    solution["drone_period_usage"] = build_drone_period_usage(solution["drone_routes"])
    solution["segment_usage"] = _build_segment_usage_from_drone_routes(solution["drone_routes"])

    # 6-8. 只重算当前卡车的完整时间线，并写回 validation_report。
    truck_drone_tasks = [
        task
        for task in solution["drone_routes"]
        if task["truck_id"] == truck_id
    ]
    truck_capacity = get_truck_capacity(truck_id, truck_capacity_by_truck)
    updated_evaluation = recompute_truck_timeline_with_drone_waiting(
        truck_route=solution["truck_routes"][truck_id],
        truck_id=truck_id,
        truck_drone_tasks=truck_drone_tasks,
        customers=customers,
        distance_matrix=distance_matrix,
        truck_time_matrix=truck_time_matrix,
        risk_matrix=risk_matrix,
        drone_time_matrix=drone_time_matrix,
        drone_distance_matrix=drone_distance_matrix,
        periods=periods,
        period_length=period_length,
        truck_capacity=truck_capacity,
        drone_capacity_by_drone=drone_capacity_by_drone,
        drone_endurance_by_drone=drone_endurance_by_drone,
        depot_start=depot_start,
        depot_end=depot_end,
        replenishment_node=replenishment_node,
        start_time=start_time,
        anchor_node=start_state["anchor_node"],
        initial_basic_load=start_state["initial_basic_load"],
        initial_emergency_load=start_state["initial_emergency_load"],
        replenishment_time=replenishment_time,
        risk_cost_weight=risk_cost_weight,
        delay_cost_weight=delay_cost_weight,
        cost_weights=truck_cost_weights,
    )
    truck_evaluations[truck_id] = updated_evaluation

    # 9. 重算卡车总成本、无人机总成本和完整解成本。
    route_costs = {
        current_truck_id: calculate_truck_evaluation_cost(
            evaluation,
            cost_weights=truck_cost_weights,
        )
        for current_truck_id, evaluation in truck_evaluations.items()
    }
    # 对所有卡车的 evaluation 重新计算每条路径成本（调用 calculate_truck_evaluation_cost）
    validation_report["route_costs"] = route_costs
    validation_report["total_truck_cost"] = sum(route_costs.values())

    cost_info = calculate_solution_cost(
        solution=solution,
        customers=customers,
        unserved_penalty=unserved_penalty,
    )#调用 calculate_solution_cost 计算完整解的总成本（含无人机成本和未服务惩罚）
    solution["drone_total_cost"] = cost_info["drone_total_cost"]
    solution["unserved_penalty_cost"] = cost_info["unserved_penalty_cost"]
    solution["cost"] = cost_info["total_cost"]
    solution["feasible"] = updated_evaluation["feasible"]

    # 10. 保留调试日志，方便检查每次接受无人机任务后的时间线变化。
    apply_log_entry = {
        "truck_id": truck_id,
        "drone_id": drone_id,
        "customer_id": customer_id,
        "launch_node": drone_task["launch_node"],
        "recovery_node": drone_task["recovery_node"],
        "recomputed_feasible": updated_evaluation["feasible"],
        "truck_total_cost": validation_report["total_truck_cost"],
        "solution_cost": solution["cost"],
        "truck_timeline_violations": updated_evaluation["violations"],
        "truck_timeline_warnings": updated_evaluation["warnings"],
    }
    solution.setdefault("drone_apply_log", []).append(apply_log_entry)

    return {
        "applied": True,
        "drone_task": drone_task,
        "updated_truck_evaluation": updated_evaluation,
        "cost_info": cost_info,
        "log": apply_log_entry,
    }


def construct_drone_routes(
    solution,
    customers,
    drone_ids_by_truck,
    distance_matrix,
    truck_time_matrix,
    risk_matrix,
    drone_distance_matrix,
    drone_time_matrix,
    truck_capacity_by_truck,
    drone_capacity_by_drone,
    drone_endurance_by_drone,
    periods,
    period_length,
    depot_start,
    depot_end,
    replenishment_node=999,
    start_time=0.0,
    replenishment_time=0.0,
    risk_cost_weight=1.0,
    delay_cost_weight=1.0,
    cost_weights=None,
    truck_cost_weights=None,
    unserved_penalty=10000,
    allow_depot_as_launch_recovery=False,
    allow_replenishment_as_launch_recovery=False,
    update_solution=True,
):
    """为当前未服务客户构造无人机单次服务任务。"""
    required_keys = {
        "truck_routes",
        "drone_routes",
        "next_drone_task_id",
        "phase_start_state_by_truck",
        "unserved",
        "served",
        "validation_report",
    }
    missing_keys = required_keys - set(solution)
    if missing_keys:
        raise ValueError(f"solution missing required keys: {sorted(missing_keys)}")

    if "drone_routes" not in solution:
        solution["drone_routes"] = []
    if not isinstance(solution["drone_routes"], list):
        raise ValueError("solution['drone_routes'] must be a list")
    if not isinstance(solution["truck_routes"], dict):
        raise ValueError("solution['truck_routes'] must be a dict")

    if not isinstance(solution["served"], set):
        solution["served"] = set(solution["served"])
    if not isinstance(solution["unserved"], (list, set)):
        raise ValueError("solution['unserved'] must be list or set")

    validation_report = solution["validation_report"]
    if "truck_evaluations" not in validation_report:
        raise ValueError("solution['validation_report'] missing truck_evaluations")
    drone_period_usage = build_drone_period_usage(solution["drone_routes"])
    segment_usage = _build_segment_usage_from_drone_routes(solution["drone_routes"])

    drone_route_log = []
    warnings = []
    assigned_count = 0

    candidate_customers = list(solution["unserved"])

    for customer_id in candidate_customers:
        if customer_id not in customers:
            warnings.append(f"unserved customer {customer_id} is not in customers")
            continue

        if customer_id in solution["served"]:
            if update_solution and customer_id in solution["unserved"]:
                solution["unserved"].remove(customer_id)
            drone_route_log.append(
                {
                    "customer_id": customer_id,
                    "assigned": False,
                    "skipped": True,
                    "reason": "already served",
                    "candidate_count": 0,
                    "failed_candidate_count": 0,
                }
            )
            continue

        customer_candidates = []
        failed_candidates = []

        for truck_id, truck_route in solution["truck_routes"].items():
            truck_evaluations = solution["validation_report"]["truck_evaluations"]
            if truck_id not in truck_evaluations:
                raise ValueError(f"validation_report missing evaluation for truck {truck_id}")
            if truck_id not in drone_ids_by_truck:
                raise ValueError(f"drone_ids_by_truck missing truck {truck_id}")

            # 每次枚举候选时都读取最新卡车时间线；
            # 已接受无人机任务造成的等待会由 apply_drone_sortie_to_solution 写回这里。
            truck_evaluation = truck_evaluations[truck_id]
            #遍历该卡车携带的每架无人机
            for drone_id in drone_ids_by_truck[truck_id]:
                drone_capacity = get_drone_capacity(drone_id, drone_capacity_by_drone)
                drone_endurance = get_drone_endurance(drone_id, drone_endurance_by_drone)

                for launch_idx in range(len(truck_route)):
                    for recovery_idx in range(launch_idx + 1, len(truck_route)):
                        launch_node = truck_route[launch_idx]
                        recovery_node = truck_route[recovery_idx]

                        if launch_node == recovery_node:
                            continue
                        if not allow_depot_as_launch_recovery:
                            if launch_node in {depot_start, depot_end} or recovery_node in {depot_start, depot_end}:
                                continue
                        if not allow_replenishment_as_launch_recovery:
                            if launch_node == replenishment_node or recovery_node == replenishment_node:
                                continue

                        sortie_eval = evaluate_drone_sortie(
                            truck_route=truck_route,
                            truck_evaluation=truck_evaluation,
                            truck_id=truck_id,
                            drone_id=drone_id,
                            launch_node=launch_node,
                            customer_id=customer_id,
                            recovery_node=recovery_node,
                            customers=customers,
                            drone_distance_matrix=drone_distance_matrix,
                            drone_time_matrix=drone_time_matrix,
                            drone_capacity=drone_capacity,
                            drone_endurance=drone_endurance,
                            depot_start=depot_start,
                            depot_end=depot_end,
                            replenishment_node=replenishment_node,
                            periods=periods,
                            period_length=period_length,
                            cost_weights=cost_weights,
                        )

                        if not sortie_eval["feasible"]:
                            failed_candidates.append(
                                {
                                    "truck_id": truck_id,
                                    "drone_id": drone_id,
                                    "launch_node": launch_node,
                                    "recovery_node": recovery_node,
                                    "violations": sortie_eval.get("violations", []),
                                }
                            )
                            continue

                        can_add = can_add_drone_sortie(
                            sortie_eval=sortie_eval,
                            solution=solution,
                            drone_ids_by_truck=drone_ids_by_truck,
                            drone_period_usage=drone_period_usage,
                            segment_usage=segment_usage,
                        )
                        if not can_add["can_add"]:
                            failed_candidates.append(
                                {
                                    "truck_id": truck_id,
                                    "drone_id": drone_id,
                                    "launch_node": launch_node,
                                    "recovery_node": recovery_node,
                                    "violations": can_add["violations"],
                                }
                            )
                            continue

                        customer_candidates.append(sortie_eval)

        if customer_candidates:
            best = min(customer_candidates, key=lambda item: item["cost"])
            required_position_keys = {"launch_idx", "recovery_idx"}
            missing_position_keys = required_position_keys - set(best)
            if missing_position_keys:
                raise ValueError(
                    "selected drone sortie missing required position keys: "
                    f"{sorted(missing_position_keys)}"
                )
            drone_task = {
                "task_id": preview_next_drone_task_id(solution),
                "truck_id": best["truck_id"],
                "drone_id": best["drone_id"],
                "launch_node": best["launch_node"],
                "launch_idx": best["launch_idx"],
                "customer": best["customer_id"],
                "recovery_node": best["recovery_node"],
                "recovery_idx": best["recovery_idx"],
                "period_index": best["period_index"],
                "launch_time": best["launch_time"],
                "recovery_time": best["recovery_time"],
                "cost": best["cost"],
                "occupied_segments": best["occupied_segments"],
                "evaluation": best,
            }

            if update_solution:
                apply_result = apply_drone_sortie_to_solution(
                    solution=solution,
                    drone_task=drone_task,
                    customers=customers,
                    drone_ids_by_truck=drone_ids_by_truck,
                    distance_matrix=distance_matrix,
                    truck_time_matrix=truck_time_matrix,
                    risk_matrix=risk_matrix,
                    drone_time_matrix=drone_time_matrix,
                    drone_distance_matrix=drone_distance_matrix,
                    periods=periods,
                    period_length=period_length,
                    truck_capacity_by_truck=truck_capacity_by_truck,
                    drone_capacity_by_drone=drone_capacity_by_drone,
                    drone_endurance_by_drone=drone_endurance_by_drone,
                    depot_start=depot_start,
                    depot_end=depot_end,
                    replenishment_node=replenishment_node,
                    start_time=start_time,
                    replenishment_time=replenishment_time,
                    risk_cost_weight=risk_cost_weight,
                    delay_cost_weight=delay_cost_weight,
                    truck_cost_weights=truck_cost_weights,
                    unserved_penalty=unserved_penalty,
                )
                drone_period_usage = solution["drone_period_usage"]
                segment_usage = solution["segment_usage"]
            else:
                apply_result = None

            assigned_count += 1
            drone_route_log.append(
                {
                    "customer_id": customer_id,
                    "assigned": True,
                    "selected_task": drone_task,
                    "apply_result": apply_result,
                    "candidate_count": len(customer_candidates),
                    "failed_candidate_count": len(failed_candidates),
                }
            )
        else:
            drone_route_log.append(
                {
                    "customer_id": customer_id,
                    "assigned": False,
                    "candidate_count": 0,
                    "failed_candidate_count": len(failed_candidates),
                    "sample_violations": failed_candidates[:5],
                }
            )

    cost_info = calculate_solution_cost(
        solution=solution,
        customers=customers,
        unserved_penalty=unserved_penalty,
    )
    drone_total_cost = cost_info["drone_total_cost"]
    truck_total_cost = cost_info["truck_total_cost"]
    total_cost = cost_info["total_cost"]

    if update_solution:
        solution["drone_total_cost"] = drone_total_cost
        solution["cost"] = total_cost
        solution["unserved_penalty_cost"] = cost_info["unserved_penalty_cost"]
        solution["drone_construction_log"] = drone_route_log
        solution["segment_usage"] = segment_usage
        solution["drone_period_usage"] = drone_period_usage

    report = {
        "assigned_count": assigned_count,
        "remaining_unserved": list(solution["unserved"]),
        "drone_total_cost": drone_total_cost,
        "truck_total_cost": truck_total_cost,
        "total_cost": total_cost,
        "cost_info": cost_info,
        "drone_routes": solution["drone_routes"],
        "drone_period_usage": drone_period_usage,
        "segment_usage": segment_usage,
        "drone_apply_log": solution.get("drone_apply_log", []),
        "log": drone_route_log,
        "warnings": warnings,
    }
    return solution, report


def calculate_solution_cost(
    solution,
    customers,
    unserved_penalty=10000,
    cost_weights=None,
):
    """按统一四项目标函数计算完整解总成本。"""
    weights = default_cost_weights() if cost_weights is None else cost_weights
    unknown_keys = set(weights) - SUPPORTED_COST_KEYS
    if unknown_keys:
        raise ValueError(f"cost_weights contains unsupported keys: {sorted(unknown_keys)}")

    required_solution_keys = {"validation_report", "drone_routes", "unserved"}
    missing_solution_keys = required_solution_keys - set(solution)
    if missing_solution_keys:
        raise ValueError(f"solution missing required keys: {sorted(missing_solution_keys)}")

    validation_report = solution["validation_report"]
    if "total_truck_cost" not in validation_report:
        raise ValueError("solution validation_report missing total_truck_cost")
    truck_total_cost = validation_report["total_truck_cost"]

    drone_routes = solution["drone_routes"]
    validate_unique_drone_task_ids(drone_routes)
    drone_total_cost = 0.0
    for task_index, task in enumerate(drone_routes):
        if "cost" not in task:
            raise ValueError(f"drone task {task_index} missing cost")
        drone_total_cost += task["cost"]

    raw_unserved_penalty_cost = 0.0
    for customer_id in solution["unserved"]:
        if customer_id not in customers:
            raise ValueError(f"unserved customer {customer_id} is not in customers")

        customer = customers[customer_id]
        required_customer_keys = {
            "basic_demand",
            "emergency_demand",
            "is_static",
        }
        missing_customer_keys = required_customer_keys - set(customer)
        if missing_customer_keys:
            raise ValueError(
                f"customer {customer_id} missing required cost keys: "
                f"{sorted(missing_customer_keys)}"
            )

        raw_unserved_penalty_cost += (
            unserved_penalty
            * require_customer_priority_weight(customer_id, customers)
        )

    unserved_penalty_cost = (
        raw_unserved_penalty_cost * weights["unserved_penalty_cost"]
    )
    total_cost = truck_total_cost + drone_total_cost + unserved_penalty_cost

    return {
        "total_cost": total_cost,
        "truck_total_cost": truck_total_cost,
        "drone_total_cost": drone_total_cost,
        "unserved_penalty_cost": unserved_penalty_cost,
        "raw_unserved_penalty_cost": raw_unserved_penalty_cost,
    }


def validate_full_solution(
    solution,
    customers,
    drone_ids_by_truck,
    depot_start,
    depot_end,
    replenishment_node=999,
    periods=None,
    period_length=None,
    unserved_penalty=10000,
    update_solution=True,
    raise_error=False,
):
    """检查完整初始解的一致性，不重新评价卡车路径和无人机路径。"""
    violations = []
    warnings = []

    def add_violation(message):
        violations.append(message)

    def add_warning(message):
        warnings.append(message)

    def get_task_time(task, field_name):
        """第1层：直接键访问，用于任务顶层已经直接存储该时间的情况。
第2层：获取 evaluation 字段，确保它是字典。
优先查找 evaluation["recomputed"]（如果存在且为字典）中的字段 —— 这通常用于存储经过去重算或修正后的时间。
其次查找 evaluation[field_name] —— 原始的评估结果。
如果所有尝试都失败，抛出 ValueError 并指明缺失的字段名。
task["evaluation"] 中的 "recomputed" 子字典：通常存放重算或修正后的时间。
task["evaluation"] 顶层：原始评估结果中的时间字段。"""
        if field_name in task:
            value = task[field_name]
            if value is None:
                raise ValueError(f"drone task time field {field_name} is None")
            return value
        evaluation = task.get("evaluation")
        if isinstance(evaluation, dict):
            recomputed = evaluation.get("recomputed")
            if isinstance(recomputed, dict) and field_name in recomputed:
                value = recomputed[field_name]
                if value is None:
                    raise ValueError(f"drone task time field {field_name} is None")
                return value
            if field_name in evaluation:
                value = evaluation[field_name]
                if value is None:
                    raise ValueError(f"drone task time field {field_name} is None")
                return value
        raise ValueError(f"drone task missing time field: {field_name}")

    def find_optional_task_time(task, field_name):
        """查找可选时间字段；找不到时返回 None。"""
        if field_name in task:
            return task[field_name]
        evaluation = task.get("evaluation")
        if isinstance(evaluation, dict):
            recomputed = evaluation.get("recomputed")
            if isinstance(recomputed, dict) and field_name in recomputed:
                return recomputed[field_name]
            if field_name in evaluation:
                return evaluation[field_name]
        return None

    def resolve_route_index(task_idx, task, truck_route, node_key, index_key):
        #解析无人机任务中某个节点（发射点或回收点）在卡车路径中的位置索引。
        node = task[node_key]
        route_indices_by_node = {}
        for index, route_node in enumerate(truck_route):
            route_indices_by_node.setdefault(route_node, []).append(index)
        if node not in route_indices_by_node:
            add_violation(f"drone task {task_idx} {node_key} {node} not in truck route")
            return None
        if index_key in task:
            index_value = task[index_key]
            if isinstance(index_value, bool) or not isinstance(index_value, int):
                add_violation(
                    f"drone task {task_idx} {index_key} must be int, "
                    f"got {type(index_value).__name__}"
                )
                return None
            if index_value < 0 or index_value >= len(truck_route):
                add_violation(
                    f"drone task {task_idx} {index_key} {index_value} "
                    f"outside truck route length {len(truck_route)}"
                )
                return None
            if truck_route[index_value] != node:
                add_violation(
                    f"drone task {task_idx} {index_key} points to "
                    f"{truck_route[index_value]}, expected {node}"
                )
                return None
            return index_value
        # 5. 若未提供索引字段，则从路径中查找该节点的所有出现位置
        indices = route_indices_by_node[node]
        # 5.1 若节点在路径中出现多次（非唯一），则无法自动确定，必须提供索引
        if len(indices) != 1:
            add_violation(
                f"drone task {task_idx} {node_key} {node} is ambiguous without "
                f"{index_key}: indices={indices}"
            )
            return None
        return indices[0]

    required_keys = {
        "truck_routes",
        "drone_routes",
        "next_drone_task_id",
        "unserved",
        "served",
        "cost",
        "validation_report",
    }
    missing_keys = required_keys - set(solution)
    if missing_keys:
        add_violation(f"solution missing required keys: {sorted(missing_keys)}")

    truck_routes = solution.get("truck_routes", {})
    drone_routes = solution.get("drone_routes", [])
    raw_unserved = solution.get("unserved", [])
    raw_served = solution.get("served", set())
    validation_report = solution.get("validation_report", {})

    if not isinstance(truck_routes, dict):
        add_violation("solution['truck_routes'] must be a dict")
        truck_routes = {}
    if not isinstance(drone_routes, list):
        add_violation("solution['drone_routes'] must be a list")
        drone_routes = []
    else:
        validate_unique_drone_task_ids(drone_routes)
    if not isinstance(raw_unserved, (list, set)):
        add_violation("solution['unserved'] must be a list or set")
        raw_unserved = []
    if not isinstance(validation_report, dict):
        add_violation("solution['validation_report'] must be a dict")
        validation_report = {}

    truck_evaluations = validation_report.get("truck_evaluations", {})
    if drone_routes and not isinstance(truck_evaluations, dict):
        add_violation("solution['validation_report']['truck_evaluations'] must be a dict")
        truck_evaluations = {}
    # 卡车重算评价是完整解可行性的硬约束来源。
    if not isinstance(truck_evaluations, dict):
        add_violation("solution['validation_report']['truck_evaluations'] must be a dict")
        truck_evaluations = {}
    for truck_id, truck_evaluation in truck_evaluations.items():
        if not isinstance(truck_evaluation, dict):
            add_violation(f"truck evaluation of truck {truck_id} must be a dict")
            continue
        if "feasible" not in truck_evaluation:
            add_violation(f"truck evaluation of truck {truck_id} missing feasible")
        elif truck_evaluation["feasible"] is not True:
            add_violation(
                f"truck evaluation of truck {truck_id} is infeasible: "
                f"{truck_evaluation.get('violations', [])}"
            )
        if "violations" not in truck_evaluation:
            add_violation(f"truck evaluation of truck {truck_id} missing violations")
        elif truck_evaluation["violations"]:
            add_violation(
                f"truck evaluation of truck {truck_id} has violations: "
                f"{truck_evaluation['violations']}"
            )

    try:
        served = set(raw_served)
    except TypeError:
        add_violation("solution['served'] must be convertible to set")
        served = set()

    unserved = set(raw_unserved)
    non_customer_nodes = {depot_start, depot_end, replenishment_node}
    phase_start_state_by_truck = solution.get("phase_start_state_by_truck", {})
    if not isinstance(phase_start_state_by_truck, dict):
        add_violation("solution['phase_start_state_by_truck'] must be a dict")
        phase_start_state_by_truck = {}
    phase_locked_customer_ids = solution.get("phase_locked_customer_ids", set())
    if not isinstance(phase_locked_customer_ids, set):
        add_violation("solution['phase_locked_customer_ids'] must be a set")
        phase_locked_customer_ids = set()

    # B. 客户服务状态检查：卡车服务、无人机服务、未服务三类必须一致。
    truck_served_customers = set()
    truck_customer_counts = {}
    for truck_id, route in truck_routes.items():
        truck_evaluation = truck_evaluations.get(truck_id, {})
        if not isinstance(truck_evaluation, dict):
            truck_evaluation = {}
        replenishment_records = truck_evaluation.get("replenishment_records", [])
        if not isinstance(replenishment_records, list):
            add_violation(
                f"truck evaluation of truck {truck_id} replenishment_records must be a list"
            )
            replenishment_records = []
        arrival_times_by_index = truck_evaluation.get("arrival_times_by_index", {})
        if not isinstance(arrival_times_by_index, dict):
            arrival_times_by_index = {}
        if not route:
            add_violation(f"truck route of truck {truck_id} is empty")
            continue
        expected_start = depot_start
        if truck_id in phase_start_state_by_truck:
            truck_start_state = phase_start_state_by_truck[truck_id]
            if not isinstance(truck_start_state, dict):
                add_violation(
                    f"phase_start_state_by_truck[{truck_id}] must be a dict"
                )
            elif "anchor_node" not in truck_start_state:
                add_violation(
                    f"phase_start_state_by_truck[{truck_id}] missing anchor_node"
                )
            else:
                expected_start = truck_start_state["anchor_node"]
        if route[0] != expected_start:
            add_violation(
                f"truck route of truck {truck_id} must start with fixed start "
                f"node {expected_start}"
            )
        if route[-1] != depot_end:
            add_violation(
                f"truck route of truck {truck_id} must end with depot_end {depot_end}"
            )

        for index, node in enumerate(route):
            if node == depot_start and index != 0:
                add_violation(
                    f"truck route of truck {truck_id} contains depot_start {depot_start} "
                    f"outside the first position"
                )
            if node == depot_end and index != len(route) - 1:
                add_violation(
                    f"truck route of truck {truck_id} contains depot_end {depot_end} "
                    f"outside the last position"
                )
            if node == replenishment_node:
                add_violation(
                    f"truck route of truck {truck_id} contains deprecated "
                    f"replenishment node {replenishment_node}"
                )
                continue
            if node in customers:
                if "is_static" not in customers[node]:
                    raise ValueError(f"customer {node} missing required field: is_static")

            if node in non_customer_nodes:
                continue
            if index == 0 and node in phase_locked_customer_ids:
                continue
            if node not in customers:
                add_violation(f"truck route of truck {truck_id} contains unknown customer {node}")
                continue
            truck_served_customers.add(node)
            truck_customer_counts[node] = truck_customer_counts.get(node, 0) + 1

    for customer_id, count in truck_customer_counts.items():
        if count > 1:
            add_violation(f"customer {customer_id} is served by truck {count} times")

    drone_served_customers = set()
    drone_customer_counts = {}
    for task_idx, task in enumerate(drone_routes):
        if "customer" not in task:
            add_violation(f"drone task {task_idx} missing customer")
            continue
        customer_id = task["customer"]
        drone_served_customers.add(customer_id)
        drone_customer_counts[customer_id] = drone_customer_counts.get(customer_id, 0) + 1

    overlap = truck_served_customers & drone_served_customers
    if overlap:
        add_violation(f"customers served by both truck and drone: {sorted(overlap)}")

    for customer_id, count in drone_customer_counts.items():
        if count > 1:
            add_violation(f"customer {customer_id} is served by {count} drone tasks")

    corrected_served = truck_served_customers | drone_served_customers
    if served != corrected_served:
        add_warning(
            f"solution['served'] inconsistent with routes; "
            f"served={sorted(served)}, corrected_served={sorted(corrected_served)}"
        )

    for customer_id in unserved:
        if customer_id not in customers:
            add_violation(f"unserved contains unknown customer {customer_id}")

    served_unserved_overlap = corrected_served & unserved
    if served_unserved_overlap:
        add_violation(
            f"customers appear in both served and unserved: {sorted(served_unserved_overlap)}"
        )

    missing_customers = set(customers) - corrected_served - unserved
    if missing_customers:
        add_warning(
            f"customers neither served nor unserved: {sorted(missing_customers)}"
        )

    # C-E. 无人机任务结构、周期占用和路段占用检查。
    drone_period_usage = {}
    segment_usage = {}
    drone_intervals_by_drone = {}

    for task_idx, task in enumerate(drone_routes):
        required_task_keys = {
            "truck_id",
            "drone_id",
            "launch_node",
            "customer",
            "recovery_node",
            "period_index",
            "occupied_segments",
        }
        missing_task_keys = required_task_keys - set(task)
        if missing_task_keys:
            add_violation(
                f"drone task {task_idx} missing required keys: {sorted(missing_task_keys)}"
            )
            continue

        truck_id = task["truck_id"]
        drone_id = task["drone_id"]
        launch_node = task["launch_node"]
        recovery_node = task["recovery_node"]
        customer_id = task["customer"]
        period_index = task["period_index"]
        occupied_segments = task["occupied_segments"]

        if period_index is None:
            add_violation(f"drone task {task_idx} period_index must not be None")

        if truck_id not in truck_routes:
            add_violation(f"drone task {task_idx} truck_id {truck_id} not in truck_routes")
            continue
        if truck_id not in drone_ids_by_truck:
            add_violation(f"drone_ids_by_truck missing truck_id {truck_id}")
            continue
        if drone_id not in drone_ids_by_truck[truck_id]:
            add_violation(
                f"drone task {task_idx} drone_id {drone_id} does not belong to truck {truck_id}"
            )

        truck_route = truck_routes[truck_id]
        truck_evaluation = truck_evaluations.get(truck_id)
        if not isinstance(truck_evaluation, dict):
            add_violation(f"validation_report missing recomputed evaluation for truck {truck_id}")
            truck_evaluation = {}
        arrival_times = truck_evaluation.get("arrival_times")
        if not isinstance(arrival_times, dict):
            add_violation(f"truck evaluation of truck {truck_id} missing arrival_times")
            arrival_times = {}
        arrival_times_by_index = truck_evaluation.get("arrival_times_by_index")
        if not isinstance(arrival_times_by_index, dict):
            add_violation(
                f"truck evaluation of truck {truck_id} missing arrival_times_by_index"
            )
            arrival_times_by_index = {}

        launch_idx = resolve_route_index(
            task_idx, task, truck_route, "launch_node", "launch_idx"
        )
        recovery_idx = resolve_route_index(
            task_idx, task, truck_route, "recovery_node", "recovery_idx"
        )
        if launch_idx is not None and recovery_idx is not None:
            if launch_idx >= recovery_idx:
                add_violation(
                    f"drone task {task_idx} launch_node must appear before recovery_node"
                )
            else:
                # 同步一致性：无人机占用的卡车路段必须正好覆盖发射点到回收点之间的路段。
                expected_segments = [
                    (truck_id, seg_idx)
                    for seg_idx in range(launch_idx, recovery_idx)
                ]
                if isinstance(occupied_segments, list) and occupied_segments != expected_segments:
                    add_violation(
                        f"drone task {task_idx} occupied_segments inconsistent: "
                        f"expected={expected_segments}, actual={occupied_segments}"
                    )

        if customer_id not in customers:
            add_violation(f"drone task {task_idx} customer {customer_id} not in customers")

        if customer_id in customers:
            if "is_static" not in customers[customer_id]:
                raise ValueError(f"customer {customer_id} missing required field: is_static")
            customer_is_static = customers[customer_id]["is_static"]
            if not isinstance(customer_is_static, bool):
                add_violation(
                    f"drone task {task_idx} customer {customer_id} is_static must be bool, "
                    f"got {type(customer_is_static).__name__}"
                )

        # 同步一致性：无人机必须在卡车到达发射节点时起飞。
        try:
            launch_time = get_task_time(task, "launch_time")
            recovery_time = get_task_time(task, "recovery_time")
        except ValueError as exc:
            add_violation(f"drone task {task_idx} {exc}")
            launch_time = None
            recovery_time = None
        if launch_time is not None and recovery_time is not None:
            if (
                isinstance(launch_time, bool)
                or isinstance(recovery_time, bool)
                or not isinstance(launch_time, (int, float))
                or not isinstance(recovery_time, (int, float))
            ):
                add_violation(
                    f"drone task {task_idx} launch_time and recovery_time must be numeric"
                )
            elif recovery_time < launch_time:
                add_violation(
                    f"drone task {task_idx} recovery_time {recovery_time} "
                    f"is before launch_time {launch_time}"
                )
            else:
                interval_key = (truck_id, drone_id)
                drone_intervals_by_drone.setdefault(interval_key, []).append(
                    {
                        "task_idx": task_idx,
                        "customer": customer_id,
                        "launch_time": float(launch_time),
                        "recovery_time": float(recovery_time),
                    }
                )

        customer_service_start_for_release = find_optional_task_time(
            task,
            "customer_service_start",
        )
        if (
            customer_id in customers
            and "is_static" in customers[customer_id]
            and customers[customer_id]["is_static"] is False
        ):
            if "release_time" not in customers[customer_id]:
                raise ValueError(f"customer {customer_id} missing required field: release_time")
            release_time = customers[customer_id]["release_time"]
            if isinstance(release_time, bool) or not isinstance(release_time, (int, float)):
                add_violation(
                    f"dynamic customer {customer_id} release_time must be numeric, "
                    f"got {type(release_time).__name__}"
                )
            else:
                if customer_service_start_for_release is None:
                    add_violation(
                        f"drone task {task_idx} missing customer_service_start for release_time validation"
                    )
                elif customer_service_start_for_release < release_time:
                    add_violation(
                        f"dynamic customer {customer_id} served before release_time: "
                        f"service_start={customer_service_start_for_release}, release_time={release_time}"
                    )

        if launch_time is not None:
            if launch_idx is None:
                add_violation(
                    f"drone task {task_idx} launch_idx is required for launch_time validation"
                )
            elif launch_idx not in arrival_times_by_index:
                add_violation(
                    f"truck evaluation of truck {truck_id} missing arrival_time for launch_idx {launch_idx}"
                )
            else:
                expected_launch_time = arrival_times_by_index[launch_idx]
                if abs(launch_time - expected_launch_time) > 1e-6:
                    add_violation(
                        f"drone task {task_idx} launch_time inconsistent: "
                        f"expected truck arrival {expected_launch_time}, actual {launch_time}"
                    )

        # 弱检查：单个任务记录的等待时间可能不同于同一回收点的最终等待，
        # 因为多架无人机同时回收时卡车实际等到最晚 recovery_time。
        #查任务中记录的“卡车等待时间”是否与基于实际时间计算出的理论等待时间一致。
        if recovery_time is not None and "truck_waiting_time" in task:
            #recovery_time 是无人机返回卡车（回收节点）的时刻（通常通过 get_task_time 获取）
            if recovery_idx is None:

                add_warning(
                    f"drone task {task_idx} recovery_idx is required for waiting-time validation"
                )
            elif recovery_idx not in arrival_times_by_index:

                add_warning(
                    f"truck evaluation of truck {truck_id} missing arrival_time for recovery_idx {recovery_idx}"
                )
            else:
                expected_wait = max(0.0, recovery_time - arrival_times_by_index[recovery_idx])#表示无人机返回时刻减去卡车到达回收节点的时刻。
                #将任务中记录的 truck_waiting_time 与刚计算的 expected_wait 进行比较
                if abs(task["truck_waiting_time"] - expected_wait) > 1e-6:
                    add_warning(
                        f"drone task {task_idx} truck_waiting_time inconsistent: "
                        f"expected {expected_wait}, actual {task['truck_waiting_time']}"
                    )

        key = (drone_id, period_index)
        drone_period_usage[key] = drone_period_usage.get(key, 0) + 1

        if not isinstance(occupied_segments, list):
            add_violation(f"drone task {task_idx} occupied_segments must be a list")
            continue

        for seg in occupied_segments:
            if not isinstance(seg, tuple) or len(seg) != 2:
                add_violation(f"drone task {task_idx} invalid occupied segment {seg}")
                continue
            seg_truck_id, seg_idx = seg
            if seg_truck_id != truck_id:
                add_violation(
                    f"drone task {task_idx} occupied segment {seg} truck_id "
                    f"does not match task truck_id {truck_id}"
                )
            if not isinstance(seg_idx, int):
                add_violation(f"drone task {task_idx} segment index must be int: {seg}")
                continue
            if seg_idx < 0 or seg_idx >= len(truck_route) - 1:
                add_violation(f"drone task {task_idx} segment index out of range: {seg}")
                continue
            segment_usage[seg] = segment_usage.get(seg, 0) + 1

    for seg, count in segment_usage.items():
        truck_id = seg[0]
        if truck_id not in drone_ids_by_truck:
            add_violation(f"segment {seg} references truck missing in drone_ids_by_truck")
            continue
        limit = len(drone_ids_by_truck[truck_id])
        if count > limit:
            add_violation(
                f"segment {seg} drone usage {count} exceeds truck {truck_id} limit {limit}"
            )

    for (truck_id, drone_id), intervals in drone_intervals_by_drone.items():
        intervals.sort(key=lambda item: (item["launch_time"], item["recovery_time"]))
        for previous, current in zip(intervals, intervals[1:]):
            if current["launch_time"] < previous["recovery_time"]:
                add_violation(
                    f"drone {drone_id} on truck {truck_id} has overlapping tasks: "
                    f"task {previous['task_idx']} customer {previous['customer']} "
                    f"[{previous['launch_time']}, {previous['recovery_time']}] and "
                    f"task {current['task_idx']} customer {current['customer']} "
                    f"[{current['launch_time']}, {current['recovery_time']}]"
                )

    # F. 成本检查：只复算汇总成本，不重评路径。
    cost_info = calculate_solution_cost(
        solution=solution,
        customers=customers,
        unserved_penalty=unserved_penalty,
    )
    existing_cost = solution.get("cost")
    if existing_cost != cost_info["total_cost"]:
        add_warning(
            f"solution cost inconsistent: current={existing_cost}, "
            f"calculated={cost_info['total_cost']}"
        )

    report = {
        "valid": len(violations) == 0,
        "feasible": len(violations) == 0,
        "cost_info": cost_info,
        "truck_served_customers": truck_served_customers,
        "drone_served_customers": drone_served_customers,
        "corrected_served": corrected_served,
        "unserved": unserved,
        "missing_customers": missing_customers,
        "drone_period_usage": drone_period_usage,
        "segment_usage": segment_usage,
        "violations": violations,
        "warnings": warnings,
    }

    if update_solution:
        solution["served"] = corrected_served
        solution["cost"] = cost_info["total_cost"]
        solution["drone_total_cost"] = cost_info["drone_total_cost"]
        solution["unserved_penalty_cost"] = cost_info["unserved_penalty_cost"]
        solution["segment_usage"] = segment_usage
        solution["drone_period_usage"] = drone_period_usage
        solution["full_validation_report"] = report
        solution["feasible"] = len(violations) == 0

    if raise_error and violations:
        preview = "\n".join(f"- {message}" for message in violations[:10])
        raise ValueError(f"full solution validation failed:\n{preview}")

    return report
