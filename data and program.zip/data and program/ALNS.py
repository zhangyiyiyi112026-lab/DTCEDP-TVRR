﻿from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional, Callable, Any, Set
import math
import random
import heapq
import copy
import hashlib
import json
import os
import time
from pathlib import Path

from truck_routes import calculate_route_cost, evaluate_truck_route
from utils import ROAD_RISK_DISTANCE_SCALE
from priority_rules import require_customer_priority_weight
from solution import refresh_depot_phase_start_state
from replanning_types import (
    append_new_drone_task,
    preview_next_drone_task_id,
    validate_unique_drone_task_ids,
)
from UAV_routes import *


# =============================
# Profiling
# =============================

_PROFILE_STATS: Dict[str, float] = {}

def _profile_enabled() -> bool:
    return os.environ.get("ALNS_PROFILE") == "1"

def _profile_add(name: str, seconds: float) -> None:
    if not _profile_enabled():
        return
    _PROFILE_STATS[name] = _PROFILE_STATS.get(name, 0.0) + seconds
def _profile_count(name: str, amount: int = 1) -> None:
    if not _profile_enabled():
        return
    _PROFILE_STATS[name] = _PROFILE_STATS.get(name, 0.0) + amount
def _profile_reset() -> None:
    _PROFILE_STATS.clear()
def _profile_average(seconds_name: str, calls_name: str) -> float:
    calls = _PROFILE_STATS.get(calls_name, 0.0)
    if calls == 0:
        return 0.0
    return _PROFILE_STATS.get(seconds_name, 0.0) / calls

def _profile_average_count(total_name: str, calls_name: str) -> float:
    calls = _PROFILE_STATS.get(calls_name, 0.0)
    if calls == 0:
        return 0.0
    return _PROFILE_STATS.get(total_name, 0.0) / calls

def _profile_finish_timed_call(prefix: str, start_time: Optional[float]) -> None:
    if start_time is None:
        return
    _profile_count(f"{prefix}_calls")
    _profile_add(f"{prefix}_seconds", time.perf_counter() - start_time)


def _profile_print_summary() -> None:
    rebuild_calls = _PROFILE_STATS.get("rebuild_total_calls", 0.0)
    rebuild_seconds = _PROFILE_STATS.get("rebuild_total_seconds", 0.0)
    truck_eval_calls = _PROFILE_STATS.get("evaluate_truck_route_calls", 0.0)
    truck_eval_seconds = _PROFILE_STATS.get("evaluate_truck_route_seconds", 0.0)
    deepcopy_calls = _PROFILE_STATS.get("solution_deepcopy_calls", 0.0)
    deepcopy_seconds = _PROFILE_STATS.get("solution_deepcopy_seconds", 0.0)
    drone_position_calls = _PROFILE_STATS.get("all_drone_insert_positions_calls", 0.0)
    drone_position_seconds = _PROFILE_STATS.get("all_drone_insert_positions_seconds", 0.0)
    drone_position_candidates = _PROFILE_STATS.get("all_drone_insert_positions_candidates", 0.0)
    sortie_calls = _PROFILE_STATS.get("evaluate_drone_sortie_calls", 0.0)
    sortie_seconds = _PROFILE_STATS.get("evaluate_drone_sortie_seconds", 0.0)
    all_insert_calls = _PROFILE_STATS.get("all_insert_deltas_calls", 0.0)
    all_insert_seconds = _PROFILE_STATS.get("all_insert_deltas_seconds", 0.0)
    all_insert_returned_moves = _PROFILE_STATS.get("all_insert_deltas_returned_moves", 0.0)

    print("[ALNS_PROFILE]")
    print(
        "  rebuild_solution: "
        f"calls={int(rebuild_calls)}, "
        f"total={rebuild_seconds:.2f}s, "
        f"avg={_profile_average('rebuild_total_seconds', 'rebuild_total_calls'):.6f}s"
    )
    print(
        "    "
        f"full_validate_calls={int(_PROFILE_STATS.get('rebuild_full_validate_calls', 0.0))}, "
        f"lightweight_calls={int(_PROFILE_STATS.get('rebuild_lightweight_calls', 0.0))}"
    )
    print(
        "  evaluate_truck_route: "
        f"calls={int(truck_eval_calls)}, "
        f"total={truck_eval_seconds:.2f}s, "
        f"avg={_profile_average('evaluate_truck_route_seconds', 'evaluate_truck_route_calls'):.6f}s"
    )
    print(
        "  solution_deepcopy: "
        f"calls={int(deepcopy_calls)}, "
        f"total={deepcopy_seconds:.2f}s, "
        f"avg={_profile_average('solution_deepcopy_seconds', 'solution_deepcopy_calls'):.6f}s"
    )
    print(
        "  _all_drone_insert_positions: "
        f"calls={int(drone_position_calls)}, "
        f"total={drone_position_seconds:.2f}s, "
        f"avg={_profile_average('all_drone_insert_positions_seconds', 'all_drone_insert_positions_calls'):.6f}s, "
        f"candidates={int(drone_position_candidates)}, "
        f"avg_candidates={_profile_average_count('all_drone_insert_positions_candidates', 'all_drone_insert_positions_calls'):.2f}"
    )
    print(
        "  evaluate_drone_sortie: "
        f"calls={int(sortie_calls)}, "
        f"total={sortie_seconds:.2f}s, "
        f"avg={_profile_average('evaluate_drone_sortie_seconds', 'evaluate_drone_sortie_calls'):.6f}s"
    )
    print(
        "  _all_insert_deltas: "
        f"calls={int(all_insert_calls)}, "
        f"total={all_insert_seconds:.2f}s, "
        f"avg={_profile_average('all_insert_deltas_seconds', 'all_insert_deltas_calls'):.6f}s, "
        f"returned_moves={int(all_insert_returned_moves)}, "
        f"avg_returned_moves={_profile_average_count('all_insert_deltas_returned_moves', 'all_insert_deltas_calls'):.2f}"
    )
    print("  repair operators:")
    for repair_name in (
        "repair_greedy",
        "repair_regret2",
        "repair_priority",
        "repair_risk_aware",
        "repair_drone_first",
    ):
        calls = _PROFILE_STATS.get(f"{repair_name}_calls", 0.0)
        seconds = _PROFILE_STATS.get(f"{repair_name}_seconds", 0.0)
        print(
            f"    {repair_name}: "
            f"calls={int(calls)}, "
            f"total={seconds:.2f}s, "
            f"avg={_profile_average(f'{repair_name}_seconds', f'{repair_name}_calls'):.6f}s"
        )


# =============================
# Data Structures
# =============================

@dataclass
class DroneTask:
    """
    可选兼容类。
    你当前代码中的无人机任务主要用 dict 表示：
    {
        "truck_id": int,
        "drone_id": int,
        "launch_node": int,
        "customer": int,
        "recovery_node": int,
        "period_index": int,
        "launch_time": float,
        "recovery_time": float,
        "cost": float,
        "occupied_segments": [...],
        "evaluation": {...}
    }

    如果后续不想用 dataclass，可以完全不用这个类。
    """
    truck_id: int
    drone_id: int
    launch_node: int
    customer: int
    recovery_node: int
    period_index: Optional[int] = None
    launch_time: Optional[float] = None
    recovery_time: Optional[float] = None
    cost: float = 0.0
    occupied_segments: List[Tuple[int, int]] = field(default_factory=list)
    evaluation: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "truck_id": self.truck_id,
            "drone_id": self.drone_id,
            "launch_node": self.launch_node,
            "customer": self.customer,
            "recovery_node": self.recovery_node,
            "period_index": self.period_index,
            "launch_time": self.launch_time,
            "recovery_time": self.recovery_time,
            "cost": self.cost,
            "occupied_segments": self.occupied_segments,
            "evaluation": self.evaluation,
        }


@dataclass
class Solution:
    """
    适配当前问题的 Solution 包装类。

    内部保存 dict 形式的完整解：

    {
        "truck_routes": {
            truck_id: [depot_start, ..., depot_end]
        },
        "drone_routes": [
            {
                "truck_id": int,
                "drone_id": int,
                "launch_node": int,
                "customer": int,
                "recovery_node": int,
                "period_index": int,
                "launch_time": float,
                "recovery_time": float,
                "cost": float,
                "occupied_segments": [(truck_id, seg_idx), ...],
                "evaluation": {...}
            }
        ],
        "unserved": [...],
        "next_drone_task_id": int,
        "served": set(...),
        "cost": float,
        "feasible": bool,
        "validation_report": {...},
        "full_validation_report": {...},
        "drone_period_usage": {...},
        "segment_usage": {...}
    }
    注意：
    1. 不使用 setdefault；
    2. 不自动补字段；
    3. 不自动把 list 转成 set；
    4. 缺字段或类型错误时直接报错。
    """
    data: Dict[str, Any]

    def deepcopy(self) -> "Solution":
        if not _profile_enabled():
            return Solution(copy.deepcopy(self.data))
        start_time = time.perf_counter()
        try:
            return Solution(copy.deepcopy(self.data))
        finally:
            _profile_count("solution_deepcopy_calls")
            _profile_add(
                "solution_deepcopy_seconds",
                time.perf_counter() - start_time,
            )

    # ========== 成本兼容 ==========
    @property
    def cost(self) -> float:
        return self.data["cost"]

    @cost.setter
    def cost(self, value: float) -> None:
        self.data["cost"] = value

    @property
    def total_obj(self) -> float:
        """
        兼容旧 ALNS 代码中 curr.total_obj / best.total_obj 的写法。
        """
        return self.data["cost"]

    @total_obj.setter
    def total_obj(self, value: float) -> None:
        self.data["cost"] = value

    # ========== 卡车路径 ==========
    @property
    def truck_routes(self) -> Dict[int, List[int]]:
        return self.data["truck_routes"]

    @truck_routes.setter
    def truck_routes(self, value: Dict[int, List[int]]) -> None:
        self.data["truck_routes"] = value

    @property
    def truck_paths(self) -> List[List[int]]:
        """
        兼容旧代码中的 sol.truck_paths。

        旧代码使用 list[list[int]]；
        新代码核心使用 dict[int, list[int]]。

        注意：
        这里只返回按 truck_id 排序后的路径列表。
        如果要修改路径，建议直接修改 sol.truck_routes。
        """
        return [self.data["truck_routes"][truck_id] for truck_id in sorted(self.data["truck_routes"])]

    # ========== 无人机任务 ==========
    @property
    def drone_routes(self) -> List[Dict[str, Any]]:
        return self.data["drone_routes"]

    @drone_routes.setter
    def drone_routes(self, value: List[Dict[str, Any]]) -> None:
        self.data["drone_routes"] = value

    @property
    def drone_tasks(self) -> List[Dict[str, Any]]:
        """
        兼容旧代码中的 sol.drone_tasks。
        """
        return self.data["drone_routes"]

    @drone_tasks.setter
    def drone_tasks(self, value: List[Dict[str, Any]]) -> None:
        self.data["drone_routes"] = value

    # ========== 服务状态 ==========
    @property
    def served(self) -> Set[int]:
        return self.data["served"]

    @served.setter
    def served(self, value: Set[int]) -> None:
        self.data["served"] = value

    @property
    def unserved(self) -> List[int]:
        return self.data["unserved"]

    @unserved.setter
    def unserved(self, value: List[int]) -> None:
        self.data["unserved"] = value

    # ========== 资源占用 ==========
    @property
    def segment_usage(self) -> Dict[Tuple[int, int], int]:
        return self.data["segment_usage"]

    @segment_usage.setter
    def segment_usage(self, value: Dict[Tuple[int, int], int]) -> None:
        self.data["segment_usage"] = value

    @property
    def segment_usage_count(self) -> Dict[Tuple[int, int], int]:
        """
        兼容旧代码字段名。
        """
        return self.data["segment_usage"]

    @segment_usage_count.setter
    def segment_usage_count(self, value: Dict[Tuple[int, int], int]) -> None:
        self.data["segment_usage"] = value

    @property
    def drone_period_usage(self) -> Dict[Tuple[int, int], int]:
        return self.data["drone_period_usage"]

    @drone_period_usage.setter
    def drone_period_usage(self, value: Dict[Tuple[int, int], int]) -> None:
        self.data["drone_period_usage"] = value

    # ========== 可行性 ==========
    @property
    def feasible(self) -> bool:
        return self.data["feasible"]

    @feasible.setter
    def feasible(self, value: bool) -> None:
        self.data["feasible"] = value

    # ========== 检查报告 ==========
    @property
    def validation_report(self) -> Dict[str, Any]:
        return self.data["validation_report"]

    @validation_report.setter
    def validation_report(self, value: Dict[str, Any]) -> None:
        self.data["validation_report"] = value

    @property
    def full_validation_report(self) -> Dict[str, Any]:
        return self.data["full_validation_report"]

    @full_validation_report.setter
    def full_validation_report(self, value: Dict[str, Any]) -> None:
        self.data["full_validation_report"] = value


@dataclass
class OperatorScore:
    """
    ALNS 算子评分结构。

    w: 当前算子选择权重。
    s: 当前统计窗口内累计得分。
    """

    w: float = 1.0
    s: float = 0.0
    selected_count: int = 0
    accepted_count: int = 0
    improved_current_count: int = 0
    improved_best_count: int = 0


class InvalidMoveError(ValueError):
    """Raised when an ALNS operator creates an explicitly rejected move."""


def _resolve_destroy_count(
    candidate_count: int,
    requested_count: int,
    diagnostic_min_destroy_size: int | None,
) -> int:
    """Resolve a destroy size without expanding an operator's legal candidate set."""
    for value, label in (
        (candidate_count, "candidate_count"),
        (requested_count, "requested_count"),
    ):
        if isinstance(value, bool) or not isinstance(value, int):
            raise TypeError(f"{label} must be an int")
    if candidate_count < 0:
        raise ValueError("candidate_count must be non-negative")
    if requested_count < 0:
        raise ValueError("requested_count must be non-negative")
    if candidate_count == 0:
        return 0
    if diagnostic_min_destroy_size is not None:
        if (
            isinstance(diagnostic_min_destroy_size, bool)
            or not isinstance(diagnostic_min_destroy_size, int)
            or diagnostic_min_destroy_size < 1
        ):
            raise ValueError(
                "diagnostic_min_destroy_size must be a positive integer or None"
            )
    remove_count = min(requested_count, candidate_count)
    if diagnostic_min_destroy_size is not None:
        remove_count = max(
            remove_count,
            min(diagnostic_min_destroy_size, candidate_count),
        )
    return remove_count


def canonical_solution_signature(solution: Solution | Dict[str, Any]) -> tuple:
    """Return a physical solution signature that ignores interchangeable drone ids."""
    data = solution.data if isinstance(solution, Solution) else solution
    if not isinstance(data, dict):
        raise TypeError("solution must be a Solution or dict")
    required = {"truck_routes", "drone_routes", "unserved"}
    missing = required - set(data)
    if missing:
        raise ValueError(f"solution missing signature fields: {sorted(missing)}")
    if not isinstance(data["truck_routes"], dict):
        raise TypeError("solution truck_routes must be a dict")
    if not isinstance(data["drone_routes"], list):
        raise TypeError("solution drone_routes must be a list")
    if not isinstance(data["unserved"], (list, set, tuple)):
        raise TypeError("solution unserved must be a list, set, or tuple")
    truck_signature = tuple(
        sorted(
            (int(truck_id), tuple(int(node) for node in route))
            for truck_id, route in data["truck_routes"].items()
        )
    )
    drone_signature_items = []
    for task_index, task in enumerate(data["drone_routes"]):
        if not isinstance(task, dict):
            raise TypeError(f"drone task {task_index} must be a dict")
        required_task = {"truck_id", "launch_node", "customer", "recovery_node"}
        missing_task = required_task - set(task)
        if missing_task:
            raise ValueError(
                f"drone task {task_index} missing signature fields: "
                f"{sorted(missing_task)}"
            )
        drone_signature_items.append(
            (
                int(task["truck_id"]),
                int(task["launch_node"]),
                int(task["customer"]),
                int(task["recovery_node"]),
            )
        )
    drone_signature = tuple(sorted(drone_signature_items))
    unserved_signature = tuple(sorted(int(value) for value in data["unserved"]))
    return truck_signature, drone_signature, unserved_signature


def stable_solution_hash(solution: Solution | Dict[str, Any]) -> str:
    signature = canonical_solution_signature(solution)
    payload = json.dumps(signature, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


class ALNS:
    def __init__(
        self,
        customers,
        distance_matrix,
        truck_time_matrix,
        risk_matrix,
        drone_distance_matrix,
        drone_time_matrix,
        periods,
        period_length,
        truck_capacity_by_truck,
        drone_capacity_by_drone,
        drone_endurance_by_drone,
        drone_ids_by_truck,
        depot_start,
        depot_end,
        replenishment_node=999,
        cost_weights=None,
        unserved_penalty=10000,
        truck_insert_tw_radius=0,
        random_seed=None,
        diagnostic_min_destroy_size: int | None = None,
        forced_destroy_operator: str | None = None,
        forced_repair_operator: str | None = None,
        operator_set: str = "full",
        acceptance_rule: str = "sa",
        enable_search_trace: bool = False,
        trace_output_dir: str | Path | None = None,
        enable_joint_truck_drone_repair: bool = False,
        joint_repair_max_customers: int = 4,
        joint_repair_beam_width: int = 5,
    ):
        """
        适配当前应急物流问题的 ALNS 初始化函数。

        当前问题特点：
        1. 多卡车-多无人机；
        2. 静态客户和动态客户；
        3. 999 是补给节点；当前卡车规则为补其后紧邻客户，动态客户无人机服务将从 999 装货起飞；
        4. 客户有基础需求 basic_demand 和紧急需求 emergency_demand；
        5. 卡车道路风险随周期变化；
        6. 无人机任务不能跨周期；
        7. 同一架无人机同一周期最多一次；
        8. 卡车路段无人机占用数不能超过该车携带无人机数；
        9. 无人机回收等待会重新传播卡车后续时间线。
        """

        # ========== 基础数据 ==========
        self.customers = customers

        self.distance_matrix = distance_matrix
        self.truck_time_matrix = truck_time_matrix
        self.risk_matrix = risk_matrix

        self.drone_distance_matrix = drone_distance_matrix
        self.drone_time_matrix = drone_time_matrix

        self.periods = periods
        self.period_length = period_length

        # ========== 容量与资源 ==========
        self.truck_capacity_by_truck = truck_capacity_by_truck
        self.drone_capacity_by_drone = drone_capacity_by_drone
        self.drone_endurance_by_drone = drone_endurance_by_drone
        self.drone_ids_by_truck = drone_ids_by_truck

        # ========== 节点 ==========
        self.depot_start = depot_start
        self.depot_end = depot_end
        self.replenishment_node = replenishment_node
        if isinstance(truck_insert_tw_radius, bool) or not isinstance(truck_insert_tw_radius, int):
            raise TypeError("truck_insert_tw_radius must be an int")
        if truck_insert_tw_radius < 0:
            raise ValueError("truck_insert_tw_radius must be non-negative")
        self.truck_insert_tw_radius = truck_insert_tw_radius

        # ========== 成本参数 ==========
        # 默认权重必须与 route_evaluator.calculate_route_cost 支持的字段一致。
        self.cost_weights = cost_weights or {
            "priority_cost": 1.0,
            "unserved_penalty_cost": 1.0,
            "road_risk_cost": 1.0,
            "delay_penalty": 1.0,
        }

        self.unserved_penalty = unserved_penalty

        # ========== 随机数 ==========
        self.rnd = random.Random(random_seed)
        if diagnostic_min_destroy_size is not None and (
            isinstance(diagnostic_min_destroy_size, bool)
            or not isinstance(diagnostic_min_destroy_size, int)
            or diagnostic_min_destroy_size < 1
        ):
            raise ValueError(
                "diagnostic_min_destroy_size must be a positive integer or None"
            )
        for value, label in (
            (forced_destroy_operator, "forced_destroy_operator"),
            (forced_repair_operator, "forced_repair_operator"),
        ):
            if value is not None and (not isinstance(value, str) or value == ""):
                raise ValueError(f"{label} must be a non-empty string or None")
        supported_operator_sets = {
            "basic",
            "full",
            "full_no_risk_ops",
            "full_no_drone_specialized_ops",
        }
        if operator_set not in supported_operator_sets:
            raise ValueError(
                "operator_set must be one of "
                f"{sorted(supported_operator_sets)}, got {operator_set!r}"
            )
        if acceptance_rule not in {"sa", "only_improve"}:
            raise ValueError(
                f"acceptance_rule must be sa or only_improve, got {acceptance_rule!r}"
            )
        if not isinstance(enable_search_trace, bool):
            raise TypeError("enable_search_trace must be bool")
        if trace_output_dir is not None and not isinstance(trace_output_dir, (str, Path)):
            raise TypeError("trace_output_dir must be a path string, Path, or None")
        if trace_output_dir is not None and not enable_search_trace:
            raise ValueError(
                "trace_output_dir requires enable_search_trace=True"
            )
        if not isinstance(enable_joint_truck_drone_repair, bool):
            raise TypeError("enable_joint_truck_drone_repair must be bool")
        if (
            isinstance(joint_repair_max_customers, bool)
            or not isinstance(joint_repair_max_customers, int)
        ):
            raise TypeError("joint_repair_max_customers must be an int")
        if joint_repair_max_customers < 2:
            raise ValueError("joint_repair_max_customers must be at least 2")
        if joint_repair_max_customers > 4:
            raise ValueError("joint_repair_max_customers must be at most 4")
        if (
            isinstance(joint_repair_beam_width, bool)
            or not isinstance(joint_repair_beam_width, int)
        ):
            raise TypeError("joint_repair_beam_width must be an int")
        if joint_repair_beam_width < 1:
            raise ValueError("joint_repair_beam_width must be positive")
        self.diagnostic_min_destroy_size = diagnostic_min_destroy_size
        self.forced_destroy_operator = forced_destroy_operator
        self.forced_repair_operator = forced_repair_operator
        self.operator_set = operator_set
        self.acceptance_rule = acceptance_rule
        self.enable_search_trace = enable_search_trace
        self.trace_output_dir = (
            None if trace_output_dir is None else Path(trace_output_dir)
        )
        self.trace_run_label: str | None = None
        self.last_search_trace: List[Dict[str, Any]] = []
        self.last_search_diagnostics: Dict[str, Any] = {}
        self.last_operator_pair_stats: Dict[Tuple[str, str], Dict[str, Any]] = {}
        self.allow_drone_insertions = True
        self.phase_candidate_validator = None
        self.rejected_phase_candidate_count = 0
        self.last_rejected_phase_candidate_validation = None
        self.rejected_destroy_move_count = 0
        self.enable_joint_truck_drone_repair = enable_joint_truck_drone_repair
        self.joint_repair_max_customers = joint_repair_max_customers
        self.joint_repair_beam_width = joint_repair_beam_width
        self.joint_repair_stats: Dict[str, Any] = self._new_joint_repair_stats()

        # ========== 破坏算子注册 ==========
        if self.operator_set == "basic":
            if self.enable_joint_truck_drone_repair:
                raise ValueError(
                    "enable_joint_truck_drone_repair requires a full operator profile"
                )
            self.remove_ops = [
                ("random", self._remove_random),
                ("related", self._remove_related),
            ]
            self.repair_ops = [
                ("greedy", self._repair_greedy),
                ("regret2", self._repair_regret2),
            ]
        elif self.operator_set in {
            "full",
            "full_no_risk_ops",
            "full_no_drone_specialized_ops",
        }:
            self.remove_ops = [
                ("random", self._remove_random),
                ("related", self._remove_related),
                #("time_window", self._remove_time_window),
                ("risk", self._remove_risk),
                ("drone_task", self._remove_drone_task),
            ]
            self.repair_ops = [
                ("greedy", self._repair_greedy),
                ("regret2", self._repair_regret2),
                ("priority", self._repair_priority),
                ("risk_aware", self._repair_risk_aware),
                ("drone_first", self._repair_drone_first),
            ]
            if self.operator_set == "full_no_risk_ops":
                self.remove_ops = [
                    item for item in self.remove_ops if item[0] != "risk"
                ]
                self.repair_ops = [
                    item for item in self.repair_ops if item[0] != "risk_aware"
                ]
            elif self.operator_set == "full_no_drone_specialized_ops":
                self.remove_ops = [
                    item for item in self.remove_ops if item[0] != "drone_task"
                ]
                self.repair_ops = [
                    item for item in self.repair_ops if item[0] != "drone_first"
                ]
            if self.enable_joint_truck_drone_repair:
                self.repair_ops.append(
                    ("joint_truck_drone", self._repair_joint_truck_drone)
                )
        else:
            raise ValueError(f"unknown operator_set: {self.operator_set}")
        expected_operator_names = {
            "basic": {
                "destroy": ["random", "related"],
                "repair": ["greedy", "regret2"],
            },
            "full": {
                "destroy": ["random", "related", "risk", "drone_task"],
                "repair": ["greedy", "regret2", "priority", "risk_aware", "drone_first"],
            },
            "full_no_risk_ops": {
                "destroy": ["random", "related", "drone_task"],
                "repair": ["greedy", "regret2", "priority", "drone_first"],
            },
            "full_no_drone_specialized_ops": {
                "destroy": ["random", "related", "risk"],
                "repair": ["greedy", "regret2", "priority", "risk_aware"],
            },
        }[self.operator_set]
        if self.enable_joint_truck_drone_repair:
            expected_operator_names = {
                "destroy": list(expected_operator_names["destroy"]),
                "repair": expected_operator_names["repair"] + ["joint_truck_drone"],
            }
        actual_operator_names = {
            "destroy": [name for name, _ in self.remove_ops],
            "repair": [name for name, _ in self.repair_ops],
        }
        if actual_operator_names != expected_operator_names:
            raise RuntimeError(
                "operator registry does not match the selected operator_set: "
                f"expected={expected_operator_names}, actual={actual_operator_names}"
            )
        self.remove_scores: Dict[str, OperatorScore] = {
            name: OperatorScore(1.0, 0.0)
            for name, _ in self.remove_ops
        }

        self.repair_scores: Dict[str, OperatorScore] = {
            name: OperatorScore(1.0, 0.0)
            for name, _ in self.repair_ops
        }
        self.best_iteration = 0

        # Validate forced names immediately after the real registries exist.
        if self.forced_destroy_operator is not None:
            self._operator_from_registry(
                self.remove_ops,
                self.forced_destroy_operator,
                "destroy",
            )
        if self.forced_repair_operator is not None:
            self._operator_from_registry(
                self.repair_ops,
                self.forced_repair_operator,
                "repair",
            )

    @staticmethod
    def _operator_from_registry(
        registry: List[Tuple[str, Callable]],
        requested_name: str,
        operator_type: str,
    ) -> Tuple[str, Callable]:
        if not isinstance(registry, list) or not registry:
            raise ValueError(f"{operator_type} operator registry must not be empty")
        matches = [(name, fn) for name, fn in registry if name == requested_name]
        if len(matches) == 1:
            return matches[0]
        if len(matches) > 1:
            raise ValueError(
                f"{operator_type} operator registry contains duplicate name: "
                f"{requested_name}"
            )
        available = sorted(name for name, _ in registry)
        raise ValueError(
            f"unknown {operator_type} operator: {requested_name}; "
            f"available operators: {available}"
        )

    def _select_destroy_for_iteration(self) -> Tuple[str, Callable]:
        if self.forced_destroy_operator is None:
            return self._roulette(self.remove_ops, self.remove_scores)
        return self._operator_from_registry(
            self.remove_ops,
            self.forced_destroy_operator,
            "destroy",
        )

    def _select_repair_for_iteration(self) -> Tuple[str, Callable]:
        if self.forced_repair_operator is None:
            return self._roulette(self.repair_ops, self.repair_scores)
        return self._operator_from_registry(
            self.repair_ops,
            self.forced_repair_operator,
            "repair",
        )

    def registered_operator_names(self) -> Dict[str, List[str]]:
        return {
            "destroy": [name for name, _ in self.remove_ops],
            "repair": [name for name, _ in self.repair_ops],
        }

    @staticmethod
    def _new_joint_repair_stats() -> Dict[str, Any]:
        return {
            "calls": 0,
            "selected_customer_count": 0,
            "generated_candidate_count": 0,
            "feasible_candidate_count": 0,
            "beam_level_count": 0,
            "accepted_count": 0,
            "global_best_update_count": 0,
            "runtime": 0.0,
            "truck_customer_count": 0,
            "drone_task_count": 0,
            "unserved_count": 0,
            "total_obj": None,
        }

    def print_registered_operators(self) -> None:
        names = self.registered_operator_names()
        print("Destroy operators:")
        for name in names["destroy"]:
            print(f"- {name}")
        print("\nRepair operators:")
        for name in names["repair"]:
            print(f"- {name}")

    @staticmethod
    def _phase_candidate_rejection_summary(
            validation_result: Dict[str, Any],
    ) -> Dict[str, Any]:
        summary = {"valid": validation_result["valid"]}
        if "violations" in validation_result:
            if not isinstance(validation_result["violations"], list):
                raise TypeError("phase_candidate_validator violations must be a list")
            summary["violations"] = list(validation_result["violations"])
        if "truck_routes" in validation_result:
            if not isinstance(validation_result["truck_routes"], dict):
                raise TypeError("phase_candidate_validator truck_routes must be a dict")
            summary["truck_routes"] = copy.deepcopy(validation_result["truck_routes"])
        return summary

    @staticmethod
    def _served_mode_sets(solution: Solution) -> Tuple[Set[int], Set[int]]:
        truck_customers = {
            int(node)
            for route in solution.data["truck_routes"].values()
            for node in route
        }
        drone_customers = {
            int(task["customer"])
            for task in solution.data["drone_routes"]
        }
        return truck_customers, drone_customers

    def _record_search_iteration(self, row: Dict[str, Any]) -> None:
        if not self.enable_search_trace:
            return
        required = {
            "iteration",
            "destroy_operator",
            "repair_operator",
            "requested_remove_count",
            "actual_remove_count",
            "removed_customers",
            "removed_truck_customers",
            "removed_drone_customers",
            "candidate_feasible",
            "candidate_obj",
            "current_obj_before",
            "current_obj_after",
            "best_obj_before",
            "best_obj_after",
            "candidate_accepted",
            "improved_current",
            "new_global_best",
            "candidate_drone_task_count",
            "candidate_solution_hash",
            "rejection_reason",
        }
        missing = required - set(row)
        if missing:
            raise ValueError(f"search trace row missing fields: {sorted(missing)}")
        self.last_search_trace.append(copy.deepcopy(row))
        pair = (row["destroy_operator"], row["repair_operator"])
        if pair not in self.last_operator_pair_stats:
            self.last_operator_pair_stats[pair] = {
                "destroy_operator": pair[0],
                "repair_operator": pair[1],
                "calls": 0,
                "feasible_candidates": 0,
                "accepted_candidates": 0,
                "improved_current_count": 0,
                "global_best_update_count": 0,
                "drone_task_added_count": 0,
                "drone_task_removed_count": 0,
                "actual_remove_count_total": 0,
                "maximum_actual_remove_count": 0,
            }
        stats = self.last_operator_pair_stats[pair]
        stats["calls"] += 1
        actual_remove_count = int(row["actual_remove_count"] or 0)
        stats["actual_remove_count_total"] += actual_remove_count
        stats["maximum_actual_remove_count"] = max(
            stats["maximum_actual_remove_count"],
            actual_remove_count,
        )
        stats["feasible_candidates"] += int(row["candidate_feasible"] is True)
        stats["accepted_candidates"] += int(row["candidate_accepted"] is True)
        stats["improved_current_count"] += int(row["improved_current"] is True)
        stats["global_best_update_count"] += int(row["new_global_best"] is True)
        stats["drone_task_added_count"] += int(row.get("drone_task_added_count", 0))
        stats["drone_task_removed_count"] += int(
            row.get("drone_task_removed_count", 0)
        )

    def _write_search_trace_if_requested(self) -> None:
        if not self.enable_search_trace or self.trace_output_dir is None:
            return
        if self.trace_run_label is None or not isinstance(self.trace_run_label, str):
            raise ValueError(
                "trace_run_label must be set to a non-empty string when "
                "trace_output_dir is configured"
            )
        if self.trace_run_label == "":
            raise ValueError("trace_run_label must not be empty")
        path = self.trace_output_dir / f"{self.trace_run_label}.jsonl"
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="utf-8", newline="\n") as stream:
            for row in self.last_search_trace:
                stream.write(
                    json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n"
                )

    def solve(
            self,
            init: Solution,
            iters: int,
            x_remove: float | None = 0.15,
            temp_init: float = 1.0,
            temp_final: float = 0.01,
            normalize_every: int = 100,
            stage_breaks: Tuple[float, float] = (0.3, 0.7),
            verbose: bool = True,
    ) -> Solution:
        """
        ALNS 主循环。
        """
        # ---------- Step 1: 初始化当前解和历史最优解 ----------
        if (
            _profile_enabled()
            and os.environ.get("ALNS_PROFILE_SESSION_ACTIVE") != "1"
        ):
            _profile_reset()

        current = init.deepcopy()
        best = init.deepcopy()

        self.last_search_trace = []
        self.last_operator_pair_stats = {}
        self.last_search_diagnostics = {}
        self.joint_repair_stats = self._new_joint_repair_stats()

        self._reject_replenishment_nodes(
            current,
            scope="solve_initial_current",
        )
        self._reject_replenishment_nodes(
            best,
            scope="solve_initial_best",
        )

        # 初始解也先统一重建，确保 cost、feasible、validation_report 是最新的
        if not current.data.get("feasible", True):
            raise ValueError("initial solution passed to solve() is infeasible")
        if not math.isfinite(current.cost):
            raise ValueError(
                "initial solution passed to solve() must already have a finite cost"
            )
        if not math.isfinite(best.cost):
            raise ValueError(
                "initial best solution passed to solve() must already have a finite cost"
            )
        best.data["best_iteration"] = 0
        self.best_iteration = 0
        initial_obj = float(best.cost)
        initial_solution_hash = stable_solution_hash(best)
        initial_drone_task_count = len(best.data["drone_routes"])
        max_drone_task_count_seen = initial_drone_task_count
        unique_solution_hashes = {initial_solution_hash}
        feasible_candidate_count = 0
        accepted_candidate_count = 0
        improvement_count = 0
        first_improvement_iteration = None
        last_improvement_iteration = None
        best_phase_candidate_valid = True#标记当前 best 是否通过阶段候选验证（如果有验证器）。
        if self.phase_candidate_validator is not None:
            initial_validation = self.phase_candidate_validator(best)#外部阶段候选验证器（phase_candidate_validator）
            if not isinstance(initial_validation, dict):
                raise TypeError("phase_candidate_validator must return a dict")
            if "valid" not in initial_validation:
                raise ValueError("phase_candidate_validator result missing valid")
            if not isinstance(initial_validation["valid"], bool):
                raise TypeError("phase_candidate_validator valid must be bool")
            if not initial_validation["valid"]:
                self.rejected_phase_candidate_count += 1
                self.last_rejected_phase_candidate_validation = (
                    self._phase_candidate_rejection_summary(
                        initial_validation
                    )
                )
                raise ValueError(
                    "initial solution does not pass phase_candidate_validator: "
                    f"{self.last_rejected_phase_candidate_validation}"
                )

        T0 = temp_init
        Tf = temp_final

        for it in range(1, iters + 1):

            # ---------- Step 2: 当前迭代进度与温度 ----------
            frac = it / max(1, iters)
            temperature = self._exp_cooling(T0, Tf, frac)

            # ---------- Step 3: 设置当前移除比例 ----------
            if x_remove is None:
                if frac < stage_breaks[0]:
                    remove_ratio = self.rnd.uniform(0.15, 0.20)
                elif frac < stage_breaks[1]:
                    remove_ratio = self.rnd.uniform(0.10, 0.15)
                else:
                    remove_ratio = self.rnd.uniform(0.05, 0.10)
            else:
                remove_ratio = x_remove

            # ---------- Step 4: 轮盘赌选择破坏算子和修复算子 ----------
            remove_name, remove_fn = self._select_destroy_for_iteration()
            repair_name, repair_fn = self._select_repair_for_iteration()
            current_cost_before = float(current.cost)
            best_cost_before = float(best.cost)
            current_drone_count_before = len(current.data["drone_routes"])
            truck_customers_before, drone_customers_before = self._served_mode_sets(
                current
            )
            trace_row = {
                "iteration": it,
                "destroy_operator": remove_name,
                "repair_operator": repair_name,
                "requested_remove_count": None,
                "actual_remove_count": 0,
                "removed_customers": [],
                "removed_truck_customers": [],
                "removed_drone_customers": [],
                "candidate_feasible": False,
                "candidate_obj": None,
                "current_obj_before": current_cost_before,
                "current_obj_after": current_cost_before,
                "best_obj_before": best_cost_before,
                "best_obj_after": best_cost_before,
                "candidate_accepted": False,
                "improved_current": False,
                "new_global_best": False,
                "candidate_drone_task_count": None,
                "candidate_solution_hash": None,
                "drone_task_added_count": 0,
                "drone_task_removed_count": 0,
                "rejection_reason": None,
            }

            # ---------- Step 5: 执行破坏算子 ----------
            self.remove_scores[remove_name].selected_count += 1
            self.repair_scores[repair_name].selected_count += 1
            try:
                destroyed, removed_set, context = remove_fn(current, remove_ratio)
            except InvalidMoveError:
                self.rejected_destroy_move_count += 1
                trace_row["rejection_reason"] = "destroy_invalid_move"
                self._record_search_iteration(trace_row)
                continue

            if not isinstance(context, dict):
                raise TypeError("destroy operator context must be a dict")
            requested_remove_count = context.get("requested_remove_count", len(removed_set))
            if (
                isinstance(requested_remove_count, bool)
                or not isinstance(requested_remove_count, int)
                or requested_remove_count < 0
            ):
                raise ValueError(
                    "destroy context requested_remove_count must be a non-negative int"
                )
            removed_sorted = sorted(int(value) for value in removed_set)
            trace_row.update(
                {
                    "requested_remove_count": requested_remove_count,
                    "actual_remove_count": len(removed_sorted),
                    "removed_customers": removed_sorted,
                    "removed_truck_customers": sorted(
                        value for value in removed_sorted if value in truck_customers_before
                    ),
                    "removed_drone_customers": sorted(
                        value for value in removed_sorted if value in drone_customers_before
                    ),
                }
            )

            # 如果本轮没有移除任何客户，则跳过本轮
            if not removed_set:
                trace_row["rejection_reason"] = "no_customers_removed"
                self._record_search_iteration(trace_row)
                continue

            # ---------- Step 6: 执行修复算子 ----------
            try:
                candidate = repair_fn(destroyed, removed_set, context)
            except Exception as exc:
                diagnostics = self._drone_task_diagnostics(
                    destroyed,
                    scope=(
                        f"solve iteration {it}, remove={remove_name}, "
                        f"repair={repair_name}"
                    ),
                )
                raise RuntimeError(
                    "repair operator failed after destroy; "
                    f"iteration={it}, remove={remove_name}, repair={repair_name}, "
                    f"removed_set={sorted(removed_set)}, "
                    f"destroy_context={context}, "
                    f"drone_task_diagnostics={diagnostics}"
                ) from exc

            # 如果修复失败，跳过本轮
            if candidate is None:
                trace_row["rejection_reason"] = "repair_returned_none"
                self._record_search_iteration(trace_row)
                continue

            try:
                self._reject_replenishment_nodes(
                    candidate,
                    scope="repair_candidate",
                )
            except InvalidMoveError:
                if self.phase_candidate_validator is not None:
                    self.rejected_phase_candidate_count += 1
                else:
                    self.rejected_destroy_move_count += 1
                trace_row["rejection_reason"] = "infeasible"
                self._record_search_iteration(trace_row)
                continue

            # ---------- 已删除：Step 7: 重建候选解 ----------
            if not math.isfinite(candidate.cost):
                raise ValueError(
                    "repair operator returned a candidate without a finite cost"
                )

            # ---------- Step 8: 如果候选解不可行，则不接受 ----------
            if not candidate.data.get("feasible", True):
                trace_row["candidate_obj"] = float(candidate.cost)
                trace_row["candidate_drone_task_count"] = len(
                    candidate.data["drone_routes"]
                )
                trace_row["candidate_solution_hash"] = stable_solution_hash(candidate)
                trace_row["rejection_reason"] = "infeasible"
                self._record_search_iteration(trace_row)
                continue
            if self.phase_candidate_validator is not None:
                validation_result = self.phase_candidate_validator(candidate)
                if not isinstance(validation_result, dict):
                    raise TypeError("phase_candidate_validator must return a dict")
                if "valid" not in validation_result:
                    raise ValueError("phase_candidate_validator result missing valid")
                if not isinstance(validation_result["valid"], bool):
                    raise TypeError("phase_candidate_validator valid must be bool")
                if not validation_result["valid"]:
                    self.rejected_phase_candidate_count += 1
                    self.last_rejected_phase_candidate_validation = (
                        self._phase_candidate_rejection_summary(
                            validation_result
                        )
                    )
                    trace_row["candidate_obj"] = float(candidate.cost)
                    trace_row["candidate_drone_task_count"] = len(
                        candidate.data["drone_routes"]
                    )
                    trace_row["candidate_solution_hash"] = stable_solution_hash(
                        candidate
                    )
                    trace_row["rejection_reason"] = "infeasible"
                    self._record_search_iteration(trace_row)
                    continue

            # ---------- Step 9: 成本比较 ----------
            current_cost = current.cost
            candidate_cost = candidate.cost
            best_cost = best.cost if best_phase_candidate_valid else math.inf
            '''if not math.isfinite(current_cost):
                raise ValueError("current solution cost must be finite")
            if not math.isfinite(candidate_cost):
                raise ValueError("candidate solution cost must be finite")
            if best_phase_candidate_valid and not math.isfinite(best_cost):
                raise ValueError("best solution cost must be finite")'''

            improved_best = bool(candidate_cost < best_cost - 1e-9)
            improved_current = bool(candidate_cost < current_cost - 1e-9)
            candidate_hash = stable_solution_hash(candidate)
            candidate_drone_count = len(candidate.data["drone_routes"])
            feasible_candidate_count += 1
            unique_solution_hashes.add(candidate_hash)
            max_drone_task_count_seen = max(
                max_drone_task_count_seen,
                candidate_drone_count,
            )
            trace_row.update(
                {
                    "candidate_feasible": True,
                    "candidate_obj": float(candidate_cost),
                    "candidate_drone_task_count": candidate_drone_count,
                    "candidate_solution_hash": candidate_hash,
                    "improved_current": improved_current,
                    "new_global_best": improved_best,
                    "best_obj_after": (
                        float(candidate_cost) if improved_best else best_cost_before
                    ),
                    "drone_task_added_count": max(
                        0, candidate_drone_count - current_drone_count_before
                    ),
                    "drone_task_removed_count": max(
                        0, current_drone_count_before - candidate_drone_count
                    ),
                }
            )
            if improved_best:
                best = candidate.deepcopy()
                best.data["best_iteration"] = it
                self.best_iteration = it
                best_phase_candidate_valid = True#因为 candidate 进入此分支前已经通过了阶段验证器（在上一轮可行性检查中执行），所以新的最优解必然是合法的，因此将 best_phase_candidate_valid 设为 True。
                improvement_count += 1
                if first_improvement_iteration is None:
                    first_improvement_iteration = it
                last_improvement_iteration = it

            accepted = bool(
                self._accept(current_cost, candidate_cost, temperature)
            )

            # ---------- Step 10: 接受准则与算子得分更新 ----------
            if accepted:
                accepted_candidate_count += 1
                self.remove_scores[remove_name].accepted_count += 1
                self.repair_scores[repair_name].accepted_count += 1
                if repair_name == "joint_truck_drone":
                    self.joint_repair_stats["accepted_count"] += 1
                current = candidate.deepcopy()

                # 找到新的全局最优解
                if improved_best:
                    if repair_name == "joint_truck_drone":
                        self.joint_repair_stats["global_best_update_count"] += 1
                    self.remove_scores[remove_name].improved_current_count += 1
                    self.repair_scores[repair_name].improved_current_count += 1
                    self.remove_scores[remove_name].improved_best_count += 1
                    self.repair_scores[repair_name].improved_best_count += 1

                    self._bump_score(self.remove_scores[remove_name],1.2)
                    self._bump_score(self.repair_scores[repair_name],1.2)

                # 优于当前解，但不是全局最优
                elif improved_current:
                    self.remove_scores[remove_name].improved_current_count += 1
                    self.repair_scores[repair_name].improved_current_count += 1
                    self._bump_score(self.remove_scores[remove_name],1.0)
                    self._bump_score(self.repair_scores[repair_name],1.0)

                # 较差解被模拟退火接受
                else:
                    self._bump_score(self.remove_scores[remove_name],0.8)
                    self._bump_score(self.repair_scores[repair_name],0.8)

            trace_row["candidate_accepted"] = accepted
            trace_row["current_obj_after"] = float(current.cost)
            if not accepted:
                trace_row["rejection_reason"] = "not_accepted_by_criterion"
            self._record_search_iteration(trace_row)

            # ---------- Step 11: 周期性归一化算子权重 ----------
            if normalize_every is not None and normalize_every > 0:
                if it % normalize_every == 0:
                    self._normalize_scores(self.remove_scores)
                    self._normalize_scores(self.repair_scores)

            # ---------- Step 12: 输出迭代信息 ----------
            if verbose:
                if it == 1 or (
                        normalize_every is not None
                        and normalize_every > 0
                        and it % normalize_every == 0
                ):
                    print(
                        f"[ALNS] iter={it}, "
                        f"current={current.cost:.4f}, "
                        f"best={best.cost:.4f}, "
                        f"remove={remove_name}, "
                        f"repair={repair_name}, "
                        f"T={temperature:.6f}"
                    )
        final_best_hash = stable_solution_hash(best)
        self.last_search_diagnostics = {
            "iteration_limit": int(iters),
            "initial_obj": initial_obj,
            "final_best_obj": float(best.cost),
            "initial_solution_hash": initial_solution_hash,
            "final_best_solution_hash": final_best_hash,
            "initial_drone_task_count": initial_drone_task_count,
            "final_drone_task_count": len(best.data["drone_routes"]),
            "max_drone_task_count_seen": max_drone_task_count_seen,
            "unique_solution_count": len(unique_solution_hashes),
            "improvement_count": improvement_count,
            "accepted_candidate_count": accepted_candidate_count,
            "feasible_candidate_count": feasible_candidate_count,
            "first_improvement_iteration": first_improvement_iteration,
            "last_improvement_iteration": last_improvement_iteration,
            "joint_repair_stats": copy.deepcopy(self.joint_repair_stats),
        }
        self._write_search_trace_if_requested()
        return best

    def _roulette(
        self,
        registry: List[Tuple[str, Callable]],#接受一个注册表（算子名称和可调用对象的元组列表
        scores: Dict[str, OperatorScore],
    ):
        """
        根据算子权重进行轮盘赌选择。
        当前版本不做权重兜底：注册表为空、缺少分数、权重非法时直接报错。
        """
        if not isinstance(registry, list):
            raise TypeError("registry must be a list of (name, function) pairs")
        if len(registry) == 0:
            raise ValueError("operator registry must not be empty")
        if not isinstance(scores, dict):
            raise TypeError("scores must be a dict")

        names = []#储存算子
        functions = []#储存对应函数
        for index, item in enumerate(registry):
            if not isinstance(item, tuple) or len(item) != 2:
                raise TypeError(f"registry item {index} must be a (name, function) tuple")
            name, fn = item
            if not isinstance(name, str) or name == "":#检查名称是否为非空字符串
                raise ValueError(f"registry item {index} has invalid operator name: {name}")
            if not callable(fn):#检查函数是否可调用
                raise TypeError(f"operator {name} is not callable")
            names.append(name)
            functions.append(fn)

        if len(set(names)) != len(names):#通过集合去重检查名称是否重复，若有重复则抛出异常。
            raise ValueError(f"operator registry contains duplicate names: {names}")

        score_names = set(scores)
        registry_names = set(names)
        missing_scores = registry_names - score_names
        if missing_scores:
            raise ValueError(f"scores missing operators: {sorted(missing_scores)}")
        extra_scores = score_names - registry_names
        if extra_scores:
            raise ValueError(f"scores contains unregistered operators: {sorted(extra_scores)}")

        weights = []
        for name in names:#遍历每个算子名称，从 scores 中取出对应的 OperatorScore 对象
            score = scores[name]
            #验证对象类型，检查权重 score.w 是否为有限正数（非无穷、非 NaN、>0）
            if not isinstance(score, OperatorScore):
                raise TypeError(f"scores[{name!r}] must be an OperatorScore")
            if not math.isfinite(score.w):
                raise ValueError(f"operator {name} has non-finite weight: {score.w}")
            if score.w <= 0:
                raise ValueError(f"operator {name} weight must be positive, got {score.w}")
            weights.append(score.w)

        total = sum(weights)
        if not math.isfinite(total) or total <= 0:
            raise ValueError(f"operator weight total must be positive and finite, got {total}")

        threshold = self.rnd.random() * total#生成一个 [0, total) 区间内的随机浮点数作为选择阈值
        cumulative = 0.0
        for name, fn, weight in zip(names, functions, weights):
            cumulative += weight
            if threshold < cumulative:
                return name, fn

        raise RuntimeError(
            f"roulette selection failed: threshold={threshold}, total={total}, weights={weights}"
        )

    def _bump_score(self, sc: OperatorScore, amount: float) -> None:
        """给被接受解对应的算子增加窗口得分和选择权重。"""
        if not isinstance(sc, OperatorScore):
            #检查 sc 是否为 OperatorScore 类型，若不是则抛出 TypeError，确保后续操作安全。
            raise TypeError("sc must be an OperatorScore")
        if not math.isfinite(sc.s):
            raise ValueError(f"operator score s must be finite, got {sc.s}")
        if not math.isfinite(sc.w) or sc.w <= 0:
            raise ValueError(f"operator weight w must be positive and finite, got {sc.w}")
        if not math.isfinite(amount) or amount <= 0:
            raise ValueError(f"score bump amount must be positive and finite, got {amount}")

        sc.s += amount
        sc.w += amount * 0.1

    def _normalize_scores(self, table: Dict[str, OperatorScore]) -> None:
        """
        按当前统计窗口得分归一化算子权重。
        如果本窗口没有任何正得分，则保持原权重，只清空窗口分数。
        这是“无得分信号”的显式处理，不把权重重置成统一值。
        """
        if not isinstance(table, dict):
            raise TypeError("score table must be a dict")
        if len(table) == 0:
            raise ValueError("score table must not be empty")

        for name, score in table.items():#遍历每个算子
            if not isinstance(name, str) or name == "":
                raise ValueError(f"score table contains invalid operator name: {name}")
            if not isinstance(score, OperatorScore):
                raise TypeError(f"score table value for {name!r} must be an OperatorScore")
            if not math.isfinite(score.w) or score.w <= 0:
                raise ValueError(f"operator {name} weight must be positive and finite, got {score.w}")
            if not math.isfinite(score.s) or score.s < 0:
                raise ValueError(f"operator {name} score must be non-negative and finite, got {score.s}")

        score_sum = sum(score.s for score in table.values())
        #如果总和为 0，意味着本窗口没有任何算子获得成功（即没有产生被接受的解）。此时只将每个算子的得分清零，保持权重不变，然后返回。
        if score_sum == 0:
            for score in table.values():
                score.s = 0.0
            return
        #获取算子个数，并定义权重下界为 0.2。
        operator_count = len(table)
        min_weight = 0.2
        for score in table.values():
            probability_mass = score.s / score_sum
            score.w = max(min_weight, probability_mass * operator_count)
            score.s = 0.0

    def _exp_cooling(self, T0: float, Tf: float, frac: float) -> float:
        """指数降温函数。"""
        if not math.isfinite(T0) or T0 <= 0:
            raise ValueError(f"T0 must be positive and finite, got {T0}")
        if not math.isfinite(Tf) or Tf <= 0:
            raise ValueError(f"Tf must be positive and finite, got {Tf}")
        if Tf > T0:
            raise ValueError(f"Tf must not be greater than T0 for cooling: T0={T0}, Tf={Tf}")
        if not math.isfinite(frac) or frac < 0 or frac > 1:
            raise ValueError(f"frac must be in [0, 1], got {frac}")

        return T0 * (Tf / T0) ** frac

    def _accept(self, f_curr: float, f_cand: float, T: float) -> bool:
        """Accept a candidate using the configured acceptance rule."""
        if not math.isfinite(f_curr):
            raise ValueError(f"f_curr must be finite, got {f_curr}")
        if not math.isfinite(f_cand):
            raise ValueError(f"f_cand must be finite, got {f_cand}")
        if self.acceptance_rule == "only_improve":
            return f_cand < f_curr - 1e-9
        if self.acceptance_rule != "sa":
            raise ValueError(f"unknown acceptance_rule: {self.acceptance_rule}")
        if not math.isfinite(T) or T <= 0:
            raise ValueError(f"T must be positive and finite, got {T}")

        if f_cand < f_curr:
            return True

        delta = f_cand - f_curr
        probability = math.exp(-delta / T)
        return self.rnd.random() < probability
    # -------------------------
    # Removal helper functions
    # -------------------------
    def _collect_nonkey_customers(self, sol: Solution) -> List[int]:
        """
        收集可以被破坏算子移除的普通客户。
        参考原版 ALNS 的思想：无人机发射点和回收点属于关键节点，
        不能在普通客户删除中直接移除，否则会破坏无人机任务的同步结构。
        """
        key_nodes = self._key_nodes(sol)
        all_customers = self._customers_in_solution(sol)
        locked_customer_ids = self._phase_locked_customer_ids(sol)
        future_dynamic_customer_ids = self._phase_future_dynamic_customer_ids(sol)
        excluded_nodes = {
            self.depot_start,
            self.depot_end,
            self.replenishment_node,
        }
        return [
            customer_id
            for customer_id in all_customers
            if (
                customer_id not in key_nodes
                and customer_id not in excluded_nodes
                and customer_id not in locked_customer_ids
                and customer_id not in future_dynamic_customer_ids
            )
        ]

    def _phase_locked_customer_ids(self, sol: Solution) -> Set[int]:
        if "phase_locked_customer_ids" not in sol.data:
            return set()
        locked_customer_ids = sol.data["phase_locked_customer_ids"]
        if not isinstance(locked_customer_ids, set):
            raise TypeError('sol.data["phase_locked_customer_ids"] must be a set')
        return set(locked_customer_ids)

    def _phase_completed_customer_ids(self, sol: Solution) -> Set[int]:
        if "phase_completed_customer_ids" not in sol.data:
            return set()
        completed_customer_ids = sol.data["phase_completed_customer_ids"]
        if not isinstance(completed_customer_ids, set):
            raise TypeError('sol.data["phase_completed_customer_ids"] must be a set')
        return set(completed_customer_ids)

    def _phase_future_dynamic_customer_ids(self, sol: Solution) -> Set[int]:
        if "phase_future_dynamic_customer_ids" not in sol.data:
            return set()
        future_dynamic_customer_ids = sol.data["phase_future_dynamic_customer_ids"]
        if not isinstance(future_dynamic_customer_ids, set):
            raise TypeError('sol.data["phase_future_dynamic_customer_ids"] must be a set')
        return set(future_dynamic_customer_ids)

    def _phase_locked_drone_intervals(self, sol: Solution) -> List[Dict[str, Any]]:
        if "phase_locked_drone_intervals" not in sol.data:
            return []
        intervals = sol.data["phase_locked_drone_intervals"]
        if not isinstance(intervals, list):
            raise TypeError('sol.data["phase_locked_drone_intervals"] must be a list')
        normalized_intervals = []
        required_keys = {
            "task_id",
            "truck_id",
            "drone_id",
            "customer",
            "launch_time",
            "recovery_time",
        }
        for interval_index, interval in enumerate(intervals):
            if not isinstance(interval, dict):
                raise TypeError(
                    f"phase locked drone interval {interval_index} must be a dict"
                )
            missing_keys = required_keys - set(interval)
            if missing_keys:
                raise ValueError(
                    f"phase locked drone interval {interval_index} missing required "
                    f"keys: {sorted(missing_keys)}"
                )
            for key_name in ("task_id", "truck_id", "drone_id", "customer"):
                if isinstance(interval[key_name], bool) or not isinstance(
                    interval[key_name],
                    int,
                ):
                    raise TypeError(
                        f"phase locked drone interval {interval_index} {key_name} "
                        f"must be int, got {type(interval[key_name]).__name__}"
                    )
            for key_name in ("launch_time", "recovery_time"):
                if isinstance(interval[key_name], bool) or not isinstance(
                    interval[key_name],
                    (int, float),
                ):
                    raise TypeError(
                        f"phase locked drone interval {interval_index} {key_name} "
                        f"must be numeric, got {type(interval[key_name]).__name__}"
                    )
            launch_time = float(interval["launch_time"])
            recovery_time = float(interval["recovery_time"])
            if recovery_time < launch_time:
                raise ValueError(
                    f"phase locked drone interval {interval_index} recovery_time "
                    f"{recovery_time} is before launch_time {launch_time}"
                )
            normalized_intervals.append(
                {
                    "task_id": interval["task_id"],
                    "truck_id": interval["truck_id"],
                    "drone_id": interval["drone_id"],
                    "customer": interval["customer"],
                    "launch_time": launch_time,
                    "recovery_time": recovery_time,
                }
            )
        return normalized_intervals

    def _key_nodes(self, sol: Solution) -> Set[int]:
        """
        收集当前解中的关键节点。
        关键节点包括：
        1. depot_start；
        2. depot_end；
        3. replenishment_node；
        4. 所有无人机任务的 launch_node；
        5. 所有无人机任务的 recovery_node。
        随机破坏阶段默认不删除这些关键节点，避免破坏无人机任务锚点。
        """
        key_nodes = {
            self.depot_start,
            self.depot_end,
            self.replenishment_node,
        }
        key_nodes.update(self._phase_locked_customer_ids(sol))
        if "phase_start_state_by_truck" in sol.data:
            phase_start_state_by_truck = sol.data["phase_start_state_by_truck"]
            if not isinstance(phase_start_state_by_truck, dict):
                raise TypeError('sol.data["phase_start_state_by_truck"] must be a dict')
            for truck_id, route in sol.data["truck_routes"].items():
                if truck_id not in phase_start_state_by_truck:
                    raise ValueError(f"phase_start_state_by_truck missing truck_id {truck_id}")
                if not route:
                    raise ValueError(f"truck route of truck {truck_id} must not be empty")
                key_nodes.add(route[0])
        for task in sol.data["drone_routes"]:
            key_nodes.add(task["launch_node"])
            key_nodes.add(task["recovery_node"])

        return key_nodes

    def _customers_in_solution(self, sol: Solution) -> List[int]:
        """
        收集当前解中已经被卡车或无人机服务的客户。

        适配当前 solution 结构：
        1. 卡车路径来自 sol.truck_routes: {truck_id: [0, ..., depot_end]}；
        2. 无人机任务来自 sol.drone_tasks，每个任务的服务客户字段是 "customer"；
        3. 0、depot_end、999 不算客户；
        4. 节点必须存在于 self.customers 中，否则直接报错。
        """
        seen = set()
        non_customer_nodes = {
            self.depot_start,
            self.depot_end,
            self.replenishment_node,
        }

        if not isinstance(sol.truck_routes, dict):
            raise TypeError("sol.truck_routes must be a dict")

        # 卡车服务客户：扫描每辆卡车路径中的客户节点。
        locked_customer_ids = self._phase_locked_customer_ids(sol)
        for truck_id, route in sol.truck_routes.items():
            if not isinstance(route, list):
                raise TypeError(f"truck route of truck {truck_id} must be a list")
            for position, node in enumerate(route):
                if node in non_customer_nodes:
                    continue
                if position == 0 and node in locked_customer_ids:
                    continue
                if node not in self.customers:
                    raise ValueError(
                        f"truck route of truck {truck_id} contains unknown customer {node}"
                    )
                seen.add(node)
        # 无人机服务客户：当前代码中单个任务一次服务一个 customer。
        for task_index, task in enumerate(sol.drone_tasks):
            if not isinstance(task, dict):
                raise TypeError(f"drone task {task_index} must be a dict")
            if "customer" not in task:
                raise ValueError(f"drone task {task_index} missing required key: customer")
            customer_id = task["customer"]
            if customer_id in non_customer_nodes:
                raise ValueError(
                    f"drone task {task_index} customer cannot be depot or replenishment node: "
                    f"{customer_id}"
                )
            if customer_id not in self.customers:
                raise ValueError(
                    f"drone task {task_index} contains unknown customer {customer_id}"
                )
            seen.add(customer_id)
        return list(seen)

    def _customer_total_demand(self, customer_id: int) -> float:
        """
        计算客户两类需求总量。

        字段缺失时直接由字典访问抛出 KeyError，不做默认值兜底。
        """
        customer = self.customers[customer_id]
        return (
            customer["basic_demand"]
            + customer["emergency_demand"]
        )

    def _customer_priority_score(self, customer_id: int) -> float:
        """
        计算客户需求重要度。

        数值越大，表示客户需求越重要。
        字段缺失或非法时显式报错，不做默认值兜底。
        """
        return require_customer_priority_weight(customer_id, self.customers)

    def _customer_unserved_penalty(self, customer_id: int) -> float:
        """计算客户未服务惩罚；字段缺失时直接报错，不做默认补全。"""
        return self.unserved_penalty * self._customer_priority_score(customer_id)

    def _truck_capacity(self, truck_id: int):
        """读取卡车容量；缺少 truck_id 时直接报错。"""
        if isinstance(self.truck_capacity_by_truck, dict):
            return self.truck_capacity_by_truck[truck_id]
        return self.truck_capacity_by_truck

    def _route_anchor_node_for_truck(self, sol: Solution, truck_id: int) -> int:
        if "phase_start_state_by_truck" not in sol.data:
            raise ValueError("solution missing required key: phase_start_state_by_truck")
        phase_start_state_by_truck = sol.data["phase_start_state_by_truck"]
        if not isinstance(phase_start_state_by_truck, dict):
            raise TypeError('sol.data["phase_start_state_by_truck"] must be a dict')
        if truck_id not in phase_start_state_by_truck:
            raise ValueError(f"phase_start_state_by_truck missing truck_id {truck_id}")
        start_state = phase_start_state_by_truck[truck_id]
        if not isinstance(start_state, dict):
            raise TypeError(f"phase_start_state_by_truck[{truck_id}] must be a dict")
        if "anchor_node" not in start_state:
            raise ValueError(
                f"phase_start_state_by_truck[{truck_id}] missing required key: anchor_node"
            )
        return start_state["anchor_node"]

    def _validate_drone_local_resource_feasibility(
        self,
        sol: Solution,
        sortie_eval: Dict[str, Any],
    ) -> bool:
        """候选阶段严格检查无人机全局资源约束，不修改解。"""
        if not sortie_eval["feasible"]:
            raise ValueError("sortie_eval must be feasible before local resource validation")

        customer_id = sortie_eval["customer_id"]
        truck_id = sortie_eval["truck_id"]
        drone_id = sortie_eval["drone_id"]
        launch_node = sortie_eval["launch_node"]
        recovery_node = sortie_eval["recovery_node"]
        period_index = sortie_eval["period_index"]
        occupied_segments = sortie_eval["occupied_segments"]

        if customer_id in sol.data["served"]:
            return False
        for task_index, task in enumerate(sol.data["drone_routes"]):
            if task["customer"] == customer_id:
                return False

        if "is_static" not in self.customers[customer_id]:
            raise ValueError(f"customer {customer_id} missing required field: is_static")
        customer_is_static = self.customers[customer_id]["is_static"]
        if not isinstance(customer_is_static, bool):
            raise TypeError(
                f"customer {customer_id} is_static must be bool, "
                f"got {type(customer_is_static).__name__}"
            )

        if launch_node not in self.customers:
            raise ValueError(f"drone launch_node {launch_node} is not in self.customers")
        if launch_node == self.replenishment_node:
            return False
        if not customer_is_static and "release_time" not in self.customers[customer_id]:
            raise ValueError(f"dynamic customer {customer_id} missing required field: release_time")

        if recovery_node != self.depot_end and recovery_node not in self.customers:
            raise ValueError(f"drone recovery_node {recovery_node} is not in self.customers")
        if customer_is_static:
            if recovery_node == self.depot_end:
                return False

        if period_index is None:
            raise ValueError("sortie_eval period_index must not be None")
        for field_name in ("launch_time", "customer_service_start", "recovery_time"):
            if field_name not in sortie_eval:
                raise ValueError(f"sortie_eval missing required field: {field_name}")
            if sortie_eval[field_name] is None:
                raise ValueError(f"sortie_eval {field_name} must not be None")
            if isinstance(sortie_eval[field_name], bool) or not isinstance(
                sortie_eval[field_name],
                (int, float),
            ):
                raise TypeError(
                    f"sortie_eval {field_name} must be numeric, "
                    f"got {type(sortie_eval[field_name]).__name__}"
                )

        launch_time = float(sortie_eval["launch_time"])
        recovery_time = float(sortie_eval["recovery_time"])
        if recovery_time < launch_time:
            return False
        for task in sol.data["drone_routes"]:
            if task["truck_id"] != truck_id or task["drone_id"] != drone_id:
                continue
            existing_launch_time, existing_recovery_time = get_drone_task_interval(task)
            if intervals_overlap(
                launch_time,
                recovery_time,
                existing_launch_time,
                existing_recovery_time,
            ):
                return False
        for interval in self._phase_locked_drone_intervals(sol):
            if interval["truck_id"] != truck_id or interval["drone_id"] != drone_id:
                continue
            if intervals_overlap(
                launch_time,
                recovery_time,
                interval["launch_time"],
                interval["recovery_time"],
            ):
                return False

        if truck_id not in self.drone_ids_by_truck:
            raise ValueError(f"drone_ids_by_truck missing truck_id {truck_id}")
        segment_limit = len(self.drone_ids_by_truck[truck_id])
        for segment in occupied_segments:
            if segment[0] != truck_id:
                raise ValueError(
                    f"occupied segment {segment} truck_id does not match task truck_id {truck_id}"
                )
            if segment not in sol.data["segment_usage"]:
                raise ValueError(f"segment_usage missing occupied segment {segment}")
            current_usage = sol.data["segment_usage"][segment]
            if current_usage + 1 > segment_limit:
                return False

        return True

    def _drone_task_diagnostics(
        self,
        sol: Solution,
        scope: str,
    ) -> List[Dict[str, Any]]:
        if "truck_routes" not in sol.data:
            raise ValueError("solution missing required key: truck_routes")
        if "drone_routes" not in sol.data:
            raise ValueError("solution missing required key: drone_routes")
        if not isinstance(sol.data["truck_routes"], dict):
            raise TypeError('sol.data["truck_routes"] must be a dict')
        if not isinstance(sol.data["drone_routes"], list):
            raise TypeError('sol.data["drone_routes"] must be a list')

        truck_evaluations = None
        validation_report = sol.data.get("validation_report")
        if isinstance(validation_report, dict):
            candidate_truck_evaluations = validation_report.get("truck_evaluations")
            if isinstance(candidate_truck_evaluations, dict):
                truck_evaluations = candidate_truck_evaluations

        diagnostics = []
        for task_index, task in enumerate(sol.data["drone_routes"]):
            if not isinstance(task, dict):
                diagnostics.append(
                    {
                        "scope": scope,
                        "task_index": task_index,
                        "error": f"task must be a dict, got {type(task).__name__}",
                    }
                )
                continue
            diagnostics.append(
                self._build_drone_task_diagnostic(
                    sol=sol,
                    task_index=task_index,
                    task=task,
                    truck_evaluations=truck_evaluations,
                    timing=None,
                    scope=scope,
                )
            )
        return diagnostics

    def _build_drone_task_diagnostic(
        self,
        sol: Solution,
        task_index: int,
        task: Dict[str, Any],
        truck_evaluations: Optional[Dict[int, Dict[str, Any]]],
        timing: Optional[Dict[str, Any]],
        scope: str,
    ) -> Dict[str, Any]:
        diagnostic = {
            "scope": scope,
            "task_index": task_index,
            "task_id": task.get("task_id"),
            "truck_id": task.get("truck_id"),
            "drone_id": task.get("drone_id"),
            "customer": task.get("customer"),
            "launch_node": task.get("launch_node"),
            "launch_idx": task.get("launch_idx"),
            "recovery_node": task.get("recovery_node"),
            "recovery_idx": task.get("recovery_idx"),
            "launch_time": task.get("launch_time"),
            "recovery_time": task.get("recovery_time"),
            "period_index": task.get("period_index"),
            "index_checks": [],
        }

        truck_routes = sol.data["truck_routes"]
        truck_id = task.get("truck_id")
        if truck_id not in truck_routes:
            diagnostic["route_error"] = f"truck_id {truck_id} not in truck_routes"
        else:
            route = truck_routes[truck_id]
            if not isinstance(route, list):
                diagnostic["route_error"] = (
                    f"truck route must be a list, got {type(route).__name__}"
                )
            else:
                diagnostic["route"] = list(route)
                for node_key, index_key in (
                    ("launch_node", "launch_idx"),
                    ("recovery_node", "recovery_idx"),
                ):
                    node = task.get(node_key)
                    index_value = task.get(index_key)
                    matching_indices = [
                        index
                        for index, route_node in enumerate(route)
                        if route_node == node
                    ]
                    index_check = {
                        "node_key": node_key,
                        "index_key": index_key,
                        "node": node,
                        "index": index_value,
                        "matching_indices": matching_indices,
                    }
                    if isinstance(index_value, bool) or not isinstance(index_value, int):
                        index_check["status"] = (
                            f"{index_key} must be int, got "
                            f"{type(index_value).__name__}"
                        )
                    elif index_value < 0 or index_value >= len(route):
                        index_check["status"] = (
                            f"{index_key} {index_value} outside route length "
                            f"{len(route)}"
                        )
                    else:
                        index_check["route_node_at_index"] = route[index_value]
                        if route[index_value] == node:
                            index_check["status"] = "ok"
                        else:
                            index_check["status"] = (
                                f"mismatch: route[{index_value}]="
                                f"{route[index_value]}, expected {node}"
                            )
                    diagnostic["index_checks"].append(index_check)

        evaluation = task.get("evaluation")
        if isinstance(evaluation, dict):
            diagnostic["evaluation_violations"] = list(
                evaluation.get("violations", [])
                if isinstance(evaluation.get("violations", []), list)
                else []
            )
            recomputed = evaluation.get("recomputed")
            if isinstance(recomputed, dict):
                diagnostic["evaluation_recomputed"] = {
                    "feasible": recomputed.get("feasible"),
                    "launch_time": recomputed.get("launch_time"),
                    "recovery_time": recomputed.get("recovery_time"),
                    "period_index": recomputed.get("period_index"),
                    "violations": list(
                        recomputed.get("violations", [])
                        if isinstance(recomputed.get("violations", []), list)
                        else []
                    ),
                }
        if isinstance(timing, dict):
            diagnostic["current_timing"] = {
                "feasible": timing.get("feasible"),
                "launch_time": timing.get("launch_time"),
                "recovery_time": timing.get("recovery_time"),
                "period_index": timing.get("period_index"),
                "violations": list(
                    timing.get("violations", [])
                    if isinstance(timing.get("violations", []), list)
                    else []
                ),
                "warnings": list(
                    timing.get("warnings", [])
                    if isinstance(timing.get("warnings", []), list)
                    else []
                ),
            }

        if truck_evaluations is not None and truck_id in truck_evaluations:
            truck_evaluation = truck_evaluations[truck_id]
            diagnostic["truck_evaluation"] = {
                "feasible": truck_evaluation.get("feasible"),
                "violations": list(
                    truck_evaluation.get("violations", [])
                    if isinstance(truck_evaluation.get("violations", []), list)
                    else []
                ),
                "arrival_time_indices": sorted(
                    truck_evaluation.get("arrival_times_by_index", {}).keys()
                    if isinstance(
                        truck_evaluation.get("arrival_times_by_index"),
                        dict,
                    )
                    else []
                ),
            }
            task_id = task.get("task_id")
            timings = truck_evaluation.get("drone_task_timings")
            if isinstance(timings, dict) and task_id in timings:
                task_timing = timings[task_id]
                if isinstance(task_timing, dict):
                    diagnostic["truck_timing_by_task_id"] = {
                        "feasible": task_timing.get("feasible"),
                        "launch_time": task_timing.get("launch_time"),
                        "recovery_time": task_timing.get("recovery_time"),
                        "period_index": task_timing.get("period_index"),
                        "violations": list(
                            task_timing.get("violations", [])
                            if isinstance(task_timing.get("violations", []), list)
                            else []
                        ),
                    }

        return diagnostic

    def _drone_task_time(self, task: Dict[str, Any], field_name: str) -> float:
        if field_name in task:
            value = task[field_name]
        else:
            evaluation = task.get("evaluation")
            recomputed = evaluation.get("recomputed") if isinstance(evaluation, dict) else None
            if isinstance(recomputed, dict) and field_name in recomputed:
                value = recomputed[field_name]
            elif isinstance(evaluation, dict) and field_name in evaluation:
                value = evaluation[field_name]
            else:
                raise ValueError(f"drone task missing time field: {field_name}")
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError(
                f"drone task time field {field_name} must be numeric, "
                f"got {type(value).__name__}"
            )
        return float(value)

    def _drone_time_intervals_overlap(
        self,
        first_launch: float,
        first_recovery: float,
        second_launch: float,
        second_recovery: float,
    ) -> bool:
        return intervals_overlap(
            first_launch,
            first_recovery,
            second_launch,
            second_recovery,
        )

    def _validate_drone_time_nonoverlap(self, sol: Solution) -> Dict[str, Any]:
        """
        检查同一 truck_id + drone_id 的无人机任务时间区间是否不重叠。
        允许同一无人机同一 period 内执行多个任务，但必须满足前一任务
        recovery_time <= 后一任务 launch_time。
        """
        if not hasattr(sol, "data"):
            raise TypeError("sol must expose data")
        if "drone_routes" not in sol.data:
            raise ValueError("solution missing required key: drone_routes")
        if not isinstance(sol.data["drone_routes"], list):
            raise TypeError('solution.data["drone_routes"] must be a list')

        tasks_by_drone: Dict[Tuple[int, int], List[Dict[str, Any]]] = {}
        violations = []

        for task_index, task in enumerate(sol.data["drone_routes"]):
            if not isinstance(task, dict):
                raise TypeError(f"drone task {task_index} must be a dict")
            for key in ("task_id", "truck_id", "drone_id", "customer"):
                if key not in task:
                    raise ValueError(
                        f"drone task {task_index} missing required key: {key}"
                    )
            launch_time, recovery_time = get_drone_task_interval(task)
            group_key = (task["truck_id"], task["drone_id"])
            tasks_by_drone.setdefault(group_key, []).append(
                {
                    "source": "phase",
                    "task_id": task["task_id"],
                    "customer": task["customer"],
                    "launch_time": launch_time,
                    "recovery_time": recovery_time,
                }
            )

        for interval in self._phase_locked_drone_intervals(sol):
            group_key = (interval["truck_id"], interval["drone_id"])
            tasks_by_drone.setdefault(group_key, []).append(
                {
                    "source": "locked",
                    "task_id": interval["task_id"],
                    "customer": interval["customer"],
                    "launch_time": interval["launch_time"],
                    "recovery_time": interval["recovery_time"],
                }
            )

        for (truck_id, drone_id), intervals in tasks_by_drone.items():
            intervals.sort(
                key=lambda item: (item["launch_time"], item["recovery_time"])
            )
            for previous, current in zip(intervals, intervals[1:]):
                if intervals_overlap(
                    previous["launch_time"],
                    previous["recovery_time"],
                    current["launch_time"],
                    current["recovery_time"],
                ):
                    violations.append(
                        f"drone {drone_id} on truck {truck_id} has overlapping tasks: "
                        f"{previous['source']} task {previous['task_id']} "
                        f"customer {previous['customer']} "
                        f"[{previous['launch_time']}, {previous['recovery_time']}] and "
                        f"{current['source']} task {current['task_id']} "
                        f"customer {current['customer']} "
                        f"[{current['launch_time']}, {current['recovery_time']}]"
                    )

        return {
            "valid": len(violations) == 0,
            "violations": violations,
        }

    def _drone_move_overlaps_existing_tasks(
        self,
        sol: Solution,
        move: Dict[str, Any],
    ) -> bool:
        if move.get("mode") != "drone":
            return False
        if "drone_routes" not in sol.data:
            raise ValueError("solution missing required key: drone_routes")
        if not isinstance(sol.data["drone_routes"], list):
            raise TypeError('sol.data["drone_routes"] must be a list')
        for key in ("truck_id", "drone_id"):
            if key not in move:
                raise ValueError(f"drone move missing required key: {key}")
        if "evaluation" in move:
            evaluation = move["evaluation"]
        elif "drone_task" in move and isinstance(move["drone_task"], dict):
            evaluation = move["drone_task"].get("evaluation")
        else:
            raise ValueError("drone move missing evaluation")
        if not isinstance(evaluation, dict):
            raise TypeError("drone move evaluation must be a dict")
        for key in ("launch_time", "recovery_time"):
            if key not in evaluation:
                raise ValueError(f"drone move evaluation missing {key}")

        candidate_launch_time = evaluation["launch_time"]
        candidate_recovery_time = evaluation["recovery_time"]
        candidate_truck_id = move["truck_id"]
        candidate_drone_id = move["drone_id"]

        for existing_task in sol.data["drone_routes"]:
            if not isinstance(existing_task, dict):
                raise TypeError("existing drone task must be a dict")
            if existing_task.get("truck_id") != candidate_truck_id:
                continue
            if existing_task.get("drone_id") != candidate_drone_id:
                continue
            existing_launch_time, existing_recovery_time = get_drone_task_interval(
                existing_task
            )
            if intervals_overlap(
                candidate_launch_time,
                candidate_recovery_time,
                existing_launch_time,
                existing_recovery_time,
            ):
                return True

        return False

    def _drone_time_overlap_failure_details(
        self,
        violations: List[str],
    ) -> Dict[str, Any]:
        if not isinstance(violations, list):
            raise TypeError("violations must be a list")
        return {
            "rejection_reason": "drone_time_overlap_after_rebuild",
            "full_validation_violations": [],
            "truck_evaluation_violations": [],
            "lightweight_violations": list(violations),
        }

    @staticmethod
    def _message_is_blocked_edge_violation(message: Any) -> bool:
        text = str(message)
        return (
            "blocked" in text
            or "risk level 4" in text
            or "风险等级为 4" in text
            or "不可通行" in text
        )

    def _solution_has_blocked_edge_violation(self, sol: Solution) -> bool:
        messages = []

        full_report = sol.data.get("full_validation_report", {})
        if isinstance(full_report, dict):
            violations = full_report.get("violations", [])
            if isinstance(violations, list):
                messages.extend(violations)

        validation_report = sol.data.get("validation_report", {})
        if isinstance(validation_report, dict):
            truck_evaluations = validation_report.get("truck_evaluations", {})
            if isinstance(truck_evaluations, dict):
                for truck_eval in truck_evaluations.values():
                    if isinstance(truck_eval, dict):
                        violations = truck_eval.get("violations", [])
                        if isinstance(violations, list):
                            messages.extend(violations)

        return any(
            self._message_is_blocked_edge_violation(message)
            for message in messages
        )

    def _truck_evaluation_has_blocked_edge_violation(
        self,
        truck_eval: Dict[str, Any],
    ) -> bool:
        if not isinstance(truck_eval, dict):
            raise TypeError("truck_eval must be a dict")
        if "violations" not in truck_eval:
            raise ValueError("truck_eval missing required key: violations")
        violations = truck_eval["violations"]
        if not isinstance(violations, list):
            raise TypeError('truck_eval["violations"] must be a list')
        return any(
            self._message_is_blocked_edge_violation(message)
            for message in violations
        )

    def _truck_blocked_edge_failure_details(
        self,
        violations: List[Any],
    ) -> Dict[str, Any]:
        if not isinstance(violations, list):
            raise TypeError("violations must be a list")
        return {
            "rejection_reason": "truck_insert_blocked_edge_after_rebuild",
            "full_validation_violations": [],
            "truck_evaluation_violations": [
                str(violation)
                for violation in violations
            ],
            "lightweight_violations": [],
        }

    @staticmethod
    def _insert_rejection_reason(
        failure_details: Optional[Dict[str, Any]],
        default_reason: str,
    ) -> str:
        if failure_details is None:
            return default_reason
        if not isinstance(failure_details, dict):
            raise TypeError("failure_details must be a dict")
        reason = failure_details.get("rejection_reason", default_reason)
        if not isinstance(reason, str):
            raise TypeError("failure_details rejection_reason must be a string")
        return reason

    def _reject_replenishment_nodes(
        self,
        sol: Solution,
        scope: str,
    ) -> None:
        if "truck_routes" not in sol.data:
            raise ValueError("solution missing required key: truck_routes")
        if "drone_routes" not in sol.data:
            raise ValueError("solution missing required key: drone_routes")
        if not isinstance(sol.data["truck_routes"], dict):
            raise TypeError('sol.data["truck_routes"] must be a dict')
        if not isinstance(sol.data["drone_routes"], list):
            raise TypeError('sol.data["drone_routes"] must be a list')

        for truck_id, route in sol.data["truck_routes"].items():
            if not isinstance(route, list):
                raise TypeError(f"truck route of truck {truck_id} must be a list")
            for position, node in enumerate(route):
                if node == self.replenishment_node:
                    raise InvalidMoveError(
                        f"{scope}: deprecated replenishment node "
                        f"{self.replenishment_node} appears in truck {truck_id} "
                        f"route at position {position}"
                    )

        for task_index, task in enumerate(sol.data["drone_routes"]):
            if not isinstance(task, dict):
                raise TypeError(f"drone task {task_index} must be a dict")
            for key in ("launch_node", "recovery_node", "customer"):
                if key in task and task[key] == self.replenishment_node:
                    raise InvalidMoveError(
                        f"{scope}: deprecated replenishment node "
                        f"{self.replenishment_node} appears in drone task "
                        f"{task_index} field {key}"
                    )

    def _shift_drone_task_indices_after_truck_insert(
        self,
        sol: Solution,
        truck_id: int,
        insert_pos: int,
        inserted_count: int,
    ) -> None:
        if inserted_count <= 0:
            raise ValueError(f"inserted_count must be positive, got {inserted_count}")
        for task_index, task in enumerate(sol.data["drone_routes"]):
            if not isinstance(task, dict):
                raise TypeError(f"drone task {task_index} must be a dict")
            if task.get("truck_id") != truck_id:
                continue
            for index_key in ("launch_idx", "recovery_idx"):
                if index_key not in task:
                    continue
                task_index_value = task[index_key]
                if isinstance(task_index_value, bool) or not isinstance(task_index_value, int):
                    raise TypeError(
                        f"drone task {task_index} {index_key} must be int, "
                        f"got {type(task_index_value).__name__}"
                    )
                if task_index_value >= insert_pos:
                    task[index_key] = task_index_value + inserted_count

    def _shift_drone_task_indices_after_truck_delete(
        self,
        sol: Solution,
        truck_id: int,
        removed_positions: Set[int],
    ) -> None:
        if not isinstance(removed_positions, set):
            raise TypeError("removed_positions must be a set")
        if not removed_positions:
            return None
        for task_index, task in enumerate(sol.data["drone_routes"]):
            if not isinstance(task, dict):
                raise TypeError(f"drone task {task_index} must be a dict")
            if task.get("truck_id") != truck_id:
                continue
            for index_key in ("launch_idx", "recovery_idx"):
                if index_key not in task:
                    continue
                task_index_value = task[index_key]
                if isinstance(task_index_value, bool) or not isinstance(task_index_value, int):
                    raise TypeError(
                        f"drone task {task_index} {index_key} must be int, "
                        f"got {type(task_index_value).__name__}"
                    )
                if task_index_value in removed_positions:
                    raise ValueError(
                        f"truck deletion would remove drone task {task_index} {index_key} "
                        f"at route index {task_index_value}"
                    )
                shift = sum(1 for removed_pos in removed_positions if removed_pos < task_index_value)
                if shift:
                    task[index_key] = task_index_value - shift
        return None

    def _relatedness(
        self,
        seed_customer: int,
        other_customer: int,
        weights: Dict[str, float],
    ) -> float:
        """
        计算两个客户之间的相关性距离。

        返回值越小，表示两个客户越相关，越适合一起被相关性移除算子删除。
        """
        required_weights = {
            "distance",
            "earliest",
            "latest",
            "priority",
            "demand",
            "static",
        }
        missing_weights = required_weights - set(weights)
        if missing_weights:
            raise ValueError(f"relatedness weights missing keys: {sorted(missing_weights)}")

        if seed_customer not in self.customers:
            raise ValueError(f"seed_customer {seed_customer} is not in self.customers")
        if other_customer not in self.customers:
            raise ValueError(f"other_customer {other_customer} is not in self.customers")

        c1 = self.customers[seed_customer]
        c2 = self.customers[other_customer]

        distance_related = self.distance_matrix[seed_customer][other_customer]
        earliest_related = abs(c1["earliest"] - c2["earliest"])
        latest_related = abs(c1["latest"] - c2["latest"])
        priority_related = abs(
            self._customer_priority_score(seed_customer)
            - self._customer_priority_score(other_customer)
        )
        demand_related = abs(
            self._customer_total_demand(seed_customer)
            - self._customer_total_demand(other_customer)
        )
        if c1["is_static"] != c2["is_static"]:
            static_related = 1.0
        else:
            static_related = 0.0

        return (
            weights["distance"] * distance_related
            + weights["earliest"] * earliest_related
            + weights["latest"] * latest_related
            + weights["priority"] * priority_related
            + weights["demand"] * demand_related
            + weights["static"] * static_related
        )

    def _route_after_removal_is_risk_feasible(
        self,
        sol: Solution,
        truck_id: int,
        removed_customers: Set[int],
    ) -> bool:
        if not isinstance(removed_customers, set):
            raise TypeError("removed_customers must be a set")
        if "truck_routes" not in sol.data:
            raise ValueError('solution missing required key: "truck_routes"')
        if "validation_report" not in sol.data:
            raise ValueError('solution missing required key: "validation_report"')
        validation_report = sol.data["validation_report"]
        if not isinstance(validation_report, dict):
            raise TypeError('sol.data["validation_report"] must be a dict')
        if "truck_evaluations" not in validation_report:
            raise ValueError('validation_report missing required key: "truck_evaluations"')
        truck_routes = sol.data["truck_routes"]
        truck_evaluations = validation_report["truck_evaluations"]
        if not isinstance(truck_routes, dict):
            raise TypeError('sol.data["truck_routes"] must be a dict')
        if not isinstance(truck_evaluations, dict):
            raise TypeError('validation_report["truck_evaluations"] must be a dict')
        if truck_id not in truck_routes:
            raise ValueError(f"truck_routes missing truck_id {truck_id}")
        if truck_id not in truck_evaluations:
            raise ValueError(f"truck_evaluations missing truck_id {truck_id}")

        route = truck_routes[truck_id]
        truck_eval = truck_evaluations[truck_id]
        if not isinstance(route, list):
            raise TypeError(f"truck route of truck {truck_id} must be a list")
        if not isinstance(truck_eval, dict):
            raise TypeError(f"truck evaluation of truck {truck_id} must be a dict")
        if "timeline_by_position" not in truck_eval:
            raise ValueError(
                f"truck evaluation of truck {truck_id} missing timeline_by_position"
            )
        timeline_by_position = truck_eval["timeline_by_position"]
        if not isinstance(timeline_by_position, dict):
            raise TypeError(
                f"truck evaluation of truck {truck_id} timeline_by_position must be a dict"
            )

        retained_positions = [
            position
            for position, node in enumerate(route)
            if node not in removed_customers
        ]
        if not retained_positions:
            raise ValueError(
                f"truck {truck_id} route has no retained nodes after removal"
            )
        retained_route = [route[position] for position in retained_positions]
        if retained_route[-1] != self.depot_end:
            return False

        for edge_position in range(len(retained_positions) - 1):
            original_u_position = retained_positions[edge_position]
            original_v_position = retained_positions[edge_position + 1]
            u = route[original_u_position]
            v = route[original_v_position]
            if original_u_position not in timeline_by_position:
                return False
            timeline_record = timeline_by_position[original_u_position]
            if not isinstance(timeline_record, dict):
                raise TypeError(
                    f"truck {truck_id} timeline position {original_u_position} "
                    "must be a dict"
                )
            if "departure_time" not in timeline_record:
                raise ValueError(
                    f"truck {truck_id} timeline position {original_u_position} "
                    "missing departure_time"
                )
            departure_time = timeline_record["departure_time"]
            if isinstance(departure_time, bool) or not isinstance(
                departure_time,
                (int, float),
            ):
                raise TypeError(
                    f"truck {truck_id} timeline position {original_u_position} "
                    f"departure_time must be numeric, got {type(departure_time).__name__}"
                )
            period_index = get_period_index(
                departure_time,
                self.periods,
                self.period_length,
            )
            period = self.periods[period_index]
            if period not in self.risk_matrix:
                raise ValueError(f"risk_matrix missing period {period}")
            if u not in self.risk_matrix[period]:
                raise ValueError(
                    f"risk_matrix period {period} missing from-node {u}"
                )
            if v not in self.risk_matrix[period][u]:
                raise ValueError(
                    f"risk_matrix period {period} missing edge {u}->{v}"
                )
            risk_level = self.risk_matrix[period][u][v]
            if risk_level == 4:
                return False

        return True

    def _truck_edge_is_passable_at_time(
        self,
        from_node: int,
        to_node: int,
        departure_time: float,
    ) -> bool:
        if isinstance(departure_time, bool) or not isinstance(
            departure_time,
            (int, float),
        ):
            raise TypeError(
                f"departure_time must be numeric, got {type(departure_time).__name__}"
            )
        period_index = get_period_index(
            departure_time,
            self.periods,
            self.period_length,
        )
        period = self.periods[period_index]

        if period not in self.risk_matrix:
            raise ValueError(f"risk_matrix missing period {period}")
        if from_node not in self.risk_matrix[period]:
            raise ValueError(f"risk_matrix[{period}] missing from_node {from_node}")
        if to_node not in self.risk_matrix[period][from_node]:
            raise ValueError(
                f"risk_matrix[{period}][{from_node}] missing to_node {to_node}"
            )

        return self.risk_matrix[period][from_node][to_node] != 4

    def _truck_travel_time_at_time(
        self,
        from_node: int,
        to_node: int,
        departure_time: float,
    ) -> float:
        period_index = get_period_index(
            departure_time,
            self.periods,
            self.period_length,
        )
        period = self.periods[period_index]
        if period not in self.truck_time_matrix:
            raise ValueError(f"truck_time_matrix missing period {period}")
        if from_node not in self.truck_time_matrix[period]:
            raise ValueError(
                f"truck_time_matrix[{period}] missing from_node {from_node}"
            )
        if to_node not in self.truck_time_matrix[period][from_node]:
            raise ValueError(
                f"truck_time_matrix[{period}][{from_node}] missing to_node {to_node}"
            )
        travel_time = self.truck_time_matrix[period][from_node][to_node]
        if isinstance(travel_time, bool) or not isinstance(travel_time, (int, float)):
            raise TypeError(
                f"truck travel time {from_node}->{to_node} in period {period} "
                f"must be numeric, got {type(travel_time).__name__}"
            )
        return float(travel_time)

    def _truck_insert_local_risk_feasible(
        self,
        sol: Solution,
        truck_id: int,
        insert_pos: int,
        insert_nodes: List[int],
    ) -> bool:
        """
        检查把 insert_nodes 插入 truck_id 路径 insert_pos 后，
        新增局部连接边在对应出发时间下是否可通行。
        """
        if not insert_nodes:
            raise ValueError("insert_nodes must not be empty")
        if "truck_routes" not in sol.data:
            raise ValueError("solution missing required key: truck_routes")
        if "validation_report" not in sol.data:
            raise ValueError("solution missing required key: validation_report")
        truck_routes = sol.data["truck_routes"]
        if not isinstance(truck_routes, dict):
            raise TypeError('sol.data["truck_routes"] must be a dict')
        if truck_id not in truck_routes:
            raise ValueError(f"truck_routes missing truck_id {truck_id}")
        route = truck_routes[truck_id]
        if not isinstance(route, list):
            raise TypeError(f"truck route of truck {truck_id} must be a list")
        if isinstance(insert_pos, bool) or not isinstance(insert_pos, int):
            raise TypeError(f"insert_pos must be int, got {type(insert_pos).__name__}")
        if insert_pos <= 0 or insert_pos >= len(route):
            raise ValueError(
                f"insert_pos must be in [1, len(route)-1], got {insert_pos}"
            )
        validation_report = sol.data["validation_report"]
        if not isinstance(validation_report, dict):
            raise TypeError('sol.data["validation_report"] must be a dict')
        if "truck_evaluations" not in validation_report:
            raise ValueError("validation_report missing required key: truck_evaluations")
        truck_evaluations = validation_report["truck_evaluations"]
        if truck_id not in truck_evaluations:
            raise ValueError(f"truck_evaluations missing truck_id {truck_id}")
        truck_eval = truck_evaluations[truck_id]
        if "timeline_by_position" not in truck_eval:
            raise ValueError(
                f"truck evaluation {truck_id} missing timeline_by_position"
            )
        timeline = truck_eval["timeline_by_position"]
        if not isinstance(timeline, dict):
            raise TypeError(
                f"truck evaluation {truck_id} timeline_by_position must be a dict"
            )

        prev_pos = insert_pos - 1
        if prev_pos not in timeline:
            if "feasible" not in truck_eval:
                raise ValueError(
                    f"truck evaluation {truck_id} missing required key: feasible"
                )
            if (
                truck_eval["feasible"] is False
                and self._truck_evaluation_has_blocked_edge_violation(truck_eval)
            ):
                return False
            raise ValueError(f"truck {truck_id} timeline missing position {prev_pos}")
        previous_record = timeline[prev_pos]
        if not isinstance(previous_record, dict):
            raise TypeError(f"truck {truck_id} timeline position {prev_pos} must be a dict")
        if "departure_time" not in previous_record:
            raise ValueError(
                f"truck {truck_id} timeline position {prev_pos} missing departure_time"
            )

        current_node = route[prev_pos]
        current_time = previous_record["departure_time"]
        next_original_node = route[insert_pos]
        check_nodes = list(insert_nodes) + [next_original_node]

        for next_node in check_nodes:
            if not self._truck_edge_is_passable_at_time(
                from_node=current_node,
                to_node=next_node,
                departure_time=current_time,
            ):
                return False

            travel_time = self._truck_travel_time_at_time(
                from_node=current_node,
                to_node=next_node,
                departure_time=current_time,
            )
            arrival_time = float(current_time) + travel_time

            if next_node in self.customers:
                customer = self.customers[next_node]
                for required_key in ("is_static", "service_time"):
                    if required_key not in customer:
                        raise ValueError(
                            f"customer {next_node} missing required field: {required_key}"
                        )
                service_start_time = arrival_time
                if customer["is_static"] is not True:
                    if "release_time" not in customer:
                        raise ValueError(
                            f"dynamic customer {next_node} missing required field: release_time"
                        )
                    release_time = customer["release_time"]
                    if isinstance(release_time, bool) or not isinstance(
                        release_time,
                        (int, float),
                    ):
                        raise TypeError(
                            f"dynamic customer {next_node} release_time must be numeric, "
                            f"got {type(release_time).__name__}"
                        )
                    if service_start_time < release_time:
                        service_start_time = release_time
                service_time = customer["service_time"]
                if isinstance(service_time, bool) or not isinstance(
                    service_time,
                    (int, float),
                ):
                    raise TypeError(
                        f"customer {next_node} service_time must be numeric, "
                        f"got {type(service_time).__name__}"
                    )
                current_time = service_start_time + service_time
            else:
                current_time = arrival_time

            current_node = next_node

        return True

    def _removal_set_is_risk_feasible(
        self,
        sol: Solution,
        removed_customers: Set[int],
    ) -> bool:
        if not isinstance(removed_customers, set):
            raise TypeError("removed_customers must be a set")
        if not removed_customers:
            return True
        if "truck_routes" not in sol.data:
            raise ValueError('solution missing required key: "truck_routes"')
        truck_routes = sol.data["truck_routes"]
        if not isinstance(truck_routes, dict):
            raise TypeError('sol.data["truck_routes"] must be a dict')

        for truck_id, route in truck_routes.items():
            if not isinstance(route, list):
                raise TypeError(f"truck route of truck {truck_id} must be a list")
            if any(node in removed_customers for node in route):
                if not self._route_after_removal_is_risk_feasible(
                    sol=sol,
                    truck_id=truck_id,
                    removed_customers=removed_customers,
                ):
                    return False

        return True

    def _select_risk_feasible_removed_set(
        self,
        sol: Solution,
        ordered_candidates: List[int],
        remove_count: int,
    ) -> Set[int]:
        if not isinstance(ordered_candidates, list):
            raise TypeError("ordered_candidates must be a list")
        if isinstance(remove_count, bool) or not isinstance(remove_count, int):
            raise TypeError(
                f"remove_count must be int, got {type(remove_count).__name__}"
            )
        if remove_count <= 0:
            raise ValueError(f"remove_count must be positive, got {remove_count}")

        removed: Set[int] = set()
        for candidate in ordered_candidates:
            if candidate in removed:
                continue
            trial_removed = set(removed)
            trial_removed.add(candidate)
            if self._removal_set_is_risk_feasible(
                sol=sol,
                removed_customers=trial_removed,
            ):
                removed.add(candidate)
            if len(removed) >= remove_count:
                break
        return removed

    def _remove_random(self, sol: Solution, x_ratio: float):
        """
        随机破坏算子。
        作用：
        从当前解中随机选择一部分可删除客户，并将其从卡车路径或无人机任务中移除。
        返回：
        destroyed: 删除后的解；
        removed: 被删除客户集合；
        context: 删除上下文信息。
        """
        destroyed = sol.deepcopy()
        candidates = self._collect_nonkey_customers(destroyed)

        if len(candidates) == 0:
            return destroyed, set(), {
                "reason": "random_empty",
                "removed_count": 0,
            }
        requested_remove_count = max(
            1,
            math.ceil(x_ratio * len(candidates)),
        )
        remove_count = _resolve_destroy_count(
            len(candidates),
            requested_remove_count,
            self.diagnostic_min_destroy_size,
        )
        self.rnd.shuffle(candidates)
        removed = self._select_risk_feasible_removed_set(
            sol=destroyed,
            ordered_candidates=candidates,
            remove_count=remove_count,
        )
        if not removed:
            return destroyed, set(), {
                "reason": "random_no_risk_feasible_removal",
                "removed_count": 0,
                "requested_remove_count": requested_remove_count,
                "resolved_remove_count": remove_count,
                "actual_removed_count": 0,
                "risk_bridge_filter_enabled": True,
                "risk_bridge_filtered_count": remove_count,
            }
        self._apply_removals(
            destroyed,
            removed,
            allow_key=False,
        )
        self._rebuild_solution(destroyed)
        context = {
            "reason": "random",
            "removed_count": len(removed),
            "removed_customers": list(removed),
            "requested_remove_count": requested_remove_count,
            "resolved_remove_count": remove_count,
            "actual_removed_count": len(removed),
            "risk_bridge_filter_enabled": True,
            "risk_bridge_filtered_count": remove_count - len(removed),
        }
        return destroyed, removed, context

    def _remove_related(self, sol: Solution, x_ratio: float):
        """
        相关性移除算子。
        从当前可删除客户中随机选择一个种子客户，然后删除与其最相关的一批客户。
        本函数只负责选择和删除结构，成本和派生信息由 _rebuild_solution 统一重算。
        """
        destroyed = sol.deepcopy()
        candidates = self._collect_nonkey_customers(destroyed)

        if len(candidates) == 0:
            return destroyed, set(), {
                "reason": "related_empty",
                "removed_count": 0,
            }

        requested_remove_count = max(
            1,
            math.ceil(x_ratio * len(candidates)),
        )
        remove_count = _resolve_destroy_count(
            len(candidates),
            requested_remove_count,
            self.diagnostic_min_destroy_size,
        )
        seed_customer = self.rnd.choice(candidates)
        related_weights = {
            "distance": 1.0,
            "earliest": 1.0,
            "latest": 1.0,
            "priority": 0.5,
            "demand": 0.5,
            "static": 3.0,
        }

        scored_customers = []
        for customer_id in candidates:
            score = self._relatedness(
                seed_customer=seed_customer,
                other_customer=customer_id,
                weights=related_weights,
            )
            scored_customers.append((score, customer_id))

        scored_customers.sort(key=lambda item: item[0])
        ordered_candidates = [
            customer_id
            for score, customer_id in scored_customers
        ]
        removed = self._select_risk_feasible_removed_set(
            sol=destroyed,
            ordered_candidates=ordered_candidates,
            remove_count=remove_count,
        )
        if not removed:
            return destroyed, set(), {
                "reason": "related_no_risk_feasible_removal",
                "seed_customer": seed_customer,
                "removed_count": 0,
                "requested_remove_count": requested_remove_count,
                "resolved_remove_count": remove_count,
                "actual_removed_count": 0,
                "risk_bridge_filter_enabled": True,
                "risk_bridge_filtered_count": remove_count,
            }

        self._apply_removals(
            destroyed,
            removed,
            allow_key=False,
        )
        self._rebuild_solution(destroyed)
        score_by_customer = {
            customer_id: score
            for score, customer_id in scored_customers
        }

        context = {
            "reason": "related",
            "seed_customer": seed_customer,
            "removed_count": len(removed),
            "removed_customers": list(removed),
            "requested_remove_count": requested_remove_count,
            "resolved_remove_count": remove_count,
            "actual_removed_count": len(removed),
            "risk_bridge_filter_enabled": True,
            "risk_bridge_filtered_count": remove_count - len(removed),
            "related_scores": {
                customer_id: score_by_customer[customer_id]
                for customer_id in removed
            },
        }
        return destroyed, removed, context

    def _remove_drone_task(self, sol: Solution, x_ratio: float):
        """
        无人机任务移除算子。
        随机移除一部分无人机任务，将这些任务服务的客户重新加入 unserved。
        卡车路径中的 launch_node 和 recovery_node 不会被删除。
        """
        if x_ratio <= 0:
            raise ValueError(f"x_ratio must be positive, got {x_ratio}")

        destroyed = sol.deepcopy()

        required_solution_keys = {
            "truck_routes",
            "drone_routes",
            "phase_start_state_by_truck",
            "unserved",
            "served",
            "cost",
            "feasible",
            "validation_report",
            "full_validation_report",
            "drone_period_usage",
            "segment_usage",
        }
        missing_solution_keys = required_solution_keys - set(destroyed.data)
        if missing_solution_keys:
            raise ValueError(
                f"solution missing required keys: {sorted(missing_solution_keys)}"
            )
        if not isinstance(destroyed.data["drone_routes"], list):
            raise TypeError('destroyed.data["drone_routes"] must be a list')
        if not isinstance(destroyed.data["served"], set):
            raise TypeError('destroyed.data["served"] must be a set')
        if not isinstance(destroyed.data["unserved"], list):
            raise TypeError('destroyed.data["unserved"] must be a list')

        drone_routes = destroyed.data["drone_routes"]
        if len(drone_routes) == 0:
            return destroyed, set(), {
                "reason": "drone_task_empty",
                "removed_count": 0,
            }

        requested_remove_count = max(
            1,
            math.ceil(x_ratio * len(drone_routes)),
        )
        remove_count = _resolve_destroy_count(
            len(drone_routes),
            requested_remove_count,
            self.diagnostic_min_destroy_size,
        )
        task_indices = list(range(len(drone_routes)))
        self.rnd.shuffle(task_indices)
        selected_indices = set(task_indices[:remove_count])

        new_drone_routes = []
        removed = set()
        removed_tasks = []
        required_task_keys = {
            "customer",
            "truck_id",
            "drone_id",
            "launch_node",
            "launch_idx",
            "recovery_node",
        }
        for task_index, task in enumerate(drone_routes):
            if not isinstance(task, dict):
                raise TypeError(f"drone task {task_index} must be a dict")
            missing_task_keys = required_task_keys - set(task)
            if missing_task_keys:
                raise ValueError(
                    f"drone task {task_index} missing required keys: {sorted(missing_task_keys)}"
                )

            if task_index in selected_indices:
                customer_id = task["customer"]
                if customer_id not in self.customers:
                    raise ValueError(
                        f"drone task {task_index} contains unknown customer {customer_id}"
                    )
                removed.add(customer_id)
                removed_tasks.append(copy.deepcopy(task))
                continue

            new_drone_routes.append(task)

        destroyed.data["drone_routes"] = new_drone_routes

        for customer_id in removed:
            if customer_id in destroyed.data["served"]:
                destroyed.data["served"].remove(customer_id)
            if customer_id not in destroyed.data["unserved"]:
                destroyed.data["unserved"].append(customer_id)

        self._reject_replenishment_nodes(
            destroyed,
            scope="drone_task_destroy",
        )
        self._rebuild_solution(destroyed)

        context = {
            "reason": "drone_task",
            "removed_count": len(removed),
            "removed_customers": list(removed),
            "requested_remove_count": requested_remove_count,
            "resolved_remove_count": remove_count,
            "actual_removed_count": len(removed),
            "removed_tasks": removed_tasks,
            "selected_task_indices": sorted(selected_indices),
        }
        return destroyed, removed, context

    def _customer_service_time_in_solution(
        self,
        sol: Solution,
        customer_id: int,
    ) -> float:
        """
        返回客户在当前解中的服务开始时间。
        无人机客户优先读取无人机任务 evaluation；卡车客户读取卡车重算评价。
        """
        if "drone_routes" not in sol.data:
            raise ValueError("solution missing required key: drone_routes")
        if "truck_routes" not in sol.data:
            raise ValueError("solution missing required key: truck_routes")
        if "phase_start_state_by_truck" not in sol.data:
            raise ValueError("solution missing required key: phase_start_state_by_truck")
        if "validation_report" not in sol.data:
            raise ValueError("solution missing required key: validation_report")
        if not isinstance(sol.data["drone_routes"], list):
            raise TypeError('sol.data["drone_routes"] must be a list')
        if not isinstance(sol.data["truck_routes"], dict):
            raise TypeError('sol.data["truck_routes"] must be a dict')
        if customer_id not in self.customers:
            raise ValueError(f"customer {customer_id} is not in self.customers")

        for task_index, task in enumerate(sol.data["drone_routes"]):
            if not isinstance(task, dict):
                raise TypeError(f"drone task {task_index} must be a dict")
            if "customer" not in task:
                raise ValueError(f"drone task {task_index} missing required key: customer")
            if task["customer"] == customer_id:
                if "evaluation" not in task:
                    raise ValueError(f"drone task {task_index} missing required key: evaluation")
                evaluation = task["evaluation"]
                if not isinstance(evaluation, dict):
                    raise TypeError(f"drone task {task_index} evaluation must be a dict")
                if "customer_service_start" in evaluation:
                    return evaluation["customer_service_start"]
                return evaluation["customer_arrival_time"]

        validation_report = sol.data["validation_report"]
        if not isinstance(validation_report, dict):
            raise TypeError('sol.data["validation_report"] must be a dict')
        truck_evaluations = validation_report["truck_evaluations"]
        if not isinstance(truck_evaluations, dict):
            raise TypeError('sol.data["validation_report"]["truck_evaluations"] must be a dict')

        for truck_id, route in sol.data["truck_routes"].items():
            if not isinstance(route, list):
                raise TypeError(f"truck route of truck {truck_id} must be a list")
            if customer_id not in route:
                continue
            truck_eval = truck_evaluations[truck_id]
            if not isinstance(truck_eval, dict):
                raise TypeError(f"truck evaluation of truck {truck_id} must be a dict")
            if "service_start_times" in truck_eval:
                return truck_eval["service_start_times"][customer_id]
            return truck_eval["arrival_times"][customer_id]

        raise ValueError(f"customer {customer_id} is not served in current solution")

    def _time_window_removal_score(
        self,
        sol: Solution,
        customer_id: int,
    ) -> float:
        """
        计算客户被时间窗算子移除的优先级。
        分数越大，越应该被时间窗移除算子删除。
        """
        if customer_id not in self.customers:
            raise ValueError(f"customer {customer_id} is not in self.customers")

        customer = self.customers[customer_id]
        service_time = self._customer_service_time_in_solution(sol, customer_id)
        latest = customer["latest"]
        earliest = customer["earliest"]

        lateness = max(0.0, service_time - latest)
        priority_score = self._customer_priority_score(customer_id)
        delay_score = lateness * priority_score
        time_window_width = latest - earliest
        if time_window_width <= 0:
            raise ValueError(
                f"customer {customer_id} has invalid time window: "
                f"earliest={earliest}, latest={latest}"
            )

        tightness_score = 1.0 / time_window_width#“时间窗紧张程度”。时间窗越窄，说明客户越难安排，tightness_score 越大。
        early_window_score = 1.0 / (1.0 + max(0.0, earliest))

        return (
            10.0 * delay_score
            + 5.0 * tightness_score
            + 2.0 * early_window_score
        )

    def _remove_time_window(self, sol: Solution, x_ratio: float):
        """
        时间窗移除算子。
        优先移除迟到严重、时间窗紧、且处于更早时间窗阶段的客户。
        """
        if x_ratio <= 0:
            raise ValueError(f"x_ratio must be positive, got {x_ratio}")
        destroyed = sol.deepcopy()
        candidates = self._collect_nonkey_customers(destroyed)

        if len(candidates) == 0:
            return destroyed, set(), {
                "reason": "time_window_empty",
                "removed_count": 0,
            }
        requested_remove_count = max(
            1,
            math.ceil(x_ratio * len(candidates)),
        )
        remove_count = _resolve_destroy_count(
            len(candidates),
            requested_remove_count,
            self.diagnostic_min_destroy_size,
        )
        scored_customers = []
        for customer_id in candidates:
            score = self._time_window_removal_score(
                destroyed,
                customer_id,
            )
            scored_customers.append((score, customer_id))
        scored_customers.sort(
            key=lambda item: item[0],
            reverse=True,
        )
        removed = {
            customer_id
            for score, customer_id in scored_customers[:remove_count]
        }
        self._apply_removals(
            destroyed,
            removed,
            allow_key=False,
        )
        self._rebuild_solution(destroyed)
        context = {
            "reason": "time_window",
            "removed_count": len(removed),
            "removed_customers": list(removed),
            "requested_remove_count": requested_remove_count,
            "resolved_remove_count": remove_count,
            "actual_removed_count": len(removed),
            "time_window_scores": {
                customer_id: score
                for score, customer_id in scored_customers[:remove_count]
            },
        }
        return destroyed, removed, context

    def _edge_arrival_time(
        self,
        truck_eval: Dict[str, Any],
        u: int,
    ) -> float:
        """返回卡车到达边起点 u 的时间，用于判断边 u -> v 所在风险周期。"""
        current_time = truck_eval["arrival_times"][u]
        return current_time

    def _risk_edge_score(
        self,
        truck_eval: Dict[str, Any],
        u: int,
        v: int,
    ) -> Dict[str, Any]:
        """计算卡车边 u -> v 的道路风险分数。"""
        current_time = self._edge_arrival_time(
            truck_eval=truck_eval,
            u=u,
        )
        period_index = get_period_index(
            current_time,
            self.periods,
            self.period_length,
        )
        period_key = self.periods[period_index]
        risk_level = self.risk_matrix[period_key][u][v]
        distance = self.distance_matrix[u][v]
        risk_score = risk_level * (distance / ROAD_RISK_DISTANCE_SCALE)

        if risk_level == 4:
            risk_score += 1e6

        return {
            "u": u,
            "v": v,
            "period_index": period_index,
            "period": period_key,
            "current_time": current_time,
            "risk_level": risk_level,
            "distance": distance,
            "risk_score": risk_score,
        }

    def _remove_risk(self, sol: Solution, x_ratio: float):
        """
        风险移除算子。
        从当前解中识别高风险卡车边，并移除其相邻客户。
        删除结构后统一调用 _rebuild_solution 更新派生信息。
        """
        if x_ratio <= 0:
            raise ValueError(f"x_ratio must be positive, got {x_ratio}")

        destroyed = sol.deepcopy()
        required_solution_keys = {
            "truck_routes",
            "drone_routes",
            "phase_start_state_by_truck",
            "unserved",
            "served",
            "cost",
            "feasible",
            "validation_report",
            "full_validation_report",
            "drone_period_usage",
            "segment_usage",
        }
        missing_solution_keys = required_solution_keys - set(destroyed.data)
        if missing_solution_keys:
            raise ValueError(
                f"solution missing required keys: {sorted(missing_solution_keys)}"
            )
        if not isinstance(destroyed.data["truck_routes"], dict):
            raise TypeError('destroyed.data["truck_routes"] must be a dict')
        if not isinstance(destroyed.data["drone_routes"], list):
            raise TypeError('destroyed.data["drone_routes"] must be a list')
        if not isinstance(destroyed.data["unserved"], list):
            raise TypeError('destroyed.data["unserved"] must be a list')
        if not isinstance(destroyed.data["served"], set):
            raise TypeError('destroyed.data["served"] must be a set')

        # 风险评分依赖完整卡车时间线，先统一刷新派生信息，避免使用旧 validation_report。
        self._rebuild_solution(destroyed)

        candidates = set(self._collect_nonkey_customers(destroyed))
        if not candidates:
            return destroyed, set(), {
                "reason": "risk_empty",
                "removed_count": 0,
            }

        requested_remove_count = max(
            1,
            math.ceil(x_ratio * len(candidates)),
        )
        remove_count = _resolve_destroy_count(
            len(candidates),
            requested_remove_count,
            self.diagnostic_min_destroy_size,
        )

        edge_scores = []
        truck_evaluations = destroyed.data["validation_report"]["truck_evaluations"]
        for truck_id, route in destroyed.data["truck_routes"].items():
            truck_eval = truck_evaluations[truck_id]

            for edge_idx in range(len(route) - 1):
                u = route[edge_idx]
                v = route[edge_idx + 1]
                # 如果前序边已经阻断，卡车不会到达后续 u，后续边没有可用的当前周期。
                # 这里停止扫描该车后续边；已阻断边本身已经被计入 edge_scores。
                if u not in truck_eval["arrival_times"]:
                    break
                edge_info = self._risk_edge_score(
                    truck_eval=truck_eval,
                    u=u,
                    v=v,
                )
                edge_info["truck_id"] = truck_id
                edge_info["edge_idx"] = edge_idx
                edge_scores.append(edge_info)

        if not edge_scores:
            return destroyed, set(), {
                "reason": "risk_no_edges",
                "removed_count": 0,
            }

        edge_scores.sort(
            key=lambda item: item["risk_score"],
            reverse=True,
        )

        removed = set()
        selected_edges = []

        # 从高风险边及其前后相邻位置中选择可删除客户。
        for edge_info in edge_scores:
            truck_id = edge_info["truck_id"]
            edge_idx = edge_info["edge_idx"]
            route = destroyed.data["truck_routes"][truck_id]
            before_count = len(removed)
            neighbor_positions = [
                edge_idx - 1,
                edge_idx,
                edge_idx + 1,
                edge_idx + 2,
            ]

            for pos in neighbor_positions:
                if pos < 0 or pos >= len(route):
                    continue

                node = route[pos]
                if node in candidates:
                    trial_removed = set(removed)
                    trial_removed.add(node)
                    if self._removal_set_is_risk_feasible(
                        sol=destroyed,
                        removed_customers=trial_removed,
                    ):
                        removed.add(node)

                if len(removed) >= remove_count:
                    break
            if len(removed) > before_count:
                selected_edges.append(edge_info)

            if len(removed) >= remove_count:
                break

        if not removed:
            return destroyed, set(), {
                "reason": "risk_no_risk_feasible_removal",
                "removed_count": 0,
                "requested_remove_count": requested_remove_count,
                "resolved_remove_count": remove_count,
                "actual_removed_count": 0,
                "risk_bridge_filter_enabled": True,
                "risk_bridge_filtered_count": remove_count,
                "selected_edges": selected_edges,
                "top_risk_edges": edge_scores[:min(5, len(edge_scores))],
            }

        # 防止一次加入超过 remove_count 个客户
        """if len(removed) > remove_count:
            removed_list = list(removed)
            self.rnd.shuffle(removed_list)
            removed = set(removed_list[:remove_count])"""

        self._apply_removals(
            destroyed,
            removed,
            allow_key=False,
        )
        self._rebuild_solution(destroyed)

        context = {
            "reason": "risk",
            "removed_count": len(removed),
            "removed_customers": list(removed),
            "requested_remove_count": requested_remove_count,
            "resolved_remove_count": remove_count,
            "actual_removed_count": len(removed),
            "risk_bridge_filter_enabled": True,
            "risk_bridge_filtered_count": remove_count - len(removed),
            "selected_edges": selected_edges,
            "top_risk_edges": edge_scores[:min(5, len(edge_scores))],
        }

        return destroyed, removed, context

    def _apply_removals(
        self,
        sol: Solution,
        removed: Set[int],
        allow_key: bool = False,
    ) -> None:
        """
        从当前解中删除一批客户，只修改解的结构，不重算成本和时间线。
        修改范围仅包括：
        1. sol.data["truck_routes"]
        2. sol.data["drone_routes"]
        3. sol.data["served"]
        4. sol.data["unserved"]
        注意：
        删除后必须由外部调用 _rebuild_solution(sol)，本函数不负责重算。
        """
        if not isinstance(removed, set):
            raise TypeError("removed must be a Set[int]")

        required_solution_keys = {
            "truck_routes",
            "drone_routes",
            "phase_start_state_by_truck",
            "served",
            "unserved",
        }
        missing_solution_keys = required_solution_keys - set(sol.data)
        if missing_solution_keys:
            raise ValueError(
                f"solution missing required keys: {sorted(missing_solution_keys)}"
            )
        if not isinstance(sol.data["truck_routes"], dict):
            raise TypeError('sol.data["truck_routes"] must be a dict')
        if not isinstance(sol.data["drone_routes"], list):
            raise TypeError('sol.data["drone_routes"] must be a list')
        if not isinstance(sol.data["served"], set):
            raise TypeError('sol.data["served"] must be a set')
        if not isinstance(sol.data["unserved"], list):
            raise TypeError('sol.data["unserved"] must be a list')
        # 关键节点不能被普通删除算子删除：
        # 仓库起点、仓库终点、补货点，以及所有无人机任务的发射点和回收点。
        key_nodes = self._key_nodes(sol)

        if allow_key:
            actual_removed = set(removed)
        else:
            actual_removed = {
                customer_id
                for customer_id in removed
                if customer_id not in key_nodes
            }
        forbidden_removed = (
            self._phase_locked_customer_ids(sol)
            | self._phase_completed_customer_ids(sol)
            | self._phase_future_dynamic_customer_ids(sol)
        )
        if actual_removed & forbidden_removed:
            raise ValueError(
                "removal contains locked/completed/future customers: "
                f"{sorted(actual_removed & forbidden_removed)}"
            )

        # 删除服务 actual_removed 中客户的无人机任务。
        # launch_node 和 recovery_node 不在这里删除，它们是否删除由卡车路径删除逻辑决定。
        new_drone_routes = []
        for task_index, task in enumerate(sol.data["drone_routes"]):
            if not isinstance(task, dict):
                raise TypeError(f"drone task {task_index} must be a dict")
            if "customer" not in task:
                raise ValueError(f"drone task {task_index} missing required key: customer")
            #如果当前任务服务的客户属于被移除的客户集合 actual_removed，则跳过该任务（即不加入 new_drone_routes，实现删除）。
            if task["customer"] in actual_removed:
                continue
            new_drone_routes.append(task)
        sol.data["drone_routes"] = new_drone_routes

        # 删除卡车路径中的客户。
        # If a removed customer follows 999, remove that 999 with it.
        for truck_id, route in sol.data["truck_routes"].items():
            if not isinstance(route, list):
                raise TypeError(f"truck route of truck {truck_id} must be a list")

            remove_positions = set()#初始化 remove_positions 集合，用于记录需要删除的位置索引

            for index, node in enumerate(route):
                if node not in actual_removed:
                    continue

                if not allow_key and node in key_nodes:
                    continue

                remove_positions.add(index)

                if node not in self.customers:
                    raise ValueError(
                        f"truck route of truck {truck_id} contains removed node "
                        f"{node}, but it is not in self.customers"
                )
        #在删除节点之前，调用 _shift_drone_task_indices_after_truck_delete，更新该卡车上所有无人机任务的 launch_idx 和 recovery_idx。
            self._shift_drone_task_indices_after_truck_delete(
                sol=sol,
                truck_id=truck_id,
                removed_positions=remove_positions,
            )
        #使用列表推导式重建路径，跳过所有 remove_positions 中的索引，完成删除。
            sol.data["truck_routes"][truck_id] = [
                node
                for index, node in enumerate(route)
                if index not in remove_positions
            ]

        # 更新 served：被删除客户不再视为已服务。
        sol.data["served"].difference_update(actual_removed)#从 served 集合中移除被删除的客户

        # 更新 unserved：把被删除的真实客户加入未服务集合，不重复添加。
        unserved = sol.data["unserved"]
        non_customer_nodes = {
            self.depot_start,
            self.depot_end,
            self.replenishment_node,
        }
        for customer_id in actual_removed:
            if customer_id not in self.customers:
                continue
            if customer_id in non_customer_nodes:
                continue
            if customer_id not in unserved:
                unserved.append(customer_id)
        # 清理 unserved 与 served 的交集，避免同一个客户同时处于两种状态。
        served = sol.data["served"]
        sol.data["unserved"] = [
            customer_id
            for customer_id in sol.data["unserved"]
            if customer_id not in served
        ]
        self._reject_replenishment_nodes(
            sol,
            scope="customer_destroy",
        )
        self._refresh_static_phase_start_state_if_needed(sol)
        return None

    def _all_truck_insert_deltas(
        self,
        sol: Solution,
        customer_id: int,
    ) -> List[Dict[str, Any]]:
        """返回客户的全部卡车局部插入候选；只做局部评价，不修改解。"""
        positions = self._all_truck_insert_positions(sol, customer_id)
        if len(positions) == 0:
            return []
        return self._k_best_truck_deltas(
            sol,
            customer_id,
            k=len(positions),
            positions=positions,
        )

    def _all_drone_insert_deltas(
        self,
        sol: Solution,
        customer_id: int,
    ) -> List[Dict[str, Any]]:
        """返回客户的全部无人机局部插入候选；只做局部评价，不修改解。"""
        positions = self._all_drone_insert_positions(sol, customer_id)
        if len(positions) == 0:
            return []
        return self._k_best_drone_trip_deltas(
            sol,
            customer_id,
            k=len(positions),
            positions=positions,
        )

    def _all_insert_deltas(
        self,
        sol: Solution,
        customer_id: int,
    ) -> List[Dict[str, Any]]:
        """合并客户的全部卡车和无人机局部候选，并按 delta_cost 升序排序。"""
        profile_start = time.perf_counter() if _profile_enabled() else None
        moves = self._all_truck_insert_deltas(sol, customer_id)
        if self.allow_drone_insertions:
            moves += self._all_drone_insert_deltas(sol, customer_id)
        moves.sort(key=lambda move: move["delta_cost"])
        if profile_start is not None:
            _profile_count("all_insert_deltas_calls")
            _profile_count("all_insert_deltas_returned_moves", len(moves))
            _profile_add(
                "all_insert_deltas_seconds",
                time.perf_counter() - profile_start,
            )
        return moves

    def _customer_time_window_bounds(self, customer_id: int) -> tuple[float, float]:
        if customer_id not in self.customers:
            raise ValueError(f"customer {customer_id} is not in self.customers")
        customer = self.customers[customer_id]
        for key in ("earliest", "latest"):
            if key not in customer:
                raise ValueError(f"customer {customer_id} missing required field: {key}")
            value = customer[key]
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise TypeError(
                    f"customer {customer_id} {key} must be numeric, "
                    f"got {type(value).__name__}"
                )
        return float(customer["earliest"]), float(customer["latest"])

    def _nearest_route_customer_time_windows(
        self,
        route: List[int],
        insert_pos: int,
        truck_id: int,
    ) -> List[tuple[float, float]]:
    #找出某个插入位置左右两侧最近真实客户的 earliest/latest 时间窗边界。
        non_customer_nodes = {
            self.depot_start,
            self.depot_end,
            self.replenishment_node,
        }
        neighbor_time_windows = []#后面会把左右最近客户的时间窗放进去。
        #第一段循环：向左找最近客户
        for index in range(insert_pos - 1, -1, -1):
            node = route[index]
            if node in non_customer_nodes:
                continue
            if node not in self.customers:
                raise ValueError(
                    f"truck route of truck {truck_id} contains unknown customer {node}"
                )
            neighbor_time_windows.append(self._customer_time_window_bounds(node))
            break

        for index in range(insert_pos, len(route)):
            node = route[index]
            if node in non_customer_nodes:
                continue
            if node not in self.customers:
                raise ValueError(
                    f"truck route of truck {truck_id} contains unknown customer {node}"
                )
            neighbor_time_windows.append(self._customer_time_window_bounds(node))
            break

        return neighbor_time_windows

    def _truck_insert_position_matches_time_window(
            self,
            route,
            insert_pos,
            customer_id,
            truck_id,
    ) -> bool:
        return True

    def _copy_solution_for_insert_trial(self, sol: Solution) -> Solution:
        required_solution_keys = {
            "truck_routes",
            "drone_routes",
            "next_drone_task_id",
            "phase_start_state_by_truck",
            "unserved",
            "served",
            "cost",
            "feasible",
            "validation_report",
            "full_validation_report",
            "drone_period_usage",
            "segment_usage",
        }
        missing_solution_keys = required_solution_keys - set(sol.data)
        if missing_solution_keys:
            raise ValueError(
                f"solution missing required keys: {sorted(missing_solution_keys)}"
            )
        if not isinstance(sol.data["truck_routes"], dict):
            raise TypeError('sol.data["truck_routes"] must be a dict')
        if not isinstance(sol.data["drone_routes"], list):
            raise TypeError('sol.data["drone_routes"] must be a list')
        if not isinstance(sol.data["unserved"], list):
            raise TypeError('sol.data["unserved"] must be a list')
        if not isinstance(sol.data["served"], set):
            raise TypeError('sol.data["served"] must be a set')
        if not isinstance(sol.data["drone_period_usage"], dict):
            raise TypeError('sol.data["drone_period_usage"] must be a dict')
        if not isinstance(sol.data["segment_usage"], dict):
            raise TypeError('sol.data["segment_usage"] must be a dict')
        if not isinstance(sol.data["phase_start_state_by_truck"], dict):
            raise TypeError('sol.data["phase_start_state_by_truck"] must be a dict')

        truck_routes = {}
        for truck_id, route in sol.data["truck_routes"].items():
            if not isinstance(route, list):
                raise TypeError(f"truck route of truck {truck_id} must be a list")
            truck_routes[truck_id] = list(route)

        trial_data = {
            "truck_routes": truck_routes,
            "drone_routes": [
                copy.deepcopy(task)
                for task in sol.data["drone_routes"]
            ],
            "unserved": list(sol.data["unserved"]),
            "served": set(sol.data["served"]),
            "cost": sol.data["cost"],
            "feasible": sol.data["feasible"],
            "validation_report": sol.data["validation_report"],
            "full_validation_report": sol.data["full_validation_report"],
            "drone_period_usage": dict(sol.data["drone_period_usage"]),
            "segment_usage": dict(sol.data["segment_usage"]),
            "next_drone_task_id": sol.data["next_drone_task_id"],
            "phase_start_state_by_truck": copy.deepcopy(
                sol.data["phase_start_state_by_truck"]
            ),
        }
        if "cost_info" in sol.data:
            trial_data["cost_info"] = sol.data["cost_info"]
        if "phase_locked_drone_intervals" in sol.data:
            if not isinstance(sol.data["phase_locked_drone_intervals"], list):
                raise TypeError('sol.data["phase_locked_drone_intervals"] must be a list')
            trial_data["phase_locked_drone_intervals"] = [
                copy.deepcopy(interval)
                for interval in sol.data["phase_locked_drone_intervals"]
            ]
        phase_set_keys = {
            "phase_completed_customer_ids",
            "phase_locked_customer_ids",
            "phase_locked_drone_task_ids",
            "phase_future_dynamic_customer_ids",
            "phase_repair_pool",
        }
        for key in phase_set_keys:
            if key in sol.data:
                if not isinstance(sol.data[key], set):
                    raise TypeError(f'sol.data["{key}"] must be a set')
                trial_data[key] = set(sol.data[key])
        return Solution(trial_data)

    def _refresh_static_phase_start_state_if_needed(self, sol: Solution) -> None:
        """ALNS 插入/删除客户、加入无人机任务后，
卡车路线和无人机任务变了，
静态阶段的初始装载量也必须同步变化。"""
        if "phase_start_state_by_truck" not in sol.data:
            raise ValueError("solution missing required key: phase_start_state_by_truck")
        phase_start_state_by_truck = sol.data["phase_start_state_by_truck"]
        if not isinstance(phase_start_state_by_truck, dict):
            raise TypeError('sol.data["phase_start_state_by_truck"] must be a dict')

        should_refresh = False
        for truck_id in sol.data["truck_routes"]:
            if truck_id not in phase_start_state_by_truck:
                raise ValueError(f"phase_start_state_by_truck missing truck_id {truck_id}")
            start_state = phase_start_state_by_truck[truck_id]
            required_start_state_keys = {
                "anchor_node",
                "anchor_time",
                "initial_basic_load",
                "initial_emergency_load",
            }
            missing_start_state_keys = required_start_state_keys - set(start_state)
            if missing_start_state_keys:
                raise ValueError(
                    f"phase_start_state_by_truck[{truck_id}] missing required keys: "
                    f"{sorted(missing_start_state_keys)}"
                )
            if (
                start_state["anchor_node"] == self.depot_start
                and start_state["anchor_time"] == 0.0
            ):
                should_refresh = True

        if should_refresh:
            refresh_depot_phase_start_state(
                solution=sol.data,
                customers=self.customers,
                depot_start=self.depot_start,
            )

    def _apply_insert_move_on_copy_if_feasible(
        self,
        sol: Solution,
        move: Dict[str, Any],
    ) -> Tuple[Optional[Solution], Optional[Dict[str, Any]]]:
        """
        在解副本上执行插入并 rebuild。
        返回 None 表示该局部候选在完整重算后不可行；结构错误仍直接抛出。
        """
        if move.get("mode") == "drone" and self._drone_move_overlaps_existing_tasks(sol, move):
            return None, self._drone_time_overlap_failure_details(
                [
                    "candidate drone task overlaps an existing task before rebuild"
                ]
            )
        if move.get("mode") == "truck":
            for required_key in ("truck_id", "insert_pos", "insert_nodes"):
                if required_key not in move:
                    raise ValueError(f"truck move missing required key: {required_key}")
            if not self._truck_insert_local_risk_feasible(
                sol=sol,
                truck_id=move["truck_id"],
                insert_pos=move["insert_pos"],
                insert_nodes=move["insert_nodes"],
            ):
                return None, {
                    "rejection_reason": "truck_insert_local_blocked_edge",
                    "full_validation_violations": [],
                    "truck_evaluation_violations": [],
                    "lightweight_violations": [
                        "truck insertion creates a local blocked edge"
                    ],
                    "detail": {
                        "truck_id": move["truck_id"],
                        "insert_pos": move["insert_pos"],
                        "insert_nodes": list(move["insert_nodes"]),
                    },
                }

        trial = self._copy_solution_for_insert_trial(sol)
        if move["mode"] == "truck":
            try:
                self._insert_as_truck(trial, move, rebuild=True)
            except ValueError as exc:
                if self._message_is_blocked_edge_violation(exc):
                    return None, self._truck_blocked_edge_failure_details(
                        [str(exc)]
                    )
                raise
        elif move["mode"] == "drone":
            self._apply_drone_replacement(trial, move, rebuild=True)
        else:
            raise ValueError(f"Unknown insert move mode: {move['mode']}")

        drone_time_check = self._validate_drone_time_nonoverlap(trial)
        if not drone_time_check["valid"]:
            return None, self._drone_time_overlap_failure_details(
                drone_time_check["violations"]
            )

        if not trial.data["feasible"]:
            failure_details = self._collect_post_rebuild_failure_details(trial)
            if self._solution_has_blocked_edge_violation(trial):
                failure_details["rejection_reason"] = (
                    "truck_insert_blocked_edge_after_rebuild"
                )
            return None, failure_details
        if self.phase_candidate_validator is not None:
            validation_result = self.phase_candidate_validator(trial)
            if not isinstance(validation_result, dict):
                raise TypeError("phase_candidate_validator must return a dict")
            if "valid" not in validation_result:
                raise ValueError("phase_candidate_validator result missing valid")
            if not isinstance(validation_result["valid"], bool):
                raise TypeError("phase_candidate_validator valid must be bool")
            if not validation_result["valid"]:
                return None, self._collect_phase_candidate_failure_details(
                    validation_result
                )
        return trial, None

    def _collect_phase_candidate_failure_details(
        self,
        validation_result: Dict[str, Any],
    ) -> Dict[str, Any]:
        if not isinstance(validation_result, dict):
            raise TypeError("phase_candidate_validator result must be a dict")
        if "valid" not in validation_result:
            raise ValueError("phase_candidate_validator result missing valid")
        if not isinstance(validation_result["valid"], bool):
            raise TypeError("phase_candidate_validator valid must be bool")
        if validation_result["valid"] is True:
            raise ValueError("cannot collect invalid details from valid phase candidate")

        details = {
            "full_validation_violations": [],
            "truck_evaluation_violations": [],
            "lightweight_violations": [],
        }
        violations = validation_result.get("violations", [])
        if violations is None:
            violations = []
        if not isinstance(violations, list):
            raise TypeError("phase_candidate_validator violations must be a list")
        details["full_validation_violations"].extend(
            str(violation) for violation in violations
        )

        if not any(details.values()):
            details["lightweight_violations"].append(
                "phase_candidate_validator returned valid=False without violations"
            )
        return details

    def _collect_post_rebuild_failure_details(
        self,
        trial: Solution,
    ) -> Dict[str, Any]:
        if "feasible" not in trial.data:
            raise ValueError("trial solution missing required key: feasible")
        if trial.data["feasible"] is True:
            raise ValueError("cannot collect infeasible details from feasible trial")

        details = {
            "full_validation_violations": [],
            "truck_evaluation_violations": [],
            "lightweight_violations": [],
        }

        full_report = trial.data.get("full_validation_report")
        if isinstance(full_report, dict):
            violations = full_report.get("violations", [])
            if isinstance(violations, list):
                details["full_validation_violations"].extend(str(item) for item in violations)

        validation_report = trial.data.get("validation_report")
        if isinstance(validation_report, dict):
            truck_evaluations = validation_report.get("truck_evaluations", {})
            if isinstance(truck_evaluations, dict):
                for truck_id, evaluation in truck_evaluations.items():
                    if not isinstance(evaluation, dict):
                        continue
                    if evaluation.get("feasible") is False:
                        violations = evaluation.get("violations", [])
                        if isinstance(violations, list) and violations:
                            for violation in violations:
                                details["truck_evaluation_violations"].append(
                                    f"truck {truck_id}: {violation}"
                                )
                        else:
                            details["truck_evaluation_violations"].append(
                                f"truck {truck_id}: feasible=False"
                            )

        if isinstance(full_report, dict):
            lightweight_violations = full_report.get("lightweight_violations", [])
            if isinstance(lightweight_violations, list):
                details["lightweight_violations"].extend(
                    str(item) for item in lightweight_violations
                )

        if not any(details.values()):
            details["lightweight_violations"].append(
                "trial feasible=False without validation violations"
            )
        if self._solution_has_blocked_edge_violation(trial):
            details["rejection_reason"] = "truck_insert_blocked_edge_after_rebuild"
        return details

    def _record_rejected_insert_move(
        self,
        context: Dict[str, Any],
        customer_id: int,
        move: Dict[str, Any],
        reason: str,
        failure_details: Optional[Dict[str, Any]] = None,
    ) -> None:
        """记录完整 rebuild 后失败的候选，便于调试候选阶段误差。"""
        if "rejected_insert_moves" not in context:
            context["rejected_insert_moves"] = []
        context["rejected_insert_moves"].append(
            {
                "customer": customer_id,
                "mode": move["mode"],
                "truck_id": move.get("truck_id"),
                "drone_id": move.get("drone_id"),
                "delta_cost": move.get("delta_cost"),
                "reason": reason,
                "post_rebuild_failure_details": copy.deepcopy(failure_details),
            }
        )

    def _apply_first_complete_feasible_move(
        self,
        sol: Solution,
        customer_id: int,
        moves: List[Dict[str, Any]],
        context: Dict[str, Any],
    ) -> Tuple[Optional[Solution], Optional[Dict[str, Any]]]:
        #按给定顺序尝试候选，返回第一个完整 rebuild 后可行的解和 move。
        for move in moves:
            trial, failure_details = self._apply_insert_move_on_copy_if_feasible(sol, move)
            if trial is None:
                self._record_rejected_insert_move(
                    context,
                    customer_id,
                    move,
                    self._insert_rejection_reason(
                        failure_details,
                        "post_rebuild_infeasible",
                    ),
                    failure_details,
                )
                continue
            return trial, move
        return None, None

    """def _apply_best_complete_feasible_move(
            self,
            sol: Solution,
            customer_id: int,
            moves: List[Dict[str, Any]],
            context: Dict[str, Any],
    ) -> Tuple[Optional[Solution], Optional[Dict[str, Any]]]:
        #遍历所有候选，返回完整 rebuild 后真实 total cost 最低的可行解和 move。
        best_trial = None
        best_move = None
        best_cost = None

        for move in moves:
            trial, failure_details = self._apply_insert_move_on_copy_if_feasible(sol, move)
            if trial is None:
                self._record_rejected_insert_move(
                    context,
                    customer_id,
                    move,
                    self._insert_rejection_reason(
                        failure_details,
                        "post_rebuild_infeasible",
                    ),
                    failure_details,
                )
                continue

            if "cost" not in trial.data:
                raise ValueError("trial solution missing cost after rebuild")

            trial_cost = trial.data["cost"]
            if best_cost is None or trial_cost < best_cost:
                best_trial = trial
                best_move = move
                best_cost = trial_cost

        return best_trial, best_move"""

    def _repair_customer_pool(
        self,
        sol: Solution,
        removed: Set[int],
    ) -> Set[int]:
        if not isinstance(removed, set):
            raise TypeError("removed must be a Set[int]")
        required_solution_keys = {
            "truck_routes",
            "drone_routes",
            "next_drone_task_id",
            "phase_start_state_by_truck",
            "unserved",
            "served",
        }
        missing_solution_keys = required_solution_keys - set(sol.data)
        if missing_solution_keys:
            raise ValueError(
                f"solution missing required keys: {sorted(missing_solution_keys)}"
            )
        if not isinstance(sol.data["truck_routes"], dict):
            raise TypeError('sol.data["truck_routes"] must be a dict')
        if not isinstance(sol.data["drone_routes"], list):
            raise TypeError('sol.data["drone_routes"] must be a list')
        if not isinstance(sol.data["unserved"], list):
            raise TypeError('sol.data["unserved"] must be a list')
        if not isinstance(sol.data["served"], set):
            raise TypeError('sol.data["served"] must be a set')
        if not isinstance(sol.data["phase_start_state_by_truck"], dict):
            raise TypeError('sol.data["phase_start_state_by_truck"] must be a dict')

        unserved = sol.data["unserved"]
        if len(unserved) != len(set(unserved)):
            raise ValueError(f'sol.data["unserved"] contains duplicates: {unserved}')

        pool = set(removed) | set(unserved)
        unserved_set = set(unserved)
        locked_customer_ids = self._phase_locked_customer_ids(sol)
        completed_customer_ids = self._phase_completed_customer_ids(sol)
        future_dynamic_customer_ids = self._phase_future_dynamic_customer_ids(sol)
        forbidden_repair_customers = (
            locked_customer_ids
            | completed_customer_ids
            | future_dynamic_customer_ids
        )
        if pool & forbidden_repair_customers:
            raise ValueError(
                "repair pool contains locked/completed/future customers: "
                f"{sorted(pool & forbidden_repair_customers)}"
            )
        for customer_id in pool:
            if isinstance(customer_id, bool) or not isinstance(customer_id, int):
                raise TypeError(
                    f"repair pool customer id must be int, got {type(customer_id).__name__}"
                )
            if customer_id not in self.customers:
                raise ValueError(f"repair pool customer {customer_id} is not in self.customers")
            if customer_id not in unserved_set:
                raise ValueError(
                    f"repair pool customer {customer_id} is not in sol.data['unserved']; "
                    f"removed={sorted(removed)}, unserved={unserved}"
                )
            if customer_id in sol.data["served"]:
                raise ValueError(f"repair pool customer {customer_id} is already in served")

        for truck_id, route in sol.data["truck_routes"].items():
            if not isinstance(route, list):
                raise TypeError(f"truck route of truck {truck_id} must be a list")
            for customer_id in pool:
                if customer_id in route:
                    raise ValueError(
                        f"repair pool customer {customer_id} is already in truck route "
                        f"of truck {truck_id}"
                    )

        for task_index, task in enumerate(sol.data["drone_routes"]):
            if not isinstance(task, dict):
                raise TypeError(f"drone task {task_index} must be a dict")
            if "customer" not in task:
                raise ValueError(f"drone task {task_index} missing required key: customer")
            if task["customer"] in pool:
                raise ValueError(
                    f"repair pool customer {task['customer']} is already served by "
                    f"drone task {task_index}"
                )

        return pool

    def repair_initial_unserved_by_drone(
        self,
        sol: Solution,
    ) -> Tuple[Solution, Dict[str, Any]]:
        required_solution_keys = {
            "truck_routes",
            "drone_routes",
            "next_drone_task_id",
            "phase_start_state_by_truck",
            "unserved",
            "served",
            "cost",
            "feasible",
            "validation_report",
            "full_validation_report",
            "drone_period_usage",
            "segment_usage",
        }
        missing_solution_keys = required_solution_keys - set(sol.data)
        if missing_solution_keys:
            raise ValueError(
                f"solution missing required keys: {sorted(missing_solution_keys)}"
            )
        if not isinstance(sol.data["unserved"], list):
            raise TypeError('sol.data["unserved"] must be a list')

        candidate = sol.deepcopy()
        initial_pool = self._repair_customer_pool(candidate, set())
        before_unserved = list(candidate.data["unserved"])
        context = {
            "rejected_insert_moves": [],
            "initial_drone_repair_insertions": [],
        }

        for customer_id in list(before_unserved):
            if customer_id not in initial_pool:
                raise ValueError(
                    f"initial unserved customer {customer_id} missing from repair pool"
                )
            if customer_id not in candidate.data["unserved"]:
                continue
            if customer_id not in self.customers:
                raise ValueError(f"customer {customer_id} is not in self.customers")

            drone_moves = self._all_drone_insert_deltas(candidate, customer_id)
            trial, move = self._apply_first_complete_feasible_move(
                candidate,
                customer_id,
                drone_moves,
                context,
            )
            if trial is None:
                continue

            candidate = trial
            context["initial_drone_repair_insertions"].append(
                {
                    "customer": customer_id,
                    "mode": move["mode"],
                    "truck_id": move["truck_id"],
                    "drone_id": move["drone_id"],
                    "launch_node": move["launch_node"],
                    "recovery_node": move["recovery_node"],
                    "delta_cost": move["delta_cost"],
                }
            )
            self._repair_customer_pool(candidate, set())

        report = {
            "before_unserved": before_unserved,
            "after_unserved": list(candidate.data["unserved"]),
            "assigned_count": len(context["initial_drone_repair_insertions"]),
            "assigned_customers": [
                item["customer"]
                for item in context["initial_drone_repair_insertions"]
            ],
            "insertions": context["initial_drone_repair_insertions"],
            "rejected_insert_moves_count": len(context["rejected_insert_moves"]),
        }
        candidate.data["initial_drone_repair_report"] = copy.deepcopy(report)
        return candidate, report

    def _repair_greedy(
            self,
            sol: Solution,
            removed: Set[int],
            context: Dict[str, Any],
    ) -> Solution:
        """
        ???????

        ??????????????????????? rebuild?
        ?????????????????????? rejected_insert_moves?
        ??????????????????
        """
        profile_start = time.perf_counter() if _profile_enabled() else None
        candidate = sol.deepcopy()
        pool = self._repair_customer_pool(candidate, removed)
        if len(pool) == 0:
            _profile_finish_timed_call("repair_greedy", profile_start)
            return candidate

        while pool:
            ranked_moves = []
            for customer_id in list(pool):
                for move in self._all_insert_deltas(candidate, customer_id):
                    ranked_moves.append((move["delta_cost"], customer_id, move))

            ranked_moves.sort(key=lambda item: item[0])
            if not ranked_moves:
                break

            accepted = False
            for _, customer_id, move in ranked_moves:
                trial, failure_details = self._apply_insert_move_on_copy_if_feasible(candidate, move)
                if trial is None:
                    self._record_rejected_insert_move(
                        context,
                        customer_id,
                        move,
                        self._insert_rejection_reason(
                            failure_details,
                            "post_rebuild_infeasible",
                        ),
                        failure_details,
                    )
                    continue
                candidate = trial
                pool.remove(customer_id)
                accepted = True
                break

            if not accepted:
                break

        _profile_finish_timed_call("repair_greedy", profile_start)
        return candidate

    def _repair_regret2(
        self,
        sol: Solution,
        removed: Set[int],
        context: Dict[str, Any],
    ) -> Solution:
        """
        Regret-2 ?????

        ?????????? regret ??????? rebuild ????????
        """
        profile_start = time.perf_counter() if _profile_enabled() else None
        cand = sol.deepcopy()
        pool = self._repair_customer_pool(cand, removed)

        while pool:
            best_customer = None
            best_trial = None
            best_move = None
            best_regret = -float("inf")
            best_first_cost = float("inf")

            for customer_id in list(pool):
                feasible_pairs = []
                for move in self._all_insert_deltas(cand, customer_id):
                    trial, failure_details = self._apply_insert_move_on_copy_if_feasible(cand, move)
                    if trial is None:
                        self._record_rejected_insert_move(
                            context,
                            customer_id,
                            move,
                            self._insert_rejection_reason(
                                failure_details,
                                "post_rebuild_infeasible",
                            ),
                            failure_details,
                        )
                        continue
                    feasible_pairs.append((move, trial))
                    if len(feasible_pairs) >= 2:
                        break

                if not feasible_pairs:
                    continue

                first_move, first_trial = feasible_pairs[0]
                first_cost = first_move["delta_cost"]
                if not isinstance(first_cost, (int, float)):
                    raise TypeError(
                        f"move delta_cost must be numeric for customer {customer_id}, got {first_cost}"
                    )

                if len(feasible_pairs) >= 2:
                    second_cost = feasible_pairs[1][0]["delta_cost"]
                    if not isinstance(second_cost, (int, float)):
                        raise TypeError(
                            f"second move delta_cost must be numeric for customer {customer_id}, got {second_cost}"
                        )
                    regret = second_cost - first_cost
                else:
                    regret = 0.0

                if (
                    regret > best_regret
                    or (
                        regret == best_regret
                        and first_cost < best_first_cost
                    )
                ):
                    best_customer = customer_id
                    best_trial = first_trial
                    best_move = first_move
                    best_regret = regret
                    best_first_cost = first_cost

            if best_trial is None:
                break

            cand = best_trial
            pool.remove(best_customer)

        _profile_finish_timed_call("repair_regret2", profile_start)
        return cand

    def _repair_priority(
        self,
        sol: Solution,
        removed: Set[int],
        context: Dict[str, Any],
    ) -> Solution:
        """
        ????????
        按优先级、latest 和 earliest 排序修复客户。
        ???????????????? unserved ??
        """
        profile_start = time.perf_counter() if _profile_enabled() else None
        cand = sol.deepcopy()

        if not isinstance(removed, set):
            raise TypeError("removed must be a Set[int]")

        required_solution_keys = {
            "truck_routes",
            "drone_routes",
            "phase_start_state_by_truck",
            "unserved",
            "served",
            "cost",
            "feasible",
            "validation_report",
            "full_validation_report",
            "drone_period_usage",
            "segment_usage",
        }
        missing_solution_keys = required_solution_keys - set(cand.data)
        if missing_solution_keys:
            raise ValueError(
                f"solution missing required keys: {sorted(missing_solution_keys)}"
            )
        if not isinstance(cand.data["unserved"], list):
            raise TypeError('cand.data["unserved"] must be a list')
        if not isinstance(cand.data["served"], set):
            raise TypeError('cand.data["served"] must be a set')

        pool = list(self._repair_customer_pool(cand, removed))
        pool.sort(
            key=lambda customer_id: (
                -self._customer_priority_score(customer_id),
                self.customers[customer_id]["latest"],
                self.customers[customer_id]["earliest"],
            )
        )

        for customer_id in pool:
            moves = self._all_insert_deltas(cand, customer_id)
            if not moves:
                continue
            trial, move = self._apply_first_complete_feasible_move(
                cand,
                customer_id,
                moves,
                context,
            )
            if trial is None:
                continue
            cand = trial

        _profile_finish_timed_call("repair_priority", profile_start)
        return cand

    def _repair_risk_aware(
        self,
        sol: Solution,
        removed: Set[int],
        context: Dict[str, Any],
    ) -> Solution:
        """
        ?????????
        ? delta_cost + risk_extra_weight * road_risk_delta ???
        ????? rebuild ????????
        """
        profile_start = time.perf_counter() if _profile_enabled() else None
        cand = sol.deepcopy()
        if not isinstance(removed, set):
            raise TypeError("removed must be a Set[int]")
        if not isinstance(context, dict):
            raise TypeError("context must be a Dict[str, Any]")

        required_solution_keys = {
            "truck_routes",
            "drone_routes",
            "phase_start_state_by_truck",
            "unserved",
            "served",
            "cost",
            "feasible",
            "validation_report",
            "full_validation_report",
            "drone_period_usage",
            "segment_usage",
        }
        missing_solution_keys = required_solution_keys - set(cand.data)
        if missing_solution_keys:
            raise ValueError(
                f"solution missing required keys: {sorted(missing_solution_keys)}"
            )
        if not isinstance(cand.data["unserved"], list):
            raise TypeError('cand.data["unserved"] must be a list')
        if not isinstance(cand.data["served"], set):
            raise TypeError('cand.data["served"] must be a set')

        risk_extra_weight = 2.0
        pool = self._repair_customer_pool(cand, removed)
        context["risk_aware_insertions"] = []

        while pool:
            scored_moves = []
            for customer_id in list(pool):
                if customer_id not in self.customers:
                    raise ValueError(f"customer {customer_id} is not in self.customers")

                for move in self._all_insert_deltas(cand, customer_id):
                    if "road_risk_delta" not in move:
                        raise ValueError(
                            f"insert move missing required key: road_risk_delta, move={move}"
                        )
                    risk_aware_score = (
                        move["delta_cost"]
                        + risk_extra_weight * move["road_risk_delta"]
                    )
                    scored_moves.append((risk_aware_score, customer_id, move))

            scored_moves.sort(key=lambda item: item[0])
            if not scored_moves:
                break

            accepted = False
            for risk_aware_score, customer_id, move in scored_moves:
                trial, failure_details = self._apply_insert_move_on_copy_if_feasible(cand, move)
                if trial is None:
                    self._record_rejected_insert_move(
                        context,
                        customer_id,
                        move,
                        self._insert_rejection_reason(
                            failure_details,
                            "post_rebuild_infeasible",
                        ),
                        failure_details,
                    )
                    continue

                cand = trial
                context["risk_aware_insertions"].append(
                    {
                        "customer": customer_id,
                        "mode": move["mode"],
                        "delta_cost": move["delta_cost"],
                        "road_risk_delta": move["road_risk_delta"],
                        "risk_aware_score": risk_aware_score,
                    }
                )
                pool.remove(customer_id)
                accepted = True
                break

            if not accepted:
                break

        _profile_finish_timed_call("repair_risk_aware", profile_start)
        return cand

    def _repair_drone_first(
        self,
        sol: Solution,
        removed: Set[int],
        context: Dict[str, Any],
    ) -> Solution:
        """
        ??????????
        ????????????????????????????????
        """
        profile_start = time.perf_counter() if _profile_enabled() else None
        cand = sol.deepcopy()
        if not isinstance(removed, set):
            raise TypeError("removed must be a Set[int]")
        if not isinstance(context, dict):
            raise TypeError("context must be a Dict[str, Any]")

        required_solution_keys = {
            "truck_routes",
            "drone_routes",
            "unserved",
            "served",
            "cost",
            "feasible",
            "validation_report",
            "full_validation_report",
            "drone_period_usage",
            "segment_usage",
        }
        missing_solution_keys = required_solution_keys - set(cand.data)
        if missing_solution_keys:
            raise ValueError(
                f"solution missing required keys: {sorted(missing_solution_keys)}"
            )
        if not isinstance(cand.data["unserved"], list):
            raise TypeError('cand.data["unserved"] must be a list')
        if not isinstance(cand.data["served"], set):
            raise TypeError('cand.data["served"] must be a set')

        pool = list(self._repair_customer_pool(cand, removed))
        pool.sort(
            key=lambda customer_id: (
                -self._customer_priority_score(customer_id),
                self.customers[customer_id]["latest"],
                self.customers[customer_id]["earliest"],
            )
        )
        context["drone_first_order"] = list(pool)

        for customer_id in pool:
            if customer_id not in self.customers:
                raise ValueError(f"customer {customer_id} is not in self.customers")

            drone_moves = self._all_drone_insert_deltas(cand, customer_id)
            trial, move = self._apply_first_complete_feasible_move(
                cand,
                customer_id,
                drone_moves,
                context,
            )
            if trial is not None:
                cand = trial
                continue

            truck_moves = self._all_truck_insert_deltas(cand, customer_id)
            trial, move = self._apply_first_complete_feasible_move(
                cand,
                customer_id,
                truck_moves,
                context,
            )
            if trial is not None:
                cand = trial

        _profile_finish_timed_call("repair_drone_first", profile_start)
        return cand

    def _joint_repair_customer_order(
        self,
        sol: Solution,
        pool: Set[int],
    ) -> List[int]:
        if not isinstance(pool, set):
            raise TypeError("pool must be a set")
        risk_score_by_customer: Dict[int, float] = {customer_id: 0.0 for customer_id in pool}
        if "validation_report" not in sol.data:
            raise ValueError("solution missing required key: validation_report")
        truck_evaluations = sol.data["validation_report"].get("truck_evaluations")
        if not isinstance(truck_evaluations, dict):
            raise TypeError('sol.data["validation_report"]["truck_evaluations"] must be a dict')
        for truck_id, route in sol.data["truck_routes"].items():
            if truck_id not in truck_evaluations:
                raise ValueError(f"truck_evaluations missing truck_id {truck_id}")
            truck_eval = truck_evaluations[truck_id]
            for edge_idx in range(len(route) - 1):
                from_node = route[edge_idx]
                to_node = route[edge_idx + 1]
                if from_node not in truck_eval.get("arrival_times", {}):
                    continue
                edge_info = self._risk_edge_score(
                    truck_eval=truck_eval,
                    u=from_node,
                    v=to_node,
                )
                edge_score = float(edge_info["risk_score"])
                for customer_id in pool:
                    distance_to_edge = min(
                        float(self.distance_matrix[customer_id][from_node]),
                        float(self.distance_matrix[customer_id][to_node]),
                    )
                    related_score = edge_score / (1.0 + distance_to_edge)
                    if related_score > risk_score_by_customer[customer_id]:
                        risk_score_by_customer[customer_id] = related_score

        def sort_key(customer_id: int) -> Tuple[int, float, float, float, int]:
            if customer_id not in self.customers:
                raise ValueError(f"customer {customer_id} is not in self.customers")
            customer = self.customers[customer_id]
            if "is_static" not in customer:
                raise ValueError(f"customer {customer_id} missing required field: is_static")
            dynamic_rank = 0 if customer["is_static"] is False else 1
            priority = self._customer_priority_score(customer_id)
            service_or_penalty = self._customer_unserved_penalty(customer_id)
            if customer_id in sol.data["served"]:
                service_or_penalty += self._customer_service_time_in_solution(
                    sol,
                    customer_id,
                )
            return (
                dynamic_rank,
                -priority,
                -service_or_penalty,
                -risk_score_by_customer[customer_id],
                customer_id,
            )

        return sorted(pool, key=sort_key)

    def _joint_repair_solution_signature(self, sol: Solution) -> tuple:
        return canonical_solution_signature(sol)

    def _joint_repair_full_valid(self, sol: Solution) -> bool:
        self._rebuild_solution(sol, full_validate=True)
        report = sol.data["full_validation_report"]
        if not isinstance(report, dict):
            raise TypeError("full_validation_report must be a dict")
        return bool(report.get("valid") is True and report.get("feasible") is True)

    def _repair_joint_truck_drone(
        self,
        sol: Solution,
        removed: Set[int],
        context: Dict[str, Any],
    ) -> Solution:
        if not self.enable_joint_truck_drone_repair:
            raise ValueError(
                "_repair_joint_truck_drone called while "
                "enable_joint_truck_drone_repair=False"
            )
        if not isinstance(removed, set):
            raise TypeError("removed must be a Set[int]")
        if not isinstance(context, dict):
            raise TypeError("context must be a Dict[str, Any]")

        started_at = time.perf_counter()
        self.joint_repair_stats["calls"] += 1
        base_solution = sol.deepcopy()
        pool = self._repair_customer_pool(base_solution, removed)
        if len(pool) < 2:
            result = self._repair_greedy(base_solution, removed, context)
            self._joint_repair_full_valid(result)
            self.joint_repair_stats["runtime"] += time.perf_counter() - started_at
            self.joint_repair_stats["total_obj"] = float(result.data["cost"])
            self.joint_repair_stats["truck_customer_count"] = sum(
                1
                for route in result.data["truck_routes"].values()
                for node in route
                if node in self.customers
            )
            self.joint_repair_stats["drone_task_count"] = len(result.data["drone_routes"])
            self.joint_repair_stats["unserved_count"] = len(result.data["unserved"])
            return result

        ordered_pool = self._joint_repair_customer_order(base_solution, pool)
        joint_count = min(
            len(ordered_pool),
            self.joint_repair_max_customers,
        )
        if joint_count < 2:
            raise ValueError(f"joint_count must be at least 2, got {joint_count}")
        joint_customers = ordered_pool[:joint_count]
        remaining_customers = set(ordered_pool[joint_count:])
        self.joint_repair_stats["selected_customer_count"] += joint_count

        context["joint_truck_drone"] = {
            "selected_customers": list(joint_customers),
            "remaining_customers": sorted(remaining_customers),
            "beam_width": self.joint_repair_beam_width,
            "levels": [],
        }

        beam = [base_solution]
        processed_customers: List[int] = []
        for customer_id in joint_customers:
            level_candidates: List[Solution] = []
            generated_count = 0
            feasible_count = 0
            for partial in beam:
                if customer_id not in partial.data["unserved"]:
                    raise ValueError(
                        f"joint customer {customer_id} must be unserved before "
                        f"expansion; processed={processed_customers}"
                    )
                moves = self._all_truck_insert_deltas(partial, customer_id)
                if self.allow_drone_insertions:
                    moves.extend(self._all_drone_insert_deltas(partial, customer_id))
                moves.sort(key=lambda move: move["delta_cost"])
                for move in moves:
                    generated_count += 1
                    trial, failure_details = self._apply_insert_move_on_copy_if_feasible(
                        partial,
                        move,
                    )
                    if trial is None:
                        self._record_rejected_insert_move(
                            context,
                            customer_id,
                            move,
                            self._insert_rejection_reason(
                                failure_details,
                                "post_rebuild_infeasible",
                            ),
                            failure_details,
                        )
                        continue
                    if not self._joint_repair_full_valid(trial):
                        continue
                    feasible_count += 1
                    level_candidates.append(trial)

            self.joint_repair_stats["generated_candidate_count"] += generated_count
            self.joint_repair_stats["feasible_candidate_count"] += feasible_count
            self.joint_repair_stats["beam_level_count"] += 1
            if not level_candidates:
                raise RuntimeError(
                    "joint_truck_drone repair found no feasible candidate; "
                    f"customer={customer_id}, processed={processed_customers}, "
                    f"joint_customers={joint_customers}, generated={generated_count}"
                )

            level_candidates.sort(key=lambda candidate: float(candidate.data["cost"]))
            next_beam = []
            seen_signatures = set()
            for candidate in level_candidates:
                signature = self._joint_repair_solution_signature(candidate)
                if signature in seen_signatures:
                    continue
                seen_signatures.add(signature)
                next_beam.append(candidate)
                if len(next_beam) >= self.joint_repair_beam_width:
                    break
            if not next_beam:
                raise RuntimeError(
                    "joint_truck_drone repair deduplicated all candidates; "
                    f"customer={customer_id}, processed={processed_customers}"
                )
            context["joint_truck_drone"]["levels"].append(
                {
                    "customer": customer_id,
                    "generated_candidate_count": generated_count,
                    "feasible_candidate_count": feasible_count,
                    "beam_size": len(next_beam),
                    "best_obj": float(next_beam[0].data["cost"]),
                }
            )
            processed_customers.append(customer_id)
            beam = next_beam

        beam.sort(key=lambda candidate: float(candidate.data["cost"]))
        result = beam[0]
        if remaining_customers:
            result = self._repair_greedy(result, remaining_customers, context)
        if not self._joint_repair_full_valid(result):
            raise RuntimeError(
                "joint_truck_drone repair returned an infeasible final solution"
            )

        self.joint_repair_stats["runtime"] += time.perf_counter() - started_at
        self.joint_repair_stats["truck_customer_count"] = sum(
            1
            for route in result.data["truck_routes"].values()
            for node in route
            if node in self.customers
        )
        self.joint_repair_stats["drone_task_count"] = len(result.data["drone_routes"])
        self.joint_repair_stats["unserved_count"] = len(result.data["unserved"])
        self.joint_repair_stats["total_obj"] = float(result.data["cost"])
        return result

    def _solution_road_risk_cost(self, sol: Solution) -> float:
        """返回当前解的道路风险成本。"""
        if "cost_info" in sol.data and "road_risk_cost" in sol.data["cost_info"]:
            return sol.data["cost_info"]["road_risk_cost"]

        truck_evaluations = sol.data["validation_report"]["truck_evaluations"]
        return sum(
            evaluation["road_risk_cost"]
            for evaluation in truck_evaluations.values()
        )

    def _all_truck_insert_positions(
        self,
        sol: Solution,
        customer_id: int,
    ) -> List[Dict[str, Any]]:
        """
        枚举某个客户可以尝试插入的所有卡车位置。
        position 表示插入到 route[position] 之前：
        position=1 表示插到起点仓库之后；
        position=len(route)-1 表示插到终点仓库之前。
        """
        if customer_id not in self.customers:
            raise ValueError(f"customer {customer_id} is not in self.customers")
        if "is_static" not in self.customers[customer_id]:
            raise ValueError(f"customer {customer_id} missing required field: is_static")
        if "truck_routes" not in sol.data:
            raise ValueError("solution missing required key: truck_routes")
        if not isinstance(sol.data["truck_routes"], dict):
            raise TypeError('sol.data["truck_routes"] must be a dict')

        positions = []
        for truck_id in sorted(sol.data["truck_routes"]):
            route = sol.data["truck_routes"][truck_id]
            if not isinstance(route, list):
                raise TypeError(f"truck route of truck {truck_id} must be a list")
            expected_anchor_node = self._route_anchor_node_for_truck(sol, truck_id)
            if expected_anchor_node == self.depot_end:
                if route != [self.depot_end]:
                    raise ValueError(
                        f"completed truck {truck_id} route must remain "
                        f"[{self.depot_end}], got {route}"
                    )
                continue
            if len(route) < 2:
                raise ValueError(f"truck route of truck {truck_id} must contain depot_start and depot_end")
            if route[0] != expected_anchor_node:
                raise ValueError(
                    f"truck route of truck {truck_id} must start with anchor_node "
                    f"{expected_anchor_node}: {route}"
                )
            if route[-1] != self.depot_end:
                raise ValueError(
                    f"truck route of truck {truck_id} must end with depot_end {self.depot_end}: {route}"
                )
            for position in range(1, len(route)):
                if not self._truck_insert_position_matches_time_window(
                    route=route,
                    insert_pos=position,
                    customer_id=customer_id,
                    truck_id=truck_id,
                ):
                    continue
                positions.append(
                    {
                        "truck_id": truck_id,
                        "insert_pos": position,
                    }
                )

        return positions

    def _truck_insert_node_options(self, customer_id: int) -> List[List[int]]:
        if customer_id not in self.customers:
            raise ValueError(f"customer {customer_id} is not in self.customers")
        if "is_static" not in self.customers[customer_id]:
            raise ValueError(f"customer {customer_id} missing required field: is_static")
        if customer_id in {
            self.depot_start,
            self.depot_end,
            self.replenishment_node,
        }:
            raise ValueError(f"customer_id {customer_id} cannot be depot or replenishment node")
        customer_is_static = self.customers[customer_id]["is_static"]
        if not isinstance(customer_is_static, bool):
            raise TypeError(
                f"customer {customer_id} is_static must be bool, "
                f"got {type(customer_is_static).__name__}"
            )

        return [
            [customer_id],
        ]

    def _k_best_truck_deltas(
        self,
        sol: Solution,
        customer_id: int,
        k: int,
        positions: Optional[List[Dict[str, Any]]] = None,
    ) -> List[Dict[str, Any]]:
        """
        枚举客户所有卡车插入位置，返回 delta_cost 最小的前 k 个可行 move。
        """
        if k <= 0:
            raise ValueError(f"k must be positive, got {k}")
        if positions is None:
            positions = self._all_truck_insert_positions(sol, customer_id)
        elif not isinstance(positions, list):
            raise TypeError("positions must be a list")
        if customer_id not in self.customers:
            raise ValueError(f"customer {customer_id} is not in self.customers")
        if "is_static" not in self.customers[customer_id]:
            raise ValueError(f"customer {customer_id} missing required field: is_static")
        if "unserved" not in sol.data:
            raise ValueError("solution missing required key: unserved")
        if "served" not in sol.data:
            raise ValueError("solution missing required key: served")
        if "cost" not in sol.data:
            raise ValueError("solution missing required key: cost")
        if "truck_routes" not in sol.data:
            raise ValueError("solution missing required key: truck_routes")
        if not isinstance(sol.data["unserved"], list):
            raise TypeError('sol.data["unserved"] must be a list')
        if not isinstance(sol.data["served"], set):
            raise TypeError('sol.data["served"] must be a set')
        if customer_id not in sol.data["unserved"]:
            raise ValueError(
                f"customer {customer_id} must be in unserved before truck insertion; "
                f"unserved={sol.data['unserved']}"
            )
        if customer_id in sol.data["served"]:
            raise ValueError(f"customer {customer_id} is already in served")
        for truck_id, route in sol.data["truck_routes"].items():
            if customer_id in route:
                raise ValueError(
                    f"customer {customer_id} is already in truck route of truck {truck_id}"
                )

        for task_index, task in enumerate(sol.data["drone_routes"]):
            if task["customer"] == customer_id:
                raise ValueError(
                    f"customer {customer_id} is already served by drone task {task_index}"
                )

        old_cost = sol.data["cost"]
        if "validation_report" not in sol.data:
            raise ValueError("solution missing required key: validation_report")
        if "route_costs" not in sol.data["validation_report"]:
            raise ValueError("validation_report missing required key: route_costs")
        if "truck_evaluations" not in sol.data["validation_report"]:
            raise ValueError("validation_report missing required key: truck_evaluations")
        unserved_penalty = self._customer_unserved_penalty(customer_id)
        moves = []
        if (
            "phase_completed_customer_ids" in sol.data
            and self.customers[customer_id]["is_static"] is True
        ):
            insert_node_options = [[customer_id]]
        else:
            insert_node_options = self._truck_insert_node_options(customer_id)

        for position_info in positions:
            truck_id = position_info["truck_id"]
            insert_pos = position_info["insert_pos"]
            route = sol.data["truck_routes"][truck_id]
            if truck_id not in sol.data["phase_start_state_by_truck"]:
                raise ValueError(f"phase_start_state_by_truck missing truck_id {truck_id}")
            start_state = sol.data["phase_start_state_by_truck"][truck_id]

            for insert_nodes in insert_node_options:
                if not self._truck_insert_local_risk_feasible(
                    sol=sol,
                    truck_id=truck_id,
                    insert_pos=insert_pos,
                    insert_nodes=insert_nodes,
                ):
                    continue
                candidate_route = route[:insert_pos] + insert_nodes + route[insert_pos:]
                evaluation = self._evaluate_truck_route_profiled(
                    route=candidate_route,
                    truck_id=truck_id,
                    start_state=start_state,
                )
                if not evaluation["feasible"]:
                    continue

                if truck_id not in sol.data["validation_report"]["route_costs"]:
                    raise ValueError(f"route_costs missing truck_id {truck_id}")
                if truck_id not in sol.data["validation_report"]["truck_evaluations"]:
                    raise ValueError(f"truck_evaluations missing truck_id {truck_id}")

                old_route_cost = sol.data["validation_report"]["route_costs"][truck_id]
                old_route_evaluation = sol.data["validation_report"]["truck_evaluations"][truck_id]
                if "road_risk_cost" not in old_route_evaluation:
                    raise ValueError(f"truck evaluation {truck_id} missing road_risk_cost")

                new_route_cost = calculate_route_cost(
                    evaluation,
                    cost_weights=self.cost_weights,
                )
                delta_cost = new_route_cost - old_route_cost - unserved_penalty
                road_risk_delta = evaluation["road_risk_cost"] - old_route_evaluation["road_risk_cost"]
                new_road_risk_cost = self._solution_road_risk_cost(sol) + road_risk_delta
                new_cost = old_cost + delta_cost
                moves.append(
                    {
                        "mode": "truck",
                        "customer": customer_id,
                        "truck_id": truck_id,
                        "insert_pos": insert_pos,
                        "insert_nodes": list(insert_nodes),
                        "new_route": candidate_route,
                        "delta_cost": delta_cost,
                        "road_risk_cost": new_road_risk_cost,
                        "road_risk_delta": road_risk_delta,
                        "new_cost": new_cost,
                        "old_cost": old_cost,
                        "local_evaluation": evaluation,
                    }
                )

        moves.sort(key=lambda move: move["delta_cost"])
        return moves[:k]

    def _best_truck_insert_delta(
        self,
        sol: Solution,
        customer_id: int,
    ) -> Optional[Dict[str, Any]]:
        """
        兼容旧接口：返回最优卡车插入候选。
        """
        moves = self._k_best_truck_deltas(sol, customer_id, k=1)
        if not moves:
            return None
        return moves[0]

    def _all_drone_insert_positions(
        self,
        sol: Solution,
        customer_id: int,
    ) -> List[Dict[str, Any]]:
        """
        枚举某个客户可以尝试的所有无人机发射/回收位置。

        默认不允许 depot_start、depot_end 和 replenishment_node 作为发射点或回收点。
        launch_idx 必须小于 recovery_idx，表示无人机必须在同一辆卡车后续节点回收。
        """
        profile_start = time.perf_counter() if _profile_enabled() else None
        if customer_id not in self.customers:
            raise ValueError(f"customer {customer_id} is not in self.customers")
        if "is_static" not in self.customers[customer_id]:
            raise ValueError(f"customer {customer_id} missing required field: is_static")
        if "truck_routes" not in sol.data:
            raise ValueError("solution missing required key: truck_routes")
        if not isinstance(sol.data["truck_routes"], dict):
            raise TypeError('sol.data["truck_routes"] must be a dict')
        if not isinstance(self.drone_ids_by_truck, dict):
            raise TypeError("self.drone_ids_by_truck must be a dict")

        customer_is_static = self.customers[customer_id]["is_static"]
        excluded_static_launch_recovery_nodes = {
            self.depot_start,
            self.depot_end,
            self.replenishment_node,
        }
        excluded_dynamic_launch_nodes = {
            self.depot_start,
            self.depot_end,
            self.replenishment_node,
        }
        excluded_dynamic_recovery_nodes = {
            self.depot_start,
            self.replenishment_node,
        }

        positions = []
        for truck_id in sorted(sol.data["truck_routes"]):
            if truck_id not in self.drone_ids_by_truck:
                raise ValueError(f"drone_ids_by_truck missing truck_id {truck_id}")

            route = sol.data["truck_routes"][truck_id]
            if not isinstance(route, list):
                raise TypeError(f"truck route of truck {truck_id} must be a list")
            expected_anchor_node = self._route_anchor_node_for_truck(sol, truck_id)
            if expected_anchor_node == self.depot_end:
                if route != [self.depot_end]:
                    raise ValueError(
                        f"completed truck {truck_id} route must remain "
                        f"[{self.depot_end}], got {route}"
                    )
                continue
            if len(route) < 2:
                raise ValueError(f"truck route of truck {truck_id} must contain depot_start and depot_end")
            if route[0] != expected_anchor_node:
                raise ValueError(
                    f"truck route of truck {truck_id} must start with anchor_node "
                    f"{expected_anchor_node}: {route}"
                )
            if route[-1] != self.depot_end:
                raise ValueError(
                    f"truck route of truck {truck_id} must end with depot_end {self.depot_end}: {route}"
                )
            for drone_id in sorted(self.drone_ids_by_truck[truck_id]):
                for launch_idx in range(len(route)):
                    launch_node = route[launch_idx]
                    if customer_is_static:
                        if launch_node in excluded_static_launch_recovery_nodes:
                            continue
                        if launch_node not in self.customers:
                            raise ValueError(f"launch_node {launch_node} is not in self.customers")
                    else:
                        if launch_node in excluded_dynamic_launch_nodes:
                            continue
                        if launch_node not in self.customers:
                            raise ValueError(f"launch_node {launch_node} is not in self.customers")
                    for recovery_idx in range(launch_idx + 1, len(route)):
                        recovery_node = route[recovery_idx]
                        if customer_is_static:
                            excluded_recovery_nodes = excluded_static_launch_recovery_nodes
                        else:
                            excluded_recovery_nodes = excluded_dynamic_recovery_nodes
                        if recovery_node in excluded_recovery_nodes:
                            continue
                        if recovery_node != self.depot_end and recovery_node not in self.customers:
                            raise ValueError(f"recovery_node {recovery_node} is not in self.customers")

                        positions.append(
                            {
                                "truck_id": truck_id,
                                "drone_id": drone_id,
                                "launch_idx": launch_idx,
                                "recovery_idx": recovery_idx,
                                "launch_node": launch_node,
                                "recovery_node": recovery_node,
                            }
                        )

        if profile_start is not None:
            _profile_count("all_drone_insert_positions_calls")
            _profile_count("all_drone_insert_positions_candidates", len(positions))
            _profile_add(
                "all_drone_insert_positions_seconds",
                time.perf_counter() - profile_start,
            )
        return positions

    def _k_best_drone_trip_deltas_local(
        self,
        sol: Solution,
        customer_id: int,
        k: int,
        positions: Optional[List[Dict[str, Any]]] = None,
    ) -> List[Dict[str, Any]]:
        """无人机候选阶段只做局部 sortie 评价，真正执行插入时才 rebuild。"""
        if k <= 0:
            raise ValueError(f"k must be positive, got {k}")
        if positions is None:
            positions = self._all_drone_insert_positions(sol, customer_id)
        elif not isinstance(positions, list):
            raise TypeError("positions must be a list")
        if customer_id not in self.customers:
            raise ValueError(f"customer {customer_id} is not in self.customers")
        if "is_static" not in self.customers[customer_id]:
            raise ValueError(f"customer {customer_id} missing required field: is_static")
        required_solution_keys = {
            "truck_routes",
            "drone_routes",
            "unserved",
            "served",
            "cost",
            "validation_report",
            "drone_period_usage",
            "segment_usage",
        }
        missing_solution_keys = required_solution_keys - set(sol.data)
        if missing_solution_keys:
            raise ValueError(f"solution missing required keys: {sorted(missing_solution_keys)}")
        if "truck_evaluations" not in sol.data["validation_report"]:
            raise ValueError("validation_report missing required key: truck_evaluations")
        if not isinstance(sol.data["unserved"], list):
            raise TypeError('sol.data["unserved"] must be a list')
        if not isinstance(sol.data["served"], set):
            raise TypeError('sol.data["served"] must be a set')
        if not isinstance(sol.data["drone_routes"], list):
            raise TypeError('sol.data["drone_routes"] must be a list')
        if customer_id not in sol.data["unserved"]:
            raise ValueError(
                f"customer {customer_id} must be in unserved before drone insertion; "
                f"unserved={sol.data['unserved']}"
            )
        if customer_id in sol.data["served"]:
            raise ValueError(f"customer {customer_id} is already in served")
        for truck_id, route in sol.data["truck_routes"].items():
            if customer_id in route:
                raise ValueError(
                    f"customer {customer_id} is already in truck route of truck {truck_id}"
                )
        for task_index, task in enumerate(sol.data["drone_routes"]):
            if task["customer"] == customer_id:
                raise ValueError(f"customer {customer_id} is already served by drone task {task_index}")

        old_cost = sol.data["cost"]
        old_road_risk_cost = self._solution_road_risk_cost(sol)
        unserved_penalty = self._customer_unserved_penalty(customer_id)
        moves = []

        for position_info in positions:
            if "insert_replenishment" in position_info and position_info["insert_replenishment"]:
                raise InvalidMoveError(
                    "drone insertion position cannot request deprecated "
                    "replenishment insertion"
                )

            truck_id = position_info["truck_id"]
            drone_id = position_info["drone_id"]
            launch_node = position_info["launch_node"]
            recovery_node = position_info["recovery_node"]
            launch_idx = position_info["launch_idx"]
            recovery_idx = position_info["recovery_idx"]

            if truck_id not in sol.data["truck_routes"]:
                raise ValueError(f"truck_routes missing truck_id {truck_id}")
            if truck_id not in sol.data["validation_report"]["truck_evaluations"]:
                raise ValueError(f"truck_evaluations missing truck_id {truck_id}")

            sortie_profile_start = time.perf_counter() if _profile_enabled() else None
            try:
                sortie_eval = evaluate_drone_sortie(
                    truck_route=sol.data["truck_routes"][truck_id],
                    truck_evaluation=sol.data["validation_report"]["truck_evaluations"][truck_id],
                    truck_id=truck_id,
                    drone_id=drone_id,
                    launch_node=launch_node,
                    customer_id=customer_id,
                    recovery_node=recovery_node,
                    customers=self.customers,
                    drone_distance_matrix=self.drone_distance_matrix,
                    drone_time_matrix=self.drone_time_matrix,
                    drone_capacity=get_drone_capacity(drone_id, self.drone_capacity_by_drone),
                    drone_endurance=get_drone_endurance(drone_id, self.drone_endurance_by_drone),
                    depot_start=self.depot_start,
                    depot_end=self.depot_end,
                    replenishment_node=self.replenishment_node,
                    periods=self.periods,
                    period_length=self.period_length,
                    cost_weights=self.cost_weights,
                    launch_idx=launch_idx,
                    recovery_idx=recovery_idx,
                )
            finally:
                _profile_finish_timed_call(
                    "evaluate_drone_sortie",
                    sortie_profile_start,
                )
            if not sortie_eval["feasible"]:
                continue
            expected_occupied_segments = [
                (truck_id, segment_index)
                for segment_index in range(launch_idx, recovery_idx)
            ]
            sortie_eval["occupied_segments"] = expected_occupied_segments
            if not self._validate_drone_local_resource_feasibility(sol, sortie_eval):
                continue

            drone_task = {
                "task_id": preview_next_drone_task_id(sol.data),
                "truck_id": truck_id,
                "drone_id": drone_id,#drone_id 表示 哪一架无人机
                "launch_node": launch_node,
                "launch_idx": launch_idx,
                "customer": customer_id,
                "recovery_node": recovery_node,
                "recovery_idx": recovery_idx,
                "period_index": sortie_eval["period_index"],
                "launch_time": sortie_eval["launch_time"],
                "recovery_time": sortie_eval["recovery_time"],
                "truck_waiting_time": sortie_eval["truck_waiting_time"],
                "cost": sortie_eval["cost"],
                "occupied_segments": list(sortie_eval["occupied_segments"]),
                "evaluation": copy.deepcopy(sortie_eval),
            }
            delta_cost = sortie_eval["cost"] - unserved_penalty
            move = {
                "mode": "drone",
                "customer": customer_id,
                "truck_id": truck_id,
                "drone_id": drone_id,
                "launch_idx": launch_idx,
                "recovery_idx": recovery_idx,
                "launch_node": launch_node,
                "recovery_node": recovery_node,
                "drone_task": drone_task,
                "evaluation": copy.deepcopy(sortie_eval),
                "delta_cost": delta_cost,
                "road_risk_cost": old_road_risk_cost,
                "road_risk_delta": 0.0,
                "new_cost": old_cost + delta_cost,
                "old_cost": old_cost,
            }
            if self._drone_move_overlaps_existing_tasks(sol, move):
                continue
            moves.append(move)

        moves.sort(key=lambda move: move["delta_cost"])
        return moves[:k]

    def _k_best_drone_trip_deltas(
        self,
        sol: Solution,
        customer_id: int,
        k: int,
        positions: Optional[List[Dict[str, Any]]] = None,
    ) -> List[Dict[str, Any]]:
        """
        枚举客户所有无人机单客户任务，返回 delta_cost 最小的前 k 个可行 move。
        """
        return self._k_best_drone_trip_deltas_local(
            sol,
            customer_id,
            k,
            positions=positions,
        )


    def _best_drone_insert_delta(
        self,
        sol: Solution,
        customer_id: int,
    ) -> Optional[Dict[str, Any]]:
        """
        兼容旧接口：返回最优无人机插入候选。
        """
        moves = self._k_best_drone_trip_deltas(sol, customer_id, k=1)
        if not moves:
            return None
        return moves[0]

    def _k_best_all_deltas(
        self,
        sol: Solution,
        customer_id: int,
        k: int,
    ) -> List[Dict[str, Any]]:
        """
        合并卡车插入和无人机插入候选，返回 delta_cost 最小的前 k 个 move。
        """
        if k <= 0:
            raise ValueError(f"k must be positive, got {k}")

        truck_moves = self._k_best_truck_deltas(sol, customer_id, k)
        drone_moves = self._k_best_drone_trip_deltas(sol, customer_id, k)
        moves = truck_moves + drone_moves
        moves.sort(key=lambda move: move["delta_cost"])
        return moves[:k]

    def _insert_as_truck(
        self,
        sol: Solution,
        move: Dict[str, Any],
        rebuild: bool = True,
    ) -> None:
        """
        执行卡车插入动作。
        本函数只负责修改解的结构字段：
        1. truck_routes；
        2. served；
        3. unserved。
        时间、载重、风险、成本、可行性等派生信息统一交给 _rebuild_solution。
        """
        required_solution_keys = {
            "truck_routes",
            "drone_routes",
            "unserved",
            "served",
            "cost",
            "feasible",
            "validation_report",
            "full_validation_report",
            "drone_period_usage",
            "segment_usage",
        }
        missing_solution_keys = required_solution_keys - set(sol.data)
        if missing_solution_keys:
            raise ValueError(
                f"solution missing required keys: {sorted(missing_solution_keys)}"
            )
        required_move_keys = {
            "mode",
            "customer",
            "truck_id",
            "insert_pos",
            "insert_nodes",
            "new_route",
        }
        missing_move_keys = required_move_keys - set(move)
        if missing_move_keys:
            raise ValueError(
                f"truck insert move missing required keys: {sorted(missing_move_keys)}"
            )
        if move["mode"] != "truck":
            raise ValueError(f"_insert_as_truck received non-truck move: {move['mode']}")
        if not isinstance(sol.data["truck_routes"], dict):
            raise TypeError('sol.data["truck_routes"] must be a dict')
        if not isinstance(sol.data["unserved"], list):
            raise TypeError('sol.data["unserved"] must be a list')
        if not isinstance(sol.data["served"], set):
            raise TypeError('sol.data["served"] must be a set')

        customer_id = move["customer"]
        truck_id = move["truck_id"]
        new_route = move["new_route"]
        insert_pos = move["insert_pos"]
        insert_nodes = move["insert_nodes"]

        if customer_id not in self.customers:
            raise ValueError(f"customer {customer_id} is not in self.customers")
        if "is_static" not in self.customers[customer_id]:
            raise ValueError(f"customer {customer_id} missing required field: is_static")
        if truck_id not in sol.data["truck_routes"]:
            raise ValueError(f"truck_id {truck_id} is not in sol.data['truck_routes']")
        if truck_id not in sol.data["phase_start_state_by_truck"]:
            raise ValueError(f"phase_start_state_by_truck missing truck_id {truck_id}")
        start_state = sol.data["phase_start_state_by_truck"][truck_id]
        if customer_id not in sol.data["unserved"]:
            raise ValueError(
                f"customer {customer_id} must be in unserved before truck insertion; "
                f"unserved={sol.data['unserved']}"
            )
        if customer_id in sol.data["served"]:
            raise ValueError(f"customer {customer_id} is already in served")
        if not isinstance(new_route, list):
            raise TypeError('move["new_route"] must be a list')
        if len(new_route) < 2:
            raise ValueError('move["new_route"] must contain depot_start and depot_end')
        if new_route[0] != start_state["anchor_node"]:
            raise ValueError(
                f"new_route must start with anchor_node {start_state['anchor_node']}: {new_route}"
            )
        if new_route[-1] != self.depot_end:
            raise ValueError(
                f"new_route must end with depot_end {self.depot_end}: {new_route}"
            )
        if customer_id not in new_route:
            raise ValueError(f"new_route does not contain inserted customer {customer_id}")
        if not isinstance(insert_pos, int):
            raise TypeError('move["insert_pos"] must be an int')
        if not isinstance(insert_nodes, list):
            raise TypeError('move["insert_nodes"] must be a list')
        if self.replenishment_node in insert_nodes:
            raise InvalidMoveError(
                f"truck insertion cannot include deprecated replenishment node "
                f"{self.replenishment_node}"
            )
        valid_insert_node_options = self._truck_insert_node_options(customer_id)
        if insert_nodes not in valid_insert_node_options:
            raise ValueError(
                f"invalid truck insert_nodes for customer {customer_id}: {insert_nodes}"
            )
        old_route = sol.data["truck_routes"][truck_id]
        if not isinstance(old_route, list):
            raise TypeError(f"truck route of truck {truck_id} must be a list")
        if insert_pos < 1 or insert_pos > len(old_route) - 1:
            raise ValueError(
                f"insert_pos {insert_pos} outside valid range [1, {len(old_route) - 1}]"
            )
        expected_route = old_route[:insert_pos] + insert_nodes + old_route[insert_pos:]
        if new_route != expected_route:
            raise ValueError(
                f"new_route does not match insert_pos and insert_nodes for truck {truck_id}"
            )
        for existing_truck_id, route in sol.data["truck_routes"].items():
            if existing_truck_id != truck_id and customer_id in route:
                raise ValueError(
                    f"customer {customer_id} already exists in truck route {existing_truck_id}"
                )
        for task_index, task in enumerate(sol.data["drone_routes"]):
            if not isinstance(task, dict):
                raise TypeError(f"drone task {task_index} must be a dict")
            if "customer" not in task:
                raise ValueError(f"drone task {task_index} missing required key: customer")
            if task["customer"] == customer_id:
                raise ValueError(f"customer {customer_id} is already served by drone task {task_index}")

        customer_positions = [
            idx for idx, node in enumerate(new_route) if node == customer_id
        ]
        if len(customer_positions) != 1:
            raise ValueError(
                f"customer {customer_id} must appear exactly once in new_route"
            )

        self._shift_drone_task_indices_after_truck_insert(
            sol=sol,
            truck_id=truck_id,
            insert_pos=insert_pos,
            inserted_count=len(insert_nodes),
        )
        sol.data["truck_routes"][truck_id] = list(new_route)
        sol.data["served"].add(customer_id)
        sol.data["unserved"].remove(customer_id)
        self._refresh_static_phase_start_state_if_needed(sol)

        if rebuild:
            self._rebuild_solution(sol)
        return None

    def _evaluate_truck_route_profiled(
        self,
        route: List[int],
        truck_id: int,
        start_state: Dict[str, Any],
    ) -> Dict[str, Any]:
        required_start_state_keys = {
            "anchor_node",
            "anchor_time",
            "initial_basic_load",
            "initial_emergency_load",
        }
        missing_start_state_keys = required_start_state_keys - set(start_state)
        if missing_start_state_keys:
            raise ValueError(
                f"phase_start_state_by_truck[{truck_id}] missing required keys: "
                f"{sorted(missing_start_state_keys)}"
            )
        if _profile_enabled():
            start_time = time.perf_counter()
            try:
                evaluation = evaluate_truck_route(
                    route=route,
                    customers=self.customers,
                    distance_matrix=self.distance_matrix,
                    truck_time_matrix=self.truck_time_matrix,
                    risk_matrix=self.risk_matrix,
                    periods=self.periods,
                    period_length=self.period_length,
                    truck_capacity=self._truck_capacity(truck_id),
                    depot_start=self.depot_start,
                    depot_end=self.depot_end,
                    replenishment_node=self.replenishment_node,
                    start_time=start_state["anchor_time"],
                    anchor_node=start_state["anchor_node"],
                    initial_basic_load=start_state["initial_basic_load"],
                    initial_emergency_load=start_state["initial_emergency_load"],
                )
            finally:
                _profile_count("evaluate_truck_route_calls")
                _profile_add(
                    "evaluate_truck_route_seconds",
                    time.perf_counter() - start_time,
                )
        else:
            evaluation = evaluate_truck_route(
                route=route,
                customers=self.customers,
                distance_matrix=self.distance_matrix,
                truck_time_matrix=self.truck_time_matrix,
                risk_matrix=self.risk_matrix,
                periods=self.periods,
                period_length=self.period_length,
                truck_capacity=self._truck_capacity(truck_id),
                depot_start=self.depot_start,
                depot_end=self.depot_end,
                replenishment_node=self.replenishment_node,
                start_time=start_state["anchor_time"],
                anchor_node=start_state["anchor_node"],
                initial_basic_load=start_state["initial_basic_load"],
                initial_emergency_load=start_state["initial_emergency_load"],
            )
        return evaluation

    def _apply_drone_replacement(
        self,
        sol: Solution,
        move: Dict[str, Any],
        rebuild: bool = True,
    ) -> None:
        """
        执行无人机插入动作。

        当前阶段暂不做“卡车客户改由无人机服务”的路径替换，只处理
        _best_drone_insert_delta 生成的未服务客户无人机插入任务。
        """
        required_solution_keys = {
            "truck_routes",
            "drone_routes",
            "unserved",
            "served",
            "cost",
            "feasible",
            "validation_report",
            "full_validation_report",
            "drone_period_usage",
            "segment_usage",
        }
        missing_solution_keys = required_solution_keys - set(sol.data)
        if missing_solution_keys:
            raise ValueError(
                f"solution missing required keys: {sorted(missing_solution_keys)}"
            )
        required_move_keys = {
            "mode",
            "customer",
            "truck_id",
            "drone_id",
            "launch_idx",
            "recovery_idx",
            "launch_node",
            "recovery_node",
            "drone_task",
        }
        missing_move_keys = required_move_keys - set(move)
        if missing_move_keys:
            raise ValueError(
                f"drone insert move missing required keys: {sorted(missing_move_keys)}"
            )
        if move["mode"] != "drone":
            raise ValueError(f"_apply_drone_replacement received non-drone move: {move['mode']}")
        if not isinstance(sol.data["truck_routes"], dict):
            raise TypeError('sol.data["truck_routes"] must be a dict')
        if not isinstance(sol.data["drone_routes"], list):
            raise TypeError('sol.data["drone_routes"] must be a list')
        if not isinstance(sol.data["unserved"], list):
            raise TypeError('sol.data["unserved"] must be a list')
        if not isinstance(sol.data["served"], set):
            raise TypeError('sol.data["served"] must be a set')

        customer_id = move["customer"]
        truck_id = move["truck_id"]
        drone_id = move["drone_id"]
        drone_task = copy.deepcopy(move["drone_task"])

        if customer_id not in self.customers:
            raise ValueError(f"customer {customer_id} is not in self.customers")
        if "is_static" not in self.customers[customer_id]:
            raise ValueError(f"customer {customer_id} missing required field: is_static")
        customer_is_static = self.customers[customer_id]["is_static"]
        if not isinstance(customer_is_static, bool):
            raise TypeError(
                f"customer {customer_id} is_static must be bool, "
                f"got {type(customer_is_static).__name__}"
            )
        if not customer_is_static:
            if "release_time" not in self.customers[customer_id]:
                raise ValueError(f"dynamic customer {customer_id} missing required field: release_time")
        if customer_id not in sol.data["unserved"]:
            raise ValueError(
                f"customer {customer_id} must be in unserved before drone insertion; "
                f"unserved={sol.data['unserved']}"
            )
        if customer_id in sol.data["served"]:
            raise ValueError(f"customer {customer_id} is already in served")
        if truck_id not in sol.data["truck_routes"]:
            raise ValueError(f"truck_id {truck_id} is not in sol.data['truck_routes']")
        if not isinstance(self.drone_ids_by_truck, dict):
            raise TypeError("self.drone_ids_by_truck must be a dict")
        if truck_id not in self.drone_ids_by_truck:
            raise ValueError(f"drone_ids_by_truck missing truck_id {truck_id}")
        if drone_id not in self.drone_ids_by_truck[truck_id]:
            raise ValueError(f"drone_id {drone_id} does not belong to truck {truck_id}")

        required_task_keys = {
            "task_id",
            "truck_id",
            "drone_id",
            "launch_node",
            "launch_idx",
            "customer",
            "recovery_node",
            "recovery_idx",
            "period_index",
            "launch_time",
            "recovery_time",
            "cost",
            "occupied_segments",
            "evaluation",
        }
        missing_task_keys = required_task_keys - set(drone_task)
        if missing_task_keys:
            raise ValueError(
                f"drone_task missing required keys: {sorted(missing_task_keys)}"
            )
        if drone_task["truck_id"] != truck_id:
            raise ValueError("move truck_id and drone_task truck_id are inconsistent")
        if drone_task["drone_id"] != drone_id:
            raise ValueError("move drone_id and drone_task drone_id are inconsistent")
        if drone_task["customer"] != customer_id:
            raise ValueError("move customer and drone_task customer are inconsistent")
        if drone_task["launch_node"] != move["launch_node"]:
            raise ValueError("move launch_node and drone_task launch_node are inconsistent")
        if drone_task["recovery_node"] != move["recovery_node"]:
            raise ValueError("move recovery_node and drone_task recovery_node are inconsistent")
        if drone_task["launch_idx"] != move["launch_idx"]:
            raise ValueError("move launch_idx and drone_task launch_idx are inconsistent")
        if drone_task["recovery_idx"] != move["recovery_idx"]:
            raise ValueError("move recovery_idx and drone_task recovery_idx are inconsistent")

        route = sol.data["truck_routes"][truck_id]
        if not isinstance(route, list):
            raise TypeError(f"truck route of truck {truck_id} must be a list")
        launch_idx = drone_task["launch_idx"]
        recovery_idx = drone_task["recovery_idx"]
        if isinstance(launch_idx, bool) or not isinstance(launch_idx, int):
            raise TypeError(f"drone_task launch_idx must be int, got {type(launch_idx).__name__}")
        if isinstance(recovery_idx, bool) or not isinstance(recovery_idx, int):
            raise TypeError(f"drone_task recovery_idx must be int, got {type(recovery_idx).__name__}")
        if launch_idx < 0 or launch_idx >= len(route):
            raise ValueError(
                f"drone_task launch_idx {launch_idx} outside truck route length {len(route)}"
            )
        if recovery_idx < 0 or recovery_idx >= len(route):
            raise ValueError(
                f"drone_task recovery_idx {recovery_idx} outside truck route length {len(route)}"
            )
        if route[launch_idx] != drone_task["launch_node"]:
            raise ValueError(
                f"drone_task launch_idx points to {route[launch_idx]}, "
                f"expected {drone_task['launch_node']}"
            )
        if route[recovery_idx] != drone_task["recovery_node"]:
            raise ValueError(
                f"drone_task recovery_idx points to {route[recovery_idx]}, "
                f"expected {drone_task['recovery_node']}"
            )
        if launch_idx >= recovery_idx:
            raise ValueError("launch_node must appear before recovery_node in truck route")
        if customer_is_static and drone_task["launch_node"] == self.replenishment_node:
            raise ValueError("static customer drone insertion cannot launch from replenishment node")
        if not customer_is_static and drone_task["launch_node"] == self.replenishment_node:
            raise ValueError("dynamic customer drone insertion cannot launch from replenishment node")
        if customer_id in route:
            raise ValueError(
                f"customer {customer_id} is already served in truck route {truck_id}"
            )
        validate_unique_drone_task_ids(sol.data["drone_routes"])
        for task_index, task in enumerate(sol.data["drone_routes"]):
            if not isinstance(task, dict):
                raise TypeError(f"drone task {task_index} must be a dict")
            if "customer" not in task:
                raise ValueError(f"drone task {task_index} missing required key: customer")
            if task["customer"] == customer_id:
                raise ValueError(f"customer {customer_id} is already served by drone task {task_index}")

        append_new_drone_task(sol.data, drone_task)
        sol.data["served"].add(customer_id)
        sol.data["unserved"].remove(customer_id)
        self._refresh_static_phase_start_state_if_needed(sol)

        if rebuild:
            self._rebuild_solution(sol)
        return None

    def _cost_component_weight(self, key: str) -> float:
        if key not in self.cost_weights:
            raise ValueError(f"cost_weights missing key: {key}")
        weight = self.cost_weights[key]
        if isinstance(weight, bool) or not isinstance(weight, (int, float)):
            raise TypeError(f"cost_weights[{key}] must be numeric")
        return float(weight)

    def _cost_ledger_period(self, current_time: float) -> Any:
        if not self.periods:
            raise ValueError("periods must not be empty")
        if self.period_length <= 0:
            raise ValueError("period_length must be positive")
        if current_time < 0:
            return self.periods[0]
        period_index = int(current_time // self.period_length)
        if period_index >= len(self.periods):
            return self.periods[-1]
        return self.periods[period_index]

    def _matrix_value_for_cost_ledger(self, matrix: Dict[Any, Any], *keys: Any) -> Any:
        value = matrix
        for key in keys:
            if key not in value:
                raise ValueError(f"cost ledger matrix missing path: {keys}")
            value = value[key]
        return value

    def _add_customer_cost_to_ledger(
        self,
        priority_cost_by_customer: Dict[int, float],
        delay_penalty_by_customer: Dict[int, float],
        customer_id: int,
        priority_cost: float,
        delay_penalty: float,
    ) -> None:
        if customer_id in priority_cost_by_customer:
            raise ValueError(
                f"cost ledger already contains customer {customer_id}"
            )
        priority_cost_by_customer[customer_id] = priority_cost
        delay_penalty_by_customer[customer_id] = delay_penalty

    def _build_cost_ledger(
        self,
        sol: Solution,
        cost_info: Dict[str, Any],
    ) -> Dict[str, Any]:
        validation_report = sol.data["validation_report"]
        truck_evaluations = validation_report["truck_evaluations"]
        truck_edge_road_risk_cost_by_position: Dict[int, Dict[int, float]] = {}
        priority_cost_by_customer: Dict[int, float] = {}
        delay_penalty_by_customer: Dict[int, float] = {}
        drone_cost_by_task_id: Dict[int, float] = {}

        cost_components = {
            "priority_cost": 0.0,
            "unserved_penalty_cost": float(cost_info["unserved_penalty_cost"]),
            "road_risk_cost": 0.0,
            "delay_penalty": 0.0,
        }
        priority_weight = self._cost_component_weight("priority_cost")
        road_risk_weight = self._cost_component_weight("road_risk_cost")
        delay_weight = self._cost_component_weight("delay_penalty")

        for truck_id, truck_route in sol.data["truck_routes"].items():
            if truck_id not in truck_evaluations:
                raise ValueError(f"validation_report missing truck {truck_id}")
            evaluation = truck_evaluations[truck_id]
            for component_key in (
                "priority_cost",
                "road_risk_cost",
                "delay_penalty",
            ):
                if component_key not in evaluation:
                    raise ValueError(
                        f"truck evaluation {truck_id} missing {component_key}"
                    )
            cost_components["priority_cost"] += (
                evaluation["priority_cost"] * priority_weight
            )
            cost_components["road_risk_cost"] += (
                evaluation["road_risk_cost"] * road_risk_weight
            )
            cost_components["delay_penalty"] += (
                evaluation["delay_penalty"] * delay_weight
            )

            if "timeline_by_position" not in evaluation:
                raise ValueError(
                    f"truck evaluation {truck_id} missing timeline_by_position"
                )
            timeline_by_position = evaluation["timeline_by_position"]
            if not isinstance(timeline_by_position, dict):
                raise TypeError(
                    f"truck evaluation {truck_id} timeline_by_position must be a dict"
                )
            edge_costs: Dict[int, float] = {}
            route_is_feasible = evaluation["feasible"]
            edge_positions_to_record = range(len(truck_route) - 1)
            if route_is_feasible is not True:
                edge_positions_to_record = [
                    edge_position
                    for edge_position in range(len(truck_route) - 1)
                    if edge_position in timeline_by_position
                ]

            for edge_position in edge_positions_to_record:
                if edge_position not in timeline_by_position:
                    raise ValueError(
                        f"truck {truck_id} timeline missing edge start "
                        f"position {edge_position}"
                    )
                start_record = timeline_by_position[edge_position]
                if "departure_time" not in start_record:
                    raise ValueError(
                        f"truck {truck_id} timeline position {edge_position} "
                        "missing departure_time"
                    )
                period = self._cost_ledger_period(start_record["departure_time"])
                from_node = truck_route[edge_position]
                to_node = truck_route[edge_position + 1]
                risk_level = self._matrix_value_for_cost_ledger(
                    self.risk_matrix,
                    period,
                    from_node,
                    to_node,
                )
                distance = self._matrix_value_for_cost_ledger(
                    self.distance_matrix,
                    from_node,
                    to_node,
                )
                edge_costs[edge_position] = (
                    (distance / ROAD_RISK_DISTANCE_SCALE) * risk_level * road_risk_weight
                )
            truck_edge_road_risk_cost_by_position[truck_id] = edge_costs

            if truck_id not in sol.data["phase_start_state_by_truck"]:
                raise ValueError(
                    f"phase_start_state_by_truck missing truck_id {truck_id}"
                )
            start_state = sol.data["phase_start_state_by_truck"][truck_id]
            if "anchor_time" not in start_state:
                raise ValueError(
                    f"phase_start_state_by_truck[{truck_id}] missing anchor_time"
                )
            route_start_time = start_state["anchor_time"]
            for position, node in enumerate(truck_route):
                if position == 0:
                    continue
                if node in {self.depot_start, self.depot_end, self.replenishment_node}:
                    continue
                if node not in self.customers:
                    raise ValueError(
                        f"truck route {truck_id} contains unknown customer {node}"
                    )
                if position not in timeline_by_position:
                    if route_is_feasible is True:
                        raise ValueError(
                            f"truck {truck_id} timeline missing customer position "
                            f"{position}"
                        )
                    continue
                customer = self.customers[node]
                for required_key in ("service_time", "latest", "is_static"):
                    if required_key not in customer:
                        raise ValueError(
                            f"customer {node} missing required key: {required_key}"
                        )
                if not isinstance(customer["is_static"], bool):
                    raise TypeError(
                        f"customer {node} is_static must be bool, "
                        f"got {type(customer['is_static']).__name__}"
                    )
                departure_time = timeline_by_position[position]["departure_time"]
                service_start_time = departure_time - customer["service_time"]
                customer_weight = require_customer_priority_weight(
                    node,
                    self.customers,
                )
                if customer["is_static"]:
                    priority_time = service_start_time
                else:
                    if "release_time" not in customer:
                        raise ValueError(f"customer {node} missing required key: release_time")
                    release_time = customer["release_time"]
                    if isinstance(release_time, bool) or not isinstance(release_time, (int, float)):
                        raise TypeError(
                            f"customer {node} release_time must be numeric, "
                            f"got {type(release_time).__name__}"
                        )
                    priority_time = service_start_time - release_time
                priority_cost = (
                    customer_weight
                    * max(0.0, priority_time)
                    * priority_weight
                )
                delay_penalty = (
                    max(0.0, service_start_time - customer["latest"])
                    * customer_weight
                    * delay_weight
                )
                self._add_customer_cost_to_ledger(
                    priority_cost_by_customer=priority_cost_by_customer,
                    delay_penalty_by_customer=delay_penalty_by_customer,
                    customer_id=node,
                    priority_cost=priority_cost,
                    delay_penalty=delay_penalty,
                )

        for task_index, task in enumerate(sol.data["drone_routes"]):
            for required_key in ("task_id", "customer", "evaluation"):
                if required_key not in task:
                    raise ValueError(
                        f"drone task {task_index} missing required key: {required_key}"
                    )
            evaluation = task["evaluation"]
            if not isinstance(evaluation, dict):
                raise TypeError(f"drone task {task_index} evaluation must be a dict")
            for component_key in (
                "priority_cost",
                "road_risk_cost",
                "delay_penalty",
                "unserved_penalty_cost",
                "cost",
            ):
                if component_key not in evaluation:
                    raise ValueError(
                        f"drone task {task_index} evaluation missing {component_key}"
                    )
            task_priority_cost = evaluation["priority_cost"] * priority_weight
            task_road_risk_cost = evaluation["road_risk_cost"] * road_risk_weight
            task_delay_penalty = evaluation["delay_penalty"] * delay_weight
            cost_components["priority_cost"] += task_priority_cost
            cost_components["road_risk_cost"] += task_road_risk_cost
            cost_components["delay_penalty"] += task_delay_penalty

            self._add_customer_cost_to_ledger(
                priority_cost_by_customer=priority_cost_by_customer,
                delay_penalty_by_customer=delay_penalty_by_customer,
                customer_id=task["customer"],
                priority_cost=task_priority_cost,
                delay_penalty=task_delay_penalty,
            )

        component_total = sum(cost_components.values())
        if abs(component_total - cost_info["total_cost"]) > 1e-6:
            raise ValueError(
                "cost ledger components do not sum to total cost: "
                f"{component_total} != {cost_info['total_cost']}"
            )

        return {
            "truck_edge_road_risk_cost_by_position": (
                truck_edge_road_risk_cost_by_position
            ),
            "priority_cost_by_customer": priority_cost_by_customer,
            "delay_penalty_by_customer": delay_penalty_by_customer,
            "drone_cost_by_task_id": drone_cost_by_task_id,
            "cost_components": cost_components,
        }

    def _rebuild_solution(self, sol: Solution, full_validate: bool = False) -> None:
        if not _profile_enabled():
            self._rebuild_solution_impl(sol, full_validate=full_validate)
            return None

        start_time = time.perf_counter()
        _profile_count("rebuild_total_calls")
        if full_validate:
            _profile_count("rebuild_full_validate_calls")
        else:
            _profile_count("rebuild_lightweight_calls")
        try:
            self._rebuild_solution_impl(sol, full_validate=full_validate)
        finally:
            _profile_add(
                "rebuild_total_seconds",
                time.perf_counter() - start_time,
            )
        return None

    def _rebuild_solution_impl(self, sol: Solution, full_validate: bool = False) -> None:
        """
        重建当前解的派生信息。

        本函数只基于已有 truck_routes 和 drone_routes 重算评价、占用、服务状态和成本；
        不改变卡车路径顺序，不生成新路径，也不新增无人机任务。
        """
        required_solution_keys = {
            "truck_routes",
            "drone_routes",
            "next_drone_task_id",
            "unserved",
            "served",
            "cost",
            "feasible",
            "validation_report",#是一个字典，包含针对卡车初始解的验证结果
            "full_validation_report",#通常包含 validation_report（卡车部分）以及额外的无人机任务验证结果、全局资源使用情况
            "drone_period_usage",
            "segment_usage",
        }
        missing_solution_keys = required_solution_keys - set(sol.data)
        if missing_solution_keys:
            raise ValueError(
                f"solution missing required keys: {sorted(missing_solution_keys)}"
            )
        if not isinstance(sol.data["truck_routes"], dict):
            raise TypeError('sol.data["truck_routes"] must be a dict')
        if not isinstance(sol.data["drone_routes"], list):
            raise TypeError('sol.data["drone_routes"] must be a list')
        if not isinstance(sol.data["unserved"], list):
            raise TypeError('sol.data["unserved"] must be a list')
        if not isinstance(sol.data["served"], set):
            raise TypeError('sol.data["served"] must be a set')
        if not isinstance(sol.data["phase_start_state_by_truck"], dict):
            raise TypeError('sol.data["phase_start_state_by_truck"] must be a dict')

        # 给无人机任务设置临时 task_id，便于重算函数稳定追踪任务。
        validate_unique_drone_task_ids(sol.data["drone_routes"])

        # 按卡车分组无人机任务。任务对象不复制，重算函数会更新原任务字段。
        drone_tasks_by_truck = {
            truck_id: []
            for truck_id in sol.data["truck_routes"]
        }
        for task_index, task in enumerate(sol.data["drone_routes"]):
            if "truck_id" not in task:
                raise ValueError(f"drone task {task_index} missing required key: truck_id")
            truck_id = task["truck_id"]
            if truck_id not in sol.data["truck_routes"]:
                raise ValueError(
                    f"drone task {task_index} references unknown truck_id {truck_id}"
                )
            drone_tasks_by_truck[truck_id].append(task)

        truck_evaluations = {}
        route_costs = {}
        total_truck_cost = 0.0
        phase_start_state_by_truck = sol.data["phase_start_state_by_truck"]

        # 逐辆卡车重新模拟时间线，并同步该车上的无人机任务时间字段。
        for truck_id, truck_route in sol.data["truck_routes"].items():
            if truck_id not in phase_start_state_by_truck:
                raise ValueError(f"phase_start_state_by_truck missing truck_id {truck_id}")
            start_state = phase_start_state_by_truck[truck_id]
            required_start_state_keys = {
                "anchor_node",
                "anchor_time",
                "initial_basic_load",
                "initial_emergency_load",
            }
            missing_start_state_keys = required_start_state_keys - set(start_state)
            if missing_start_state_keys:
                raise ValueError(
                    f"phase_start_state_by_truck[{truck_id}] missing required keys: "
                    f"{sorted(missing_start_state_keys)}"
                )
            if not truck_route:
                raise ValueError(f"truck route of truck {truck_id} must not be empty")
            if truck_route[0] != start_state["anchor_node"]:
                raise ValueError(
                    f"truck {truck_id} route must start from anchor_node "
                    f"{start_state['anchor_node']}, got {truck_route[0]}"
                )
            if isinstance(self.truck_capacity_by_truck, dict):
                truck_capacity = self.truck_capacity_by_truck[truck_id]
            else:
                truck_capacity = self.truck_capacity_by_truck

            evaluation = recompute_truck_timeline_with_drone_waiting(
                truck_route=truck_route,
                truck_id=truck_id,
                truck_drone_tasks=drone_tasks_by_truck[truck_id],
                customers=self.customers,
                distance_matrix=self.distance_matrix,
                truck_time_matrix=self.truck_time_matrix,
                risk_matrix=self.risk_matrix,
                drone_time_matrix=self.drone_time_matrix,
                drone_distance_matrix=self.drone_distance_matrix,
                periods=self.periods,
                period_length=self.period_length,
                truck_capacity=truck_capacity,
                drone_capacity_by_drone=self.drone_capacity_by_drone,
                drone_endurance_by_drone=self.drone_endurance_by_drone,
                depot_start=self.depot_start,
                depot_end=self.depot_end,
                replenishment_node=self.replenishment_node,
                start_time=start_state["anchor_time"],
                anchor_node=start_state["anchor_node"],
                initial_basic_load=start_state["initial_basic_load"],
                initial_emergency_load=start_state["initial_emergency_load"],
                cost_weights=self.cost_weights,
            )

            truck_evaluations[truck_id] = evaluation
            route_cost = calculate_route_cost(
                evaluation,
                cost_weights=self.cost_weights,
            )
            route_costs[truck_id] = route_cost
            total_truck_cost += route_cost

        sol.data["validation_report"] = {
            "truck_evaluations": truck_evaluations,
            "route_costs": route_costs,
            "total_truck_cost": total_truck_cost,
        }

        # 用重算后的 timing 信息更新每个无人机任务的字段和占用路段。
        for task_index, task in enumerate(sol.data["drone_routes"]):
            required_task_keys = {
                "truck_id",
                "drone_id",
                "launch_node",
                "customer",
                "recovery_node",
                "evaluation",
                "task_id",
            }
            missing_task_keys = required_task_keys - set(task)
            if missing_task_keys:
                raise ValueError(
                    f"drone task {task_index} missing required keys: {sorted(missing_task_keys)}"
                )
            if not isinstance(task["evaluation"], dict):
                raise TypeError(f"drone task {task_index} evaluation must be a dict")

            truck_id = task["truck_id"]
            truck_route = sol.data["truck_routes"][truck_id]
            timing = truck_evaluations[truck_id]["drone_task_timings"][task["task_id"]]
            if timing.get("launch_time") is None or timing.get("recovery_time") is None:
                diagnostic = self._build_drone_task_diagnostic(
                    sol=sol,
                    task_index=task_index,
                    task=task,
                    truck_evaluations=truck_evaluations,
                    timing=timing,
                    scope="rebuild_solution",
                )
                raise ValueError(
                    "drone task recomputation produced missing launch/recovery "
                    f"time; diagnostic={diagnostic}"
                )

            task["launch_time"] = timing["launch_time"]
            task["recovery_time"] = timing["recovery_time"]
            task["period_index"] = timing["period_index"]
            task["truck_waiting_time"] = timing["truck_waiting_time"]
            task["cost"] = timing["cost"] if "cost" in timing else task["cost"]
            task["evaluation"] = timing

            def resolve_task_index(node_key: str, index_key: str) -> int:
                node = task[node_key]
                if index_key in task:
                    index_value = task[index_key]
                    if isinstance(index_value, bool) or not isinstance(index_value, int):
                        raise TypeError(
                            f"drone task {task_index} {index_key} must be int, "
                            f"got {type(index_value).__name__}"
                        )
                    if index_value < 0 or index_value >= len(truck_route):
                        raise ValueError(
                            f"drone task {task_index} {index_key} {index_value} "
                            f"outside truck route length {len(truck_route)}"
                        )
                    if truck_route[index_value] != node:
                        raise ValueError(
                            f"drone task {task_index} {index_key} points to "
                            f"{truck_route[index_value]}, expected {node}"
                        )
                    return index_value

                matching_indices = [
                    index
                    for index, route_node in enumerate(truck_route)
                    if route_node == node
                ]
                if len(matching_indices) != 1:
                    raise ValueError(
                        f"drone task {task_index} {node_key} {node} is ambiguous without "
                        f"{index_key}: indices={matching_indices}"
                    )
                return matching_indices[0]

            launch_index = resolve_task_index("launch_node", "launch_idx")
            recovery_index = resolve_task_index("recovery_node", "recovery_idx")
            if launch_index >= recovery_index:
                raise ValueError(
                    f"drone task {task_index} launch_idx must be before recovery_idx"
                )
            task["occupied_segments"] = [
                (truck_id, segment_index)
                for segment_index in range(launch_index, recovery_index)
            ]

        # 重新计算卡车路段无人机占用次数。
        segment_usage = {}
        for truck_id, truck_route in sol.data["truck_routes"].items():
            for segment_index in range(len(truck_route) - 1):
                segment_usage[(truck_id, segment_index)] = 0

        for task in sol.data["drone_routes"]:
            for segment in task["occupied_segments"]:
                segment_usage[segment] += 1

        sol.data["segment_usage"] = segment_usage

        # 重新计算每架无人机在每个周期的使用次数。
        drone_period_usage = {}
        for task in sol.data["drone_routes"]:
            key = (task["drone_id"], task["period_index"])
            drone_period_usage[key] = drone_period_usage.get(key, 0) + 1

        sol.data["drone_period_usage"] = drone_period_usage

        # 根据当前卡车路径和无人机任务重算 served。
        non_customer_nodes = {
            self.depot_start,
            self.depot_end,
            self.replenishment_node,
        }
        truck_served = set()
        phase_locked_customer_ids = self._phase_locked_customer_ids(sol)
        for truck_id, truck_route in sol.data["truck_routes"].items():
            for position, node in enumerate(truck_route):
                if node in non_customer_nodes:
                    continue
                if position == 0 and node in phase_locked_customer_ids:
                    continue
                if node in phase_locked_customer_ids:
                    raise ValueError(
                        f"truck route of truck {truck_id} contains locked customer {node} "
                        f"outside phase anchor"
                    )
                if node in self.customers:
                    truck_served.add(node)
                else:
                    raise ValueError(
                        f"truck route of truck {truck_id} contains unknown customer {node}"
                    )

        drone_served = {
            task["customer"]
            for task in sol.data["drone_routes"]
        }
        for customer_id in drone_served:
            if customer_id not in self.customers:
                raise ValueError(f"drone route contains unknown customer {customer_id}")
            if customer_id in phase_locked_customer_ids:
                raise ValueError(f"drone route contains locked customer {customer_id}")
            if customer_id in non_customer_nodes:
                raise ValueError(
                    f"drone route customer cannot be depot or replenishment node: {customer_id}"
                )

        corrected_served = truck_served | drone_served
        sol.data["served"] = corrected_served

        # 只清理 served/unserved 冲突，不自动补全缺失客户。
        sol.data["unserved"] = [
            customer_id
            for customer_id in sol.data["unserved"]
            if customer_id not in corrected_served
        ]

        lightweight_violations = []
        for truck_id, evaluation in truck_evaluations.items():
            if "feasible" not in evaluation:
                raise ValueError(f"truck evaluation {truck_id} missing required key: feasible")
            if not evaluation["feasible"]:
                lightweight_violations.append(f"truck {truck_id} is infeasible")

        drone_intervals_by_drone: Dict[Tuple[int, int], List[Dict[str, Any]]] = {}
        for task_index, task in enumerate(sol.data["drone_routes"]):
            for key_name in ("truck_id", "drone_id"):
                if key_name not in task:
                    raise ValueError(f"drone task {task_index} missing required key: {key_name}")
            missing_time_fields = [
                field_name
                for field_name in ("launch_time", "recovery_time")
                if task.get(field_name) is None
            ]
            if missing_time_fields:
                lightweight_violations.append(
                    f"drone task {task_index} has missing recomputed time fields: "
                    f"{missing_time_fields}"
                )
                continue
            launch_time = self._drone_task_time(task, "launch_time")
            recovery_time = self._drone_task_time(task, "recovery_time")
            if recovery_time < launch_time:
                lightweight_violations.append(
                    f"drone task {task_index} recovery_time {recovery_time} "
                    f"is before launch_time {launch_time}"
                )
                continue
            interval_key = (task["truck_id"], task["drone_id"])
            drone_intervals_by_drone.setdefault(interval_key, []).append(
                {
                    "task_index": task_index,
                    "customer": task["customer"],
                    "launch_time": launch_time,
                    "recovery_time": recovery_time,
                    "source": "phase",
                }
            )
        for interval in self._phase_locked_drone_intervals(sol):
            interval_key = (interval["truck_id"], interval["drone_id"])
            drone_intervals_by_drone.setdefault(interval_key, []).append(
                {
                    "task_index": interval["task_id"],
                    "customer": interval["customer"],
                    "launch_time": interval["launch_time"],
                    "recovery_time": interval["recovery_time"],
                    "source": "locked",
                }
            )
        for (truck_id, drone_id), intervals in drone_intervals_by_drone.items():
            intervals.sort(key=lambda item: (item["launch_time"], item["recovery_time"]))
            for previous, current in zip(intervals, intervals[1:]):
                if current["launch_time"] < previous["recovery_time"]:
                    lightweight_violations.append(
                        f"drone {drone_id} on truck {truck_id} has overlapping tasks: "
                        f"{previous['source']} task {previous['task_index']} "
                        f"customer {previous['customer']} "
                        f"[{previous['launch_time']}, {previous['recovery_time']}] and "
                        f"{current['source']} task {current['task_index']} "
                        f"customer {current['customer']} "
                        f"[{current['launch_time']}, {current['recovery_time']}]"
                    )

        for segment, usage_count in segment_usage.items():
            truck_id = segment[0]
            if truck_id not in self.drone_ids_by_truck:
                raise ValueError(f"drone_ids_by_truck missing truck_id {truck_id}")
            if usage_count > len(self.drone_ids_by_truck[truck_id]):
                lightweight_violations.append(
                    f"segment usage exceeds drone count: {segment} -> {usage_count}"
                )

        lightweight_feasible = len(lightweight_violations) == 0
        if full_validate:
            full_report = validate_full_solution(
                solution=sol.data,
                customers=self.customers,
                drone_ids_by_truck=self.drone_ids_by_truck,
                depot_start=self.depot_start,
                depot_end=self.depot_end,
                replenishment_node=self.replenishment_node,
                periods=self.periods,
                period_length=self.period_length,
                unserved_penalty=self.unserved_penalty,
                update_solution=True,
                raise_error=False,
            )
            full_report["segment_usage"] = segment_usage
            full_report["drone_period_usage"] = drone_period_usage
            sol.data["full_validation_report"] = full_report
        else:
            sol.data["full_validation_report"] = {
                "valid": lightweight_feasible,
                "feasible": lightweight_feasible,
                "violations": list(lightweight_violations),
                "warnings": [],
                "validation_scope": "lightweight_rebuild",
                "segment_usage": segment_usage,
                "drone_period_usage": drone_period_usage,
            }
        sol.data["segment_usage"] = segment_usage
        sol.data["drone_period_usage"] = drone_period_usage

        cost_info = calculate_solution_cost(
            solution=sol.data,
            customers=self.customers,
            unserved_penalty=self.unserved_penalty,
            cost_weights=self.cost_weights,
        )
        sol.data["cost_info"] = cost_info
        sol.data["validation_report"]["cost_ledger"] = self._build_cost_ledger(
            sol=sol,
            cost_info=cost_info,
        )
        sol.data["cost"] = cost_info["total_cost"]
        report = sol.data["full_validation_report"]
        sol.data["feasible"] = (
            report["valid"]
            and report["feasible"]
        )
        return None

def make_constant_matrix(node_ids, value, diagonal_value=0):
    matrix = {}

    for i in node_ids:
        matrix[i] = {}
        for j in node_ids:
            if i == j:
                matrix[i][j] = diagonal_value
            else:
                matrix[i][j] = value

    return matrix


def make_period_matrix(periods, node_ids, value, diagonal_value=0):
    matrix = {}

    for p in periods:
        matrix[p] = {}
        for i in node_ids:
            matrix[p][i] = {}
            for j in node_ids:
                if i == j:
                    matrix[p][i][j] = diagonal_value
                else:
                    matrix[p][i][j] = value

    return matrix
